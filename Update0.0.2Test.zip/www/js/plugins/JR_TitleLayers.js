/*:
 * @plugindesc (v1.23) Custom sequential title screen layer system for images & videos.
 * @author JR
 *
 * @param Click to skip layer
 * @desc If true, clicking or touching the screen (outside the command window) skips the current layer.
 * @type boolean
 * @default true
 * 
 * @param Last Layer Video Loop
 * @desc If true, a video on the final layer will loop endlessly. If false, it freezes on its last frame.
 * @type boolean
 * @default true
 * 
 * @param Title and Subtitle on Last Layer
 * @desc True: Logo appears only when the final layer starts. False: Starts on the specific layer configured below.
 * @type boolean
 * @default true
 * 
 * @param Title Start Layer
 * @desc If 'Title and Subtitle on Last Layer' is false, which layer should they start on? (1 = First Layer)
 * @type number
 * @default 1
 * 
 * @param --- Game Title Settings ---
 * 
 * @param Title Image
 * @parent --- Game Title Settings ---
 * @desc Select the image file for your Game Title.
 * @type file
 * @dir img/titles2/
 * 
 * @param Title X
 * @parent --- Game Title Settings ---
 * @desc Title X coordinate. Can use "windowWidth".
 * @type string
 * @default 0
 * 
 * @param Title Y
 * @parent --- Game Title Settings ---
 * @desc Title Y coordinate. Can use "windowHeight".
 * @type string
 * @default 0
 * 
 * @param Title Scale
 * @parent --- Game Title Settings ---
 * @desc Scale multiplier (1.0 = 100%, 0.5 = 50%).
 * @type number
 * @decimals 2
 * @default 1.00
 * 
 * @param Title Max Opacity
 * @parent --- Game Title Settings ---
 * @desc Maximum opacity for the Title (0 to 255).
 * @type number
 * @default 255
 * 
 * @param Title Transition Type
 * @parent --- Game Title Settings ---
 * @type select
 * @option Fade In
 * @value fade
 * @option Slide Up
 * @value slide_up
 * @option Slide Down
 * @value slide_down
 * @option Slide Left
 * @value slide_left
 * @option Slide Right
 * @value slide_right
 * @option Cinematic Focus
 * @value zoom_fade
 * @option Drop-In
 * @value drop_in
 * @option Overshoot (Bounce)
 * @value overshoot
 * @option Tilt & Settle
 * @value tilt_settle
 * @option Neon Flicker
 * @value neon_flicker
 * @option Wipe Right
 * @value wipe_right
 * @option Wipe Left
 * @value wipe_left
 * @option Wipe Down
 * @value wipe_down
 * @option Wipe Up
 * @value wipe_up
 * @option None
 * @value none
 * @default fade
 * 
 * @param Title Transition Time
 * @parent --- Game Title Settings ---
 * @desc Duration of the IN-transition in frames.
 * @type number
 * @default 60
 * 
 * @param Title Delay Time
 * @parent --- Game Title Settings ---
 * @desc Wait time in SECONDS before the Title begins transitioning in.
 * @type number
 * @decimals 1
 * @default 1.0
 *
 * @param Title Idle Float
 * @parent --- Game Title Settings ---
 * @desc Bob gently up and down after transitioning in?
 * @type boolean
 * @default false
 *
 * @param Title Idle Pulse
 * @parent --- Game Title Settings ---
 * @desc Smoothly scale up and down after transitioning in?
 * @type boolean
 * @default false
 *
 * @param Title Idle Sway
 * @parent --- Game Title Settings ---
 * @desc Gently tilt left and right after transitioning in?
 * @type boolean
 * @default false
 *
 * @param Title Idle Fade
 * @parent --- Game Title Settings ---
 * @desc Slowly shift opacity after transitioning in?
 * @type boolean
 * @default false
 * 
 * @param --- Subtitle Settings ---
 * 
 * @param Subtitle Image
 * @parent --- Subtitle Settings ---
 * @desc Select the image file for your Subtitle.
 * @type file
 * @dir img/titles2/
 * 
 * @param Subtitle X
 * @parent --- Subtitle Settings ---
 * @desc X coordinate. Can use "windowWidth" and "titleWidth".
 * @type string
 * @default 0
 * 
 * @param Subtitle Y
 * @parent --- Subtitle Settings ---
 * @desc Y coordinate. Can use "windowHeight" and "titleHeight".
 * @type string
 * @default 0
 * 
 * @param Subtitle Scale
 * @parent --- Subtitle Settings ---
 * @desc Scale multiplier (1.0 = 100%, 0.5 = 50%).
 * @type number
 * @decimals 2
 * @default 1.00
 * 
 * @param Subtitle Max Opacity
 * @parent --- Subtitle Settings ---
 * @desc Maximum opacity for the Subtitle (0 to 255).
 * @type number
 * @default 255
 * 
 * @param Subtitle Transition Type
 * @parent --- Subtitle Settings ---
 * @type select
 * @option Fade In
 * @value fade
 * @option Slide Up
 * @value slide_up
 * @option Slide Down
 * @value slide_down
 * @option Slide Left
 * @value slide_left
 * @option Slide Right
 * @value slide_right
 * @option Cinematic Focus
 * @value zoom_fade
 * @option Drop-In
 * @value drop_in
 * @option Overshoot (Bounce)
 * @value overshoot
 * @option Tilt & Settle
 * @value tilt_settle
 * @option Neon Flicker
 * @value neon_flicker
 * @option Wipe Right
 * @value wipe_right
 * @option Wipe Left
 * @value wipe_left
 * @option Wipe Down
 * @value wipe_down
 * @option Wipe Up
 * @value wipe_up
 * @option None
 * @value none
 * @default fade
 * 
 * @param Subtitle Transition Time
 * @parent --- Subtitle Settings ---
 * @desc Duration of the IN-transition in frames.
 * @type number
 * @default 60
 * 
 * @param Subtitle Wait Time
 * @parent --- Subtitle Settings ---
 * @desc Wait time in SECONDS after the Title finishes before the Subtitle starts.
 * @type number
 * @decimals 1
 * @default 0.5
 *
 * @param Subtitle Idle Float
 * @parent --- Subtitle Settings ---
 * @desc Bob gently up and down after transitioning in?
 * @type boolean
 * @default false
 *
 * @param Subtitle Idle Pulse
 * @parent --- Subtitle Settings ---
 * @desc Smoothly scale up and down after transitioning in?
 * @type boolean
 * @default false
 *
 * @param Subtitle Idle Sway
 * @parent --- Subtitle Settings ---
 * @desc Gently tilt left and right after transitioning in?
 * @type boolean
 * @default false
 *
 * @param Subtitle Idle Fade
 * @parent --- Subtitle Settings ---
 * @desc Slowly shift opacity after transitioning in?
 * @type boolean
 * @default false
 * 
 * @param --- Skip Text Settings ---
 * 
 * @param Skip Text
 * @parent --- Skip Text Settings ---
 * @desc The text to display to the player. Leave blank to disable.
 * @type string
 * @default Click on the screen to skip
 * 
 * @param Skip Text Size
 * @parent --- Skip Text Settings ---
 * @desc Font size of the skip text.
 * @type number
 * @default 20
 * 
 * @param Skip Text Color
 * @parent --- Skip Text Settings ---
 * @desc Color of the skip text (Hex or CSS).
 * @type string
 * @default #ffffff
 * 
 * @param Skip Text Opacity
 * @parent --- Skip Text Settings ---
 * @desc Maximum opacity for the skip text (0 to 255).
 * @type number
 * @default 180
 * 
 * @param Skip Text X
 * @parent --- Skip Text Settings ---
 * @desc X coordinate. Can use "windowWidth".
 * @type string
 * @default 20
 * 
 * @param Skip Text Y
 * @parent --- Skip Text Settings ---
 * @desc Y coordinate. Can use "windowHeight".
 * @type string
 * @default windowHeight - 40
 * 
 * @param --- Background Layers ---
 * 
 * @param Layers
 * @parent --- Background Layers ---
 * @desc Configure your title layers here. They will play sequentially.
 * @type struct<Layer>[]
 * @default []
 *
 * @help
 * ============================================================================
 * JR Title Layers (v1.23)
 * ============================================================================
 * Optimized for low-end machines (4GB RAM target).
 * 
 * - Explicitly cleans up PIXI video textures and elements to prevent memory leaks.
 * - Safely detaches ImageManager cache bitmaps without destroying them.
 * - Pauses transitions until images are fully loaded for smooth visuals.
 * - Holds the final layer on screen permanently.
 * - Delays layer retirement to allow for seamless crossfading.
 * - Allows selective layer retirement for transparent image stacking.
 * - Preloads all images into RAM at boot to eliminate async micro-stutters.
 * - Touch/Click/Keys to skip layers (ignores command window clicks).
 * - Option to loop the final video layer endlessly or freeze it statically.
 * - Bypasses PixiJS Native Loop freeze bugs with explicit JS restarts.
 * - Game Title and Subtitle image system with dimensional parsing.
 * - Custom scaling and max opacity support for both Title and Subtitle.
 * - Sine-wave based mathematical Idle Animations (Float, Pulse, Sway, Fade).
 * - Specify the exact starting layer for Title/Subtitle animations.
 * - NW.js File System Scanner prevents game crashes/hangs if files are missing.
 * - NEW: Failsafe now correctly recognizes encrypted (.rpgmvp) deployed images!
 */

/*~struct~Layer:
 * @param Visible
 * @desc Enable or disable this layer.
 * @type boolean
 * @default true
 *
 * @param Image File
 * @desc Select the image file. Ignored if a video file is provided.
 * @type file
 * @dir img/titles1/
 *
 * @param Video File
 * @desc Type the video file name (without extension). Must be in movies/.
 * @type string
 *
 * @param Video With Sound
 * @desc If true, plays the video's audio. If false, mutes it.
 * @type boolean
 * @default false
 * 
 * @param X
 * @desc X coordinate. Can use numbers or "windowWidth".
 * @type string
 * @default 0
 * 
 * @param Y
 * @desc Y coordinate. Can use numbers or "windowHeight".
 * @type string
 * @default 0
 *
 * @param Transition Type
 * @desc How the layer transitions ONTO the screen.
 * @type select
 * @option Fade In
 * @value fade
 * @option Slide Up
 * @value slide_up
 * @option Slide Down
 * @value slide_down
 * @option Slide Left
 * @value slide_left
 * @option Slide Right
 * @value slide_right
 * @option None
 * @value none
 * @default fade
 *
 * @param Transition Time
 * @desc Duration of the IN-transition in frames.
 * @type number
 * @default 60
 * 
 * @param Wait Time
 * @desc Frames to wait AFTER Transition In before Transition Out begins (Images Only).
 * @type number
 * @default 120
 * 
 * @param Transition Out Type
 * @desc WARNING: Set this to 'None' for your final layer! How the layer transitions OFF the screen.
 * @type select
 * @option Fade Out
 * @value fade
 * @option Slide Up
 * @value slide_up
 * @option Slide Down
 * @value slide_down
 * @option Slide Left
 * @value slide_left
 * @option Slide Right
 * @value slide_right
 * @option None
 * @value none
 * @default none
 *
 * @param Transition Out Time
 * @desc Duration of the OUT-transition in frames.
 * @type number
 * @default 60
 * 
 * @param Retire Layer
 * @desc Delete layer after the next one loads to save GPU? Set FALSE if next layer is transparent.
 * @type boolean
 * @default true
 */

var Imported = Imported || {};
Imported.JR_TitleLayers = true;

var JR = JR || {};
JR.TitleLayers = JR.TitleLayers || {};

var _currentScriptName = document.currentScript ? document.currentScript.src.match(/([^\/]+)\.js/)[1] : 'JR_TitleLayers';
JR.TitleLayers.Parameters = PluginManager.parameters(_currentScriptName);

// Global Settings
JR.TitleLayers.clickToSkip = String(JR.TitleLayers.Parameters['Click to skip layer']).trim().toLowerCase() === 'true';
JR.TitleLayers.lastLayerVideoLoop = String(JR.TitleLayers.Parameters['Last Layer Video Loop']).trim().toLowerCase() === 'true';
JR.TitleLayers.titlesOnLastLayer = String(JR.TitleLayers.Parameters['Title and Subtitle on Last Layer']).trim().toLowerCase() !== 'false';
JR.TitleLayers.titleStartLayer = Number(JR.TitleLayers.Parameters['Title Start Layer']) || 1;

// Title Settings
JR.TitleLayers.titleImage = String(JR.TitleLayers.Parameters['Title Image'] || '');
JR.TitleLayers.titleX = String(JR.TitleLayers.Parameters['Title X'] || '0');
JR.TitleLayers.titleY = String(JR.TitleLayers.Parameters['Title Y'] || '0');
JR.TitleLayers.titleScale = (JR.TitleLayers.Parameters['Title Scale'] !== undefined && JR.TitleLayers.Parameters['Title Scale'] !== '') ? Number(JR.TitleLayers.Parameters['Title Scale']) : 1.0;
JR.TitleLayers.titleOpacity = (JR.TitleLayers.Parameters['Title Max Opacity'] !== undefined && JR.TitleLayers.Parameters['Title Max Opacity'] !== '') ? Number(JR.TitleLayers.Parameters['Title Max Opacity']) : 255;
JR.TitleLayers.titleTransType = String(JR.TitleLayers.Parameters['Title Transition Type'] || 'fade');
JR.TitleLayers.titleTransTime = Number(JR.TitleLayers.Parameters['Title Transition Time']) || 60;
JR.TitleLayers.titleDelay = Number(JR.TitleLayers.Parameters['Title Delay Time']) || 0;

JR.TitleLayers.tIdleFloat = String(JR.TitleLayers.Parameters['Title Idle Float']).trim().toLowerCase() === 'true';
JR.TitleLayers.tIdlePulse = String(JR.TitleLayers.Parameters['Title Idle Pulse']).trim().toLowerCase() === 'true';
JR.TitleLayers.tIdleSway = String(JR.TitleLayers.Parameters['Title Idle Sway']).trim().toLowerCase() === 'true';
JR.TitleLayers.tIdleFade = String(JR.TitleLayers.Parameters['Title Idle Fade']).trim().toLowerCase() === 'true';

// Subtitle Settings
JR.TitleLayers.subImage = String(JR.TitleLayers.Parameters['Subtitle Image'] || '');
JR.TitleLayers.subX = String(JR.TitleLayers.Parameters['Subtitle X'] || '0');
JR.TitleLayers.subY = String(JR.TitleLayers.Parameters['Subtitle Y'] || '0');
JR.TitleLayers.subScale = (JR.TitleLayers.Parameters['Subtitle Scale'] !== undefined && JR.TitleLayers.Parameters['Subtitle Scale'] !== '') ? Number(JR.TitleLayers.Parameters['Subtitle Scale']) : 1.0;
JR.TitleLayers.subOpacity = (JR.TitleLayers.Parameters['Subtitle Max Opacity'] !== undefined && JR.TitleLayers.Parameters['Subtitle Max Opacity'] !== '') ? Number(JR.TitleLayers.Parameters['Subtitle Max Opacity']) : 255;
JR.TitleLayers.subTransType = String(JR.TitleLayers.Parameters['Subtitle Transition Type'] || 'fade');
JR.TitleLayers.subTransTime = Number(JR.TitleLayers.Parameters['Subtitle Transition Time']) || 60;
JR.TitleLayers.subWait = Number(JR.TitleLayers.Parameters['Subtitle Wait Time']) || 0;

JR.TitleLayers.sIdleFloat = String(JR.TitleLayers.Parameters['Subtitle Idle Float']).trim().toLowerCase() === 'true';
JR.TitleLayers.sIdlePulse = String(JR.TitleLayers.Parameters['Subtitle Idle Pulse']).trim().toLowerCase() === 'true';
JR.TitleLayers.sIdleSway = String(JR.TitleLayers.Parameters['Subtitle Idle Sway']).trim().toLowerCase() === 'true';
JR.TitleLayers.sIdleFade = String(JR.TitleLayers.Parameters['Subtitle Idle Fade']).trim().toLowerCase() === 'true';

// Skip Text Settings
JR.TitleLayers.skipText = String(JR.TitleLayers.Parameters['Skip Text'] || '');
JR.TitleLayers.skipTextSize = Number(JR.TitleLayers.Parameters['Skip Text Size']) || 20;
JR.TitleLayers.skipTextColor = String(JR.TitleLayers.Parameters['Skip Text Color'] || '#ffffff');
JR.TitleLayers.skipTextOpacity = Number(JR.TitleLayers.Parameters['Skip Text Opacity']);
if (isNaN(JR.TitleLayers.skipTextOpacity)) JR.TitleLayers.skipTextOpacity = 180;
JR.TitleLayers.skipTextX = String(JR.TitleLayers.Parameters['Skip Text X'] || '20');
JR.TitleLayers.skipTextY = String(JR.TitleLayers.Parameters['Skip Text Y'] || 'windowHeight - 40');

// Parse Layers
JR.TitleLayers.LayersData = [];
if (JR.TitleLayers.Parameters['Layers']) {
    try {
        const rawParsed = JSON.parse(JR.TitleLayers.Parameters['Layers']);
        if (Array.isArray(rawParsed)) {
            rawParsed.forEach((layerStr, index) => {
                try {
                    let parsedLayer = typeof layerStr === 'string' ? JSON.parse(layerStr) : layerStr;
                    JR.TitleLayers.LayersData.push(parsedLayer);
                } catch (e2) {
                    console.warn(`Failed to parse layer at index ${index}`, layerStr);
                }
            });
        }
    } catch (e) {
        console.error("JR Title Layers: Critical failure parsing the 'Layers' array.", e);
    }
}

//=============================================================================
// NW.js File Validation System
//=============================================================================
JR.TitleLayers.checkFileExists = function(folder, filename, isVideo) {
    if (!Utils.isNwjs()) return true; // Web fallback
    try {
        var fs = require('fs');
        var path = require('path');
        var base = path.dirname(process.mainModule.filename);
        
        if (isVideo) {
            var ext = Graphics._videoExt || (Graphics.canPlayVideoType('video/webm') ? '.webm' : '.mp4');
            var fullPath = path.join(base, folder, filename + ext);
            return fs.existsSync(fullPath);
        } else {
            // FIX: Check for both standard .png and encrypted .rpgmvp deployed formats
            var pngPath = path.join(base, folder, filename + '.png');
            var encPath = path.join(base, folder, filename + '.rpgmvp');
            return fs.existsSync(pngPath) || fs.existsSync(encPath);
        }
    } catch (e) {
        return true; 
    }
};

//=============================================================================
// Scene_Title overrides
//=============================================================================

Scene_Title.prototype.loadProtectedJRImage = function(filename, folder) {
    if (!filename) return new Bitmap(0, 0);
    
    let pathFolder = (folder === 'title1') ? 'img/titles1' : 'img/titles2';
    
    // Failsafe 1: NW.js intercept. If missing (and not encrypted), silently return dummy bitmap.
    if (!JR.TitleLayers.checkFileExists(pathFolder, filename, false)) {
        console.warn(`JR Title Layers: Blocked crash! Missing image safely bypassed -> ${pathFolder}/${filename}`);
        return new Bitmap(0, 0);
    }
    
    let bmp;
    if (folder === 'title1') bmp = ImageManager.loadTitle1(filename);
    else bmp = ImageManager.loadTitle2(filename);
    
    // Failsafe 2: HTML Image hijack for non-NW.js systems
    if (bmp._image) {
        bmp._image.onerror = function() {
            bmp._hasError = false;
            bmp._isLoading = false;
            bmp._isReady = true; 
            console.warn(`JR Title Layers: Browser fallback engaged for missing image -> ${filename}`);
        };
    }
    
    // Core Crash Override: Intercepts the engine's fatal error check directly
    bmp.isError = function() {
        if (this._hasError) {
            console.warn(`JR Title Layers: Missing image safely ignored -> ${filename}`);
            return false; 
        }
        return false;
    };
    
    return bmp;
};

const _Scene_Title_createBackground = Scene_Title.prototype.createBackground;
Scene_Title.prototype.createBackground = function() {
    _Scene_Title_createBackground.call(this);
    this._backSprite1.visible = false;
    this._backSprite2.visible = false;
    this.createJRLayersContainer();
};

Scene_Title.prototype.createJRLayersContainer = function() {
    this._jrLayerContainer = new Sprite();
    this.addChild(this._jrLayerContainer);
    
    this._jrLayers = [];
    this._currentLayerIndex = 0;
    
    let visibleLayers = [];
    JR.TitleLayers.LayersData.forEach((data, index) => {
        let isVisible = data['Visible'] !== undefined ? String(data['Visible']).trim().toLowerCase() === 'true' : true;
        let hasVideo = String(data['Video File'] || '').trim().length > 0;
        let hasImage = String(data['Image File'] || '').trim().length > 0;
        
        if (isVisible && (hasVideo || hasImage)) {
            visibleLayers.push({ data: data, index: index });
        }
    });
    
    visibleLayers.forEach((item, i) => {
        let isLast = (i === visibleLayers.length - 1);
        const layer = new Sprite_JRTitleLayer(item.data, item.index, isLast, this);
        layer.visible = false; 
        this._jrLayers.push(layer);
        this._jrLayerContainer.addChild(layer);
    });
    
    // Create Title and Subtitle Sprites on top of the background layers
    this._jrTitleSprite = new Sprite();
    this._jrSubtitleSprite = new Sprite();
    this._jrTitleSprite.visible = false;
    this._jrSubtitleSprite.visible = false;
    
    if (JR.TitleLayers.titleImage) {
        this._jrTitleSprite.bitmap = this.loadProtectedJRImage(JR.TitleLayers.titleImage, 'title2');
        this._jrTitleSprite.scale.x = JR.TitleLayers.titleScale;
        this._jrTitleSprite.scale.y = JR.TitleLayers.titleScale;
    }
    if (JR.TitleLayers.subImage) {
        this._jrSubtitleSprite.bitmap = this.loadProtectedJRImage(JR.TitleLayers.subImage, 'title2');
        this._jrSubtitleSprite.scale.x = JR.TitleLayers.subScale;
        this._jrSubtitleSprite.scale.y = JR.TitleLayers.subScale;
    }
    
    this._jrLayerContainer.addChild(this._jrTitleSprite);
    this._jrLayerContainer.addChild(this._jrSubtitleSprite);
    
    // State Trackers
    this._jrTitlesTriggered = false;
    this._jrTitlesCoordsParsed = false;
    this._jrTitlePhase = 0; // 0=Delay, 1=TitleTrans, 2=SubWait, 3=SubTrans, 4=Done
    this._jrIdleTimer = 0;
};

const _Scene_Title_createForeground = Scene_Title.prototype.createForeground;
Scene_Title.prototype.createForeground = function() {
    _Scene_Title_createForeground.call(this);
    this.createJRSkipText();
};

Scene_Title.prototype.createJRSkipText = function() {
    if (!JR.TitleLayers.clickToSkip || JR.TitleLayers.skipText === '') return;
    
    this._jrSkipTextSprite = new Sprite(new Bitmap(Graphics.boxWidth, JR.TitleLayers.skipTextSize + 10));
    this._jrSkipTextSprite.bitmap.fontSize = JR.TitleLayers.skipTextSize;
    this._jrSkipTextSprite.bitmap.textColor = JR.TitleLayers.skipTextColor;
    
    this._jrSkipTextSprite.bitmap.drawText(JR.TitleLayers.skipText, 0, 0, Graphics.boxWidth, JR.TitleLayers.skipTextSize + 10, 'left');
    
    const parseCoord = (coordStr) => {
        if (!coordStr) return 0;
        let parsedStr = String(coordStr).replace(/windowWidth/gi, Graphics.boxWidth)
                                        .replace(/windowHeight/gi, Graphics.boxHeight);
        try { 
            let val = eval(parsedStr);
            return isNaN(val) ? 0 : val;
        } catch (e) { 
            return 0; 
        }
    };
    
    this._jrSkipTextSprite.x = parseCoord(JR.TitleLayers.skipTextX);
    this._jrSkipTextSprite.y = parseCoord(JR.TitleLayers.skipTextY);
    this._jrSkipTextSprite.opacity = 0; 
    this._jrSkipTextSprite.visible = false;
    
    this.addChild(this._jrSkipTextSprite);
};

Scene_Title.prototype.parseJRTitleCoord = function(coordStr) {
    if (!coordStr) return 0;
    
    let tW = this._jrTitleSprite.bitmap ? this._jrTitleSprite.bitmap.width * this._jrTitleSprite.scale.x : 0;
    let tH = this._jrTitleSprite.bitmap ? this._jrTitleSprite.bitmap.height * this._jrTitleSprite.scale.y : 0;
    
    let parsedStr = String(coordStr).replace(/windowWidth/gi, Graphics.boxWidth)
                                    .replace(/windowHeight/gi, Graphics.boxHeight)
                                    .replace(/titleWidth/gi, tW)
                                    .replace(/titleHeight/gi, tH);
    try { 
        let val = eval(parsedStr);
        return isNaN(val) ? 0 : val;
    } catch (e) { 
        return 0; 
    }
};

Scene_Title.prototype.setupJRTitleTransitionStart = function(sprite, type, maxOpacity, tScale) {
    sprite.visible = true;
    sprite.targetScaleX = tScale || 1;
    sprite.targetScaleY = tScale || 1;
    sprite.baseFrameW = sprite.bitmap ? sprite.bitmap.width : 0;
    sprite.baseFrameH = sprite.bitmap ? sprite.bitmap.height : 0;
    sprite.rotation = 0;
    
    if (type === 'none') {
        sprite.opacity = maxOpacity;
        sprite.scale.x = sprite.targetScaleX;
        sprite.scale.y = sprite.targetScaleY;
        if (sprite.baseFrameW > 0) sprite.setFrame(0, 0, sprite.baseFrameW, sprite.baseFrameH);
        return;
    }
    
    const offset = 200; 
    sprite.opacity = 0;
    
    switch(type) {
        case 'slide_up': sprite.y = sprite.targetY + offset; break;
        case 'slide_down': sprite.y = sprite.targetY - offset; break;
        case 'slide_left': sprite.x = sprite.targetX + offset; break;
        case 'slide_right': sprite.x = sprite.targetX - offset; break;
        case 'zoom_fade': 
            sprite.scale.x = sprite.targetScaleX * 1.2;
            sprite.scale.y = sprite.targetScaleY * 1.2;
            sprite.x = sprite.targetX - (sprite.baseFrameW * sprite.targetScaleX * 0.1);
            sprite.y = sprite.targetY - (sprite.baseFrameH * sprite.targetScaleY * 0.1);
            break;
        case 'drop_in':
            sprite.scale.x = 0;
            sprite.scale.y = 0;
            sprite.x = sprite.targetX + (sprite.baseFrameW * sprite.targetScaleX * 0.5);
            sprite.y = sprite.targetY + (sprite.baseFrameH * sprite.targetScaleY * 0.5);
            break;
        case 'overshoot':
            sprite.scale.x = 0;
            sprite.scale.y = 0;
            sprite.x = sprite.targetX + (sprite.baseFrameW * sprite.targetScaleX * 0.5);
            sprite.y = sprite.targetY + (sprite.baseFrameH * sprite.targetScaleY * 0.5);
            break;
        case 'tilt_settle':
            sprite.rotation = 0.2; 
            break;
        case 'wipe_right':
            sprite.opacity = maxOpacity;
            if (sprite.baseFrameW > 0) sprite.setFrame(0, 0, 0, sprite.baseFrameH);
            break;
        case 'wipe_left':
            sprite.opacity = maxOpacity;
            if (sprite.baseFrameW > 0) sprite.setFrame(sprite.baseFrameW, 0, 0, sprite.baseFrameH);
            break;
        case 'wipe_down':
            sprite.opacity = maxOpacity;
            if (sprite.baseFrameW > 0) sprite.setFrame(0, 0, sprite.baseFrameW, 0);
            break;
        case 'wipe_up':
            sprite.opacity = maxOpacity;
            if (sprite.baseFrameW > 0) sprite.setFrame(0, sprite.baseFrameH, sprite.baseFrameW, 0);
            break;
    }
};

Scene_Title.prototype.updateJRTitleTransition = function(sprite, type, maxTime, currentTimer, maxOpacity) {
    if (maxTime <= 0) return;
    
    const opacitySpeed = maxOpacity / maxTime;
    const moveSpeed = 200 / maxTime; 
    let progress = (maxTime - currentTimer) / maxTime;
    
    switch(type) {
        case 'fade': sprite.opacity += opacitySpeed; break;
        case 'slide_up': sprite.y -= moveSpeed; sprite.opacity += opacitySpeed; break;
        case 'slide_down': sprite.y += moveSpeed; sprite.opacity += opacitySpeed; break;
        case 'slide_left': sprite.x -= moveSpeed; sprite.opacity += opacitySpeed; break;
        case 'slide_right': sprite.x += moveSpeed; sprite.opacity += opacitySpeed; break;
        case 'zoom_fade':
            sprite.opacity += opacitySpeed;
            let zoomScale = 1.2 - (0.2 * progress);
            sprite.scale.x = sprite.targetScaleX * zoomScale;
            sprite.scale.y = sprite.targetScaleY * zoomScale;
            sprite.x = sprite.targetX - (sprite.baseFrameW * sprite.targetScaleX * (zoomScale - 1) / 2);
            sprite.y = sprite.targetY - (sprite.baseFrameH * sprite.targetScaleY * (zoomScale - 1) / 2);
            break;
        case 'drop_in':
            sprite.opacity += opacitySpeed;
            sprite.scale.x = sprite.targetScaleX * progress;
            sprite.scale.y = sprite.targetScaleY * progress;
            sprite.x = sprite.targetX + (sprite.baseFrameW * sprite.targetScaleX * (1 - progress) / 2);
            sprite.y = sprite.targetY + (sprite.baseFrameH * sprite.targetScaleY * (1 - progress) / 2);
            break;
        case 'overshoot':
            sprite.opacity += opacitySpeed;
            let oScale;
            if (progress < 0.7) {
                oScale = (progress / 0.7) * 1.15;
            } else {
                oScale = 1.15 - ((progress - 0.7) / 0.3) * 0.15;
            }
            sprite.scale.x = sprite.targetScaleX * oScale;
            sprite.scale.y = sprite.targetScaleY * oScale;
            sprite.x = sprite.targetX + (sprite.baseFrameW * sprite.targetScaleX * (1 - oScale) / 2);
            sprite.y = sprite.targetY + (sprite.baseFrameH * sprite.targetScaleY * (1 - oScale) / 2);
            break;
        case 'tilt_settle':
            sprite.opacity += opacitySpeed;
            sprite.rotation = 0.2 * (1 - progress);
            break;
        case 'neon_flicker':
            sprite.opacity = Math.random() > 0.5 ? maxOpacity : 0;
            break;
        case 'wipe_right':
            if (sprite.baseFrameW > 0) sprite.setFrame(0, 0, sprite.baseFrameW * progress, sprite.baseFrameH);
            break;
        case 'wipe_left':
            if (sprite.baseFrameW > 0) {
                let wProg = sprite.baseFrameW * progress;
                sprite.setFrame(sprite.baseFrameW - wProg, 0, wProg, sprite.baseFrameH);
                sprite.x = sprite.targetX + ((sprite.baseFrameW - wProg) * sprite.targetScaleX);
            }
            break;
        case 'wipe_down':
            if (sprite.baseFrameW > 0) {
                sprite.setFrame(0, 0, sprite.baseFrameW, sprite.baseFrameH * progress);
            }
            break;
        case 'wipe_up':
            if (sprite.baseFrameW > 0) {
                let hProg = sprite.baseFrameH * progress;
                sprite.setFrame(0, sprite.baseFrameH - hProg, sprite.baseFrameW, hProg);
                sprite.y = sprite.targetY + ((sprite.baseFrameH - hProg) * sprite.targetScaleY);
            }
            break;
    }
    
    if (currentTimer <= 0) {
        sprite.x = sprite.targetX;
        sprite.y = sprite.targetY;
        sprite.rotation = 0;
        sprite.opacity = maxOpacity;
        if (sprite.targetScaleX !== undefined) {
            sprite.scale.x = sprite.targetScaleX;
            sprite.scale.y = sprite.targetScaleY;
        }
        if (sprite.baseFrameW > 0 && type.includes('wipe')) {
            sprite.setFrame(0, 0, sprite.baseFrameW, sprite.baseFrameH);
        }
    }
};

const _Scene_Title_start = Scene_Title.prototype.start;
Scene_Title.prototype.start = function() {
    _Scene_Title_start.call(this);
    if (this._jrLayers && this._jrLayers.length > 0) {
        this._jrLayers[0].startSequence();
    }
};

const _Scene_Title_update = Scene_Title.prototype.update;
Scene_Title.prototype.update = function() {
    _Scene_Title_update.call(this);
    
    let isMogIntroActive = false;
    if (Imported.MOG_Picture_Command && this._introPhase !== undefined && this._introPhase < 2) {
        isMogIntroActive = true;
    }
    
    // ----- JR Title & Subtitle Logic -----
    if (!this._jrTitlesTriggered) {
        if (this._jrLayers.length === 0) {
            this._jrTitlesTriggered = true;
        } else if (JR.TitleLayers.titlesOnLastLayer) {
            if (this._currentLayerIndex >= this._jrLayers.length - 1) {
                if (this._jrLayers[this._jrLayers.length - 1] && this._jrLayers[this._jrLayers.length - 1]._isPlaying) {
                    this._jrTitlesTriggered = true;
                }
            }
        } else {
            let targetIndex = Math.max(0, JR.TitleLayers.titleStartLayer - 1);
            if (targetIndex >= this._jrLayers.length) targetIndex = this._jrLayers.length - 1;
            
            if (this._currentLayerIndex >= targetIndex) {
                if (this._jrLayers[this._currentLayerIndex] && this._jrLayers[this._currentLayerIndex]._isPlaying) {
                    this._jrTitlesTriggered = true;
                }
            }
        }
    }
    
    if (this._jrTitlesTriggered) {
        let tReady = !JR.TitleLayers.titleImage || (this._jrTitleSprite.bitmap && this._jrTitleSprite.bitmap.isReady());
        let sReady = !JR.TitleLayers.subImage || (this._jrSubtitleSprite.bitmap && this._jrSubtitleSprite.bitmap.isReady());
        
        if (tReady && sReady) {
            if (!this._jrTitlesCoordsParsed) {
                if (JR.TitleLayers.titleImage) {
                    this._jrTitleSprite.targetX = this.parseJRTitleCoord(JR.TitleLayers.titleX);
                    this._jrTitleSprite.targetY = this.parseJRTitleCoord(JR.TitleLayers.titleY);
                    this._jrTitleSprite.x = this._jrTitleSprite.targetX;
                    this._jrTitleSprite.y = this._jrTitleSprite.targetY;
                }
                if (JR.TitleLayers.subImage) {
                    this._jrSubtitleSprite.targetX = this.parseJRTitleCoord(JR.TitleLayers.subX);
                    this._jrSubtitleSprite.targetY = this.parseJRTitleCoord(JR.TitleLayers.subY);
                    this._jrSubtitleSprite.x = this._jrSubtitleSprite.targetX;
                    this._jrSubtitleSprite.y = this._jrSubtitleSprite.targetY;
                }
                
                this._jrTitlesCoordsParsed = true;
                this._jrTitleDelayTimer = Math.floor(JR.TitleLayers.titleDelay * 60);
                
                if (!JR.TitleLayers.titleImage) {
                    this._jrTitlePhase = 2;
                    this._jrSubtitleDelayTimer = Math.floor(JR.TitleLayers.subWait * 60);
                }
            } else {
                if (this._jrTitlePhase === 0) {
                     if (this._jrTitleDelayTimer > 0) this._jrTitleDelayTimer--;
                     if (this._jrTitleDelayTimer <= 0) {
                          this._jrTitlePhase = 1; 
                          this._jrTitleTransTimer = JR.TitleLayers.titleTransTime;
                          this.setupJRTitleTransitionStart(this._jrTitleSprite, JR.TitleLayers.titleTransType, JR.TitleLayers.titleOpacity, JR.TitleLayers.titleScale);
                     }
                } else if (this._jrTitlePhase === 1) {
                     if (this._jrTitleTransTimer > 0) {
                         this._jrTitleTransTimer--;
                         this.updateJRTitleTransition(this._jrTitleSprite, JR.TitleLayers.titleTransType, JR.TitleLayers.titleTransTime, this._jrTitleTransTimer, JR.TitleLayers.titleOpacity);
                     }
                     if (this._jrTitleTransTimer <= 0) {
                         this._jrTitlePhase = 2;
                         this._jrSubtitleDelayTimer = Math.floor(JR.TitleLayers.subWait * 60);
                         if (!JR.TitleLayers.subImage) this._jrTitlePhase = 4;
                     }
                } else if (this._jrTitlePhase === 2) {
                     if (this._jrSubtitleDelayTimer > 0) this._jrSubtitleDelayTimer--;
                     if (this._jrSubtitleDelayTimer <= 0) {
                          this._jrTitlePhase = 3;
                          this._jrSubTransTimer = JR.TitleLayers.subTransTime;
                          this.setupJRTitleTransitionStart(this._jrSubtitleSprite, JR.TitleLayers.subTransType, JR.TitleLayers.subOpacity, JR.TitleLayers.subScale);
                     }
                } else if (this._jrTitlePhase === 3) {
                     if (this._jrSubTransTimer > 0) {
                         this._jrSubTransTimer--;
                         this.updateJRTitleTransition(this._jrSubtitleSprite, JR.TitleLayers.subTransType, JR.TitleLayers.subTransTime, this._jrSubTransTimer, JR.TitleLayers.subOpacity);
                     }
                     if (this._jrSubTransTimer <= 0) {
                         this._jrTitlePhase = 4;
                     }
                }
            }
        }
    }
    
    // --- Safe Mathematical Idle Animations ---
    if (this._jrTitlePhase === 4) {
        this._jrIdleTimer++;
        
        if (JR.TitleLayers.titleImage) {
            let tFloat = JR.TitleLayers.tIdleFloat ? Math.sin(this._jrIdleTimer * 0.03) * 8 : 0;
            let tPulse = JR.TitleLayers.tIdlePulse ? Math.sin(this._jrIdleTimer * 0.04) * 0.03 : 0;
            let tSway  = JR.TitleLayers.tIdleSway  ? Math.sin(this._jrIdleTimer * 0.02) * 0.03 : 0;
            let tFade  = JR.TitleLayers.tIdleFade  ? (Math.sin(this._jrIdleTimer * 0.05) * 40) : 0;
            
            this._jrTitleSprite.y = this._jrTitleSprite.targetY + tFloat;
            this._jrTitleSprite.scale.x = this._jrTitleSprite.targetScaleX + tPulse;
            this._jrTitleSprite.scale.y = this._jrTitleSprite.targetScaleY + tPulse;
            this._jrTitleSprite.rotation = tSway;
            this._jrTitleSprite.opacity = JR.TitleLayers.titleOpacity - (JR.TitleLayers.tIdleFade ? 40 : 0) + tFade;
        }
        
        if (JR.TitleLayers.subImage) {
            let sFloat = JR.TitleLayers.sIdleFloat ? Math.sin(this._jrIdleTimer * 0.035) * 8 : 0;
            let sPulse = JR.TitleLayers.sIdlePulse ? Math.sin(this._jrIdleTimer * 0.045) * 0.03 : 0;
            let sSway  = JR.TitleLayers.sIdleSway  ? Math.sin(this._jrIdleTimer * 0.025) * 0.03 : 0;
            let sFade  = JR.TitleLayers.sIdleFade  ? (Math.sin(this._jrIdleTimer * 0.055) * 40) : 0;
            
            this._jrSubtitleSprite.y = this._jrSubtitleSprite.targetY + sFloat;
            this._jrSubtitleSprite.scale.x = this._jrSubtitleSprite.targetScaleX + sPulse;
            this._jrSubtitleSprite.scale.y = this._jrSubtitleSprite.targetScaleY + sPulse;
            this._jrSubtitleSprite.rotation = sSway;
            this._jrSubtitleSprite.opacity = JR.TitleLayers.subOpacity - (JR.TitleLayers.sIdleFade ? 40 : 0) + sFade;
        }
    }
    // ----- End Titles Logic -----
    
    if (this._jrSkipTextSprite) {
        if (!isMogIntroActive && this._currentLayerIndex < this._jrLayers.length - 1) {
            this._jrSkipTextSprite.visible = true;
            if (this._jrSkipTextSprite.opacity < JR.TitleLayers.skipTextOpacity) {
                this._jrSkipTextSprite.opacity += 5; 
            }
        } else {
            if (this._jrSkipTextSprite.opacity > 0) {
                this._jrSkipTextSprite.opacity -= 5;
            } else {
                this._jrSkipTextSprite.visible = false;
            }
        }
    }
    
    if (this._jrLayers && this._currentLayerIndex < this._jrLayers.length) {
        const currentLayer = this._jrLayers[this._currentLayerIndex];
        
        if (JR.TitleLayers.clickToSkip && !isMogIntroActive) {
            let wantsToSkip = false;
            
            if (Input.isTriggered('pageup') || Input.isTriggered('pagedown')) {
                wantsToSkip = true;
            }
            
            if (TouchInput.isTriggered()) {
                let clickedOnWindow = false;
                if (this._commandWindow && this._commandWindow.visible && this._commandWindow.isOpen()) {
                    const cw = this._commandWindow;
                    if (TouchInput.x >= cw.x && TouchInput.x <= cw.x + cw.width &&
                        TouchInput.y >= cw.y && TouchInput.y <= cw.y + cw.height) {
                        clickedOnWindow = true;
                    }
                }
                
                if (Imported.MOG_Picture_Command && this._com_pictures_data) {
                    for (let i = 0; i < this._com_pictures_data.length; i++) {
                        let data = this._com_pictures_data[i];
                        if (data && TouchInput.x >= data[0] && TouchInput.x <= data[0] + data[1] &&
                            TouchInput.y >= data[2] && TouchInput.y <= data[2] + data[3]) {
                            clickedOnWindow = true;
                            break;
                        }
                    }
                }
                
                if (!clickedOnWindow) {
                    wantsToSkip = true;
                }
            }
            
            if (wantsToSkip) {
                currentLayer.skipToTransitionOut();
            }
        }
        
        if (currentLayer.hasFinishedTransitionIn()) {
            for (let i = 0; i < this._currentLayerIndex; i++) {
                if (this._jrLayers[i]._shouldRetire && !this._jrLayers[i]._isRetired) {
                    this._jrLayers[i].retireLayer();
                    this._jrLayers[i]._isRetired = true;
                }
            }
        }
        
        if (currentLayer.isFinished()) {
            if (!currentLayer._cleanedUp) {
                currentLayer.cleanupVideo();
            }
            
            if (this._currentLayerIndex < this._jrLayers.length - 1) {
                this._currentLayerIndex++;
                this._jrLayers[this._currentLayerIndex].startSequence();
            } else {
                this._currentLayerIndex++;
            }
        }
    }
};

//=============================================================================
// Sprite_JRTitleLayer
//=============================================================================

function Sprite_JRTitleLayer() {
    this.initialize.apply(this, arguments);
}

Sprite_JRTitleLayer.prototype = Object.create(Sprite.prototype);
Sprite_JRTitleLayer.prototype.constructor = Sprite_JRTitleLayer;

Sprite_JRTitleLayer.prototype.initialize = function(data, index, isLastLayer, parentScene) {
    Sprite.prototype.initialize.call(this);
    this._data = data || {};
    this._layerId = index;
    this._isLastLayer = !!isLastLayer;
    this._parentScene = parentScene;
    
    this._isPlaying = false;
    this._isFinished = false;
    this._isRetired = false;
    this._shouldRetire = String(this._data['Retire Layer']).trim().toLowerCase() !== 'false';
    
    this._videoReady = false;
    this._videoEnded = false;
    this._cleanedUp = false;
    
    this._videoFile = String(this._data['Video File'] || '').trim();
    this._imageFile = String(this._data['Image File'] || '').trim();
    this._useVideo = this._videoFile.length > 0;
    this._videoWithSound = String(this._data['Video With Sound']).trim().toLowerCase() === 'true';
    
    if (!this._useVideo && this._imageFile) {
        if (this._parentScene && this._parentScene.loadProtectedJRImage) {
            this.bitmap = this._parentScene.loadProtectedJRImage(this._imageFile, 'title1');
        } else {
            this.bitmap = ImageManager.loadTitle1(this._imageFile);
        }
    }
    
    this._transType = String(this._data['Transition Type'] || 'fade');
    this._transTime = Number(this._data['Transition Time']) >= 0 ? Number(this._data['Transition Time']) : 60;
    this._transTimer = 0;
    
    this._waitTime = Number(this._data['Wait Time']) >= 0 ? Number(this._data['Wait Time']) : 120;
    this._waitTimer = 0;
    
    this._transOutType = String(this._data['Transition Out Type'] || 'none');
    this._transOutTime = Number(this._data['Transition Out Time']) >= 0 ? Number(this._data['Transition Out Time']) : 60;
    this._transOutTimer = 0;
    this._isTransitioningOut = false;
    
    this.setupCoordinates();
};

Sprite_JRTitleLayer.prototype.setupCoordinates = function() {
    const parseCoord = (coordStr) => {
        if (!coordStr) return 0;
        let parsedStr = String(coordStr).replace(/windowWidth/gi, Graphics.boxWidth)
                                        .replace(/windowHeight/gi, Graphics.boxHeight);
        try { 
            let val = eval(parsedStr);
            return isNaN(val) ? 0 : val;
        } catch (e) { 
            return 0; 
        }
    };
    this._targetX = parseCoord(this._data['X'] || '0');
    this._targetY = parseCoord(this._data['Y'] || '0');
};

Sprite_JRTitleLayer.prototype.startSequence = function() {
    this.visible = true;
    this._isPlaying = true;
    this._transTimer = this._transTime;
    this._waitTimer = this._waitTime;
    
    if (this._useVideo) {
        this.startVideo();
    } else if (this._imageFile) {
        if (this._parentScene && this._parentScene.loadProtectedJRImage) {
            this.bitmap = this._parentScene.loadProtectedJRImage(this._imageFile, 'title1');
        } else {
            this.bitmap = ImageManager.loadTitle1(this._imageFile);
        }
    }
    
    this.applyTransitionStart();
};

Sprite_JRTitleLayer.prototype.startVideo = function() {
    if (!JR.TitleLayers.checkFileExists('movies', this._videoFile, true)) {
        console.warn(`JR Title Layers: Blocked hang! Missing video safely bypassed -> movies/${this._videoFile}`);
        this._videoEnded = true; 
        return;
    }
    
    const ext = Graphics._videoExt || (Graphics.canPlayVideoType('video/webm') ? '.webm' : '.mp4');
    const path = 'movies/' + this._videoFile + ext;
    
    this._video = document.createElement('video');
    this._video.src = path;
    this._video.muted = !this._videoWithSound;
    
    this._video.loop = false;
    this._video.playsInline = true;
    
    this._video.onerror = () => {
        console.warn(`JR Title Layers: Browser fallback engaged for missing video -> ${this._videoFile}`);
        this._videoEnded = true; 
    };
    
    this._video.onended = () => {
        if (this._isLastLayer && JR.TitleLayers.lastLayerVideoLoop) {
            this._video.currentTime = 0;
            let playPromise = this._video.play();
            if (playPromise !== undefined) {
                playPromise.catch(e => { this._videoEnded = true; });
            }
        } else {
            this._videoEnded = true; 
        }
    };
    
    const texture = PIXI.Texture.fromVideo(this._video);
    this.texture = texture;
    
    this._video.load();
    let playPromise = this._video.play();
    
    if (playPromise !== undefined) {
        playPromise.catch(e => {
            console.warn(`Layer ${this._layerId} blocked or missing. Reason:`, e.name);
            if (e.name === 'NotAllowedError' && !this._video.muted) {
                this._video.muted = true;
                this._video.play().catch(e2 => { this._videoEnded = true; });
            } else {
                this._videoEnded = true; 
            }
        });
    }
};

Sprite_JRTitleLayer.prototype.cleanupVideo = function() {
    if (!this._useVideo || !this._video || this._cleanedUp) return;
    
    try {
        const canvas = document.createElement('canvas');
        canvas.width = this._video.videoWidth || Graphics.boxWidth;
        canvas.height = this._video.videoHeight || Graphics.boxHeight;
        const ctx = canvas.getContext('2d');
        
        ctx.drawImage(this._video, 0, 0, canvas.width, canvas.height);
        
        const oldVideoTexture = this.texture;
        
        const snapTexture = PIXI.Texture.fromCanvas(canvas);
        this.texture = snapTexture;
        
        this._video.pause();
        this._video.removeAttribute('src');
        this._video.load(); 
        this._video = null;
        
        if (oldVideoTexture && oldVideoTexture !== PIXI.Texture.EMPTY) {
            oldVideoTexture.destroy(true);
        }
        
        this._cleanedUp = true;
    } catch (e) {
        console.warn(`Layer ${this._layerId} memory wipe failed.`, e);
    }
};

Sprite_JRTitleLayer.prototype.retireLayer = function() {
    this.visible = false;
    
    if (this._useVideo) {
        if (this.texture && this.texture !== PIXI.Texture.EMPTY) {
            this.texture.destroy(true);
            this.texture = PIXI.Texture.EMPTY;
        }
    } else {
        this.bitmap = null;
    }
};

Sprite_JRTitleLayer.prototype.hasFinishedTransitionIn = function() {
    if (!this._isPlaying) return false;
    if (!this._useVideo && this.bitmap && !this.bitmap.isReady()) return false;
    if (this._useVideo && !this._videoReady) return false;
    return this._transTimer <= 0;
};

Sprite_JRTitleLayer.prototype.applyTransitionStart = function() {
    this.x = this._targetX;
    this.y = this._targetY;
    
    if (this._transTime <= 0 || this._transType === 'none') {
        this.opacity = 255;
        return;
    }
    
    const offset = 200; 
    
    switch(this._transType) {
        case 'fade': this.opacity = 0; break;
        case 'slide_up': this.y = this._targetY + offset; this.opacity = 0; break;
        case 'slide_down': this.y = this._targetY - offset; this.opacity = 0; break;
        case 'slide_left': this.x = this._targetX + offset; this.opacity = 0; break;
        case 'slide_right': this.x = this._targetX - offset; this.opacity = 0; break;
    }
};

Sprite_JRTitleLayer.prototype.skipToTransitionOut = function() {
    if (!this._isPlaying || this._isFinished || this._isTransitioningOut) return;
    
    if (this._isLastLayer && this._transTimer <= 0) return;
    
    if (this._transTimer > 0) {
        this._transTimer = 0;
        this.x = this._targetX;
        this.y = this._targetY;
        this.opacity = 255;
    }
    
    if (!this._isLastLayer) {
        this.startTransitionOut();
    }
};

Sprite_JRTitleLayer.prototype.startTransitionOut = function() {
    if (this._useVideo && !this._cleanedUp) {
        this.cleanupVideo();
    }
    
    if (this._transOutTime <= 0 || this._transOutType === 'none') {
        this._isFinished = true;
        return;
    }
    
    this._isTransitioningOut = true;
    this._transOutTimer = this._transOutTime;
};

Sprite_JRTitleLayer.prototype.update = function() {
    Sprite.prototype.update.call(this);
    if (!this._isPlaying || this._isFinished) return;
    
    if (!this._useVideo && this.bitmap && !this.bitmap.isReady()) {
        return;
    }
    
    if (this._useVideo && this.texture && !this._cleanedUp) {
        this.texture.update();
        if (!this._videoReady && this.texture.baseTexture && this.texture.baseTexture.width > 0) {
            this._videoReady = true;
            this.setFrame(0, 0, this.texture.baseTexture.width, this.texture.baseTexture.height);
        }
    }
    
    if (this._transTimer > 0) {
        this._transTimer--;
        this.updateTransitionIn();
    } 
    else if (this._isTransitioningOut) {
        this._transOutTimer--;
        this.updateTransitionOut();
        if (this._transOutTimer <= 0) {
            this._isFinished = true;
        }
    } 
    else {
        if (!this._useVideo) {
            if (this._waitTimer > 0) {
                this._waitTimer--;
            } else {
                this.startTransitionOut();
            }
        } else {
            if (this._videoEnded) {
                this.startTransitionOut();
            }
        }
    }
};

Sprite_JRTitleLayer.prototype.updateTransitionIn = function() {
    if (this._transTime <= 0) return;
    
    const opacitySpeed = 255 / this._transTime;
    const moveSpeed = 200 / this._transTime; 
    
    switch(this._transType) {
        case 'fade': this.opacity += opacitySpeed; break;
        case 'slide_up': this.y -= moveSpeed; this.opacity += opacitySpeed; break;
        case 'slide_down': this.y += moveSpeed; this.opacity += opacitySpeed; break;
        case 'slide_left': this.x -= moveSpeed; this.opacity += opacitySpeed; break;
        case 'slide_right': this.x += moveSpeed; this.opacity += opacitySpeed; break;
    }
    
    if (this._transTimer <= 0) {
        this.x = this._targetX;
        this.y = this._targetY;
        this.opacity = 255;
    }
};

Sprite_JRTitleLayer.prototype.updateTransitionOut = function() {
    if (this._transOutTime <= 0) return;
    
    const opacitySpeed = 255 / this._transOutTime;
    const moveSpeed = 200 / this._transOutTime; 
    
    switch(this._transOutType) {
        case 'fade': this.opacity -= opacitySpeed; break;
        case 'slide_up': this.y -= moveSpeed; this.opacity -= opacitySpeed; break;
        case 'slide_down': this.y += moveSpeed; this.opacity -= opacitySpeed; break;
        case 'slide_left': this.x -= moveSpeed; this.opacity -= opacitySpeed; break;
        case 'slide_right': this.x += moveSpeed; this.opacity -= opacitySpeed; break;
    }
};

Sprite_JRTitleLayer.prototype.isFinished = function() {
    return this._isFinished;
};