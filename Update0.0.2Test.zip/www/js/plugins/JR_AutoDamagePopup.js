//=============================================================================
// JR_AutoDamagePopup.js
//=============================================================================
/*:
 * @plugindesc v1.87 Automatic HP/MP/TP popups, labels, states and custom text.
 * @author JR
 *
 * @param HP Loss Color
 * @default #ff7070
 *
 * @param HP Loss Animation
 * @type select
 * @option bounce
 * @option rise
 * @option fall
 * @option zoom
 * @option slide
 * @option still
 * @default bounce
 *
 * @param HP Gain Color
 * @default #70ef98
 *
 * @param HP Gain Animation
 * @type select
 * @option bounce
 * @option rise
 * @option fall
 * @option zoom
 * @option slide
 * @option still
 * @default rise
 *
 * @param MP Loss Color
 * @default #72b8ff
 *
 * @param MP Loss Animation
 * @type select
 * @option bounce
 * @option rise
 * @option fall
 * @option zoom
 * @option slide
 * @option still
 * @default bounce
 *
 * @param MP Gain Color
 * @default #65e1f0
 *
 * @param MP Gain Animation
 * @type select
 * @option bounce
 * @option rise
 * @option fall
 * @option zoom
 * @option slide
 * @option still
 * @default rise
 *
 * @param TP Loss Color
 * @default #ffc66b
 *
 * @param TP Loss Animation
 * @type select
 * @option bounce
 * @option rise
 * @option fall
 * @option zoom
 * @option slide
 * @option still
 * @default bounce
 *
 * @param TP Gain Color
 * @default #c6ef70
 *
 * @param TP Gain Animation
 * @type select
 * @option bounce
 * @option rise
 * @option fall
 * @option zoom
 * @option slide
 * @option still
 * @default rise
 *
 * @param Physical Damage Color
 * @type string
 * @desc Attack/skill HP or MP loss color. Blank = use resource loss color.
 * @default
 *
 * @param Magical Damage Color
 * @type string
 * @desc Attack/skill HP or MP loss color. Blank = use resource loss color.
 * @default
 *
 * @param Certain Hit Damage Color
 * @type string
 * @desc Attack/skill HP or MP loss color. Blank = use resource loss color.
 * @default
 *
 * @param Physical Damage Outline Color
 * @type string
 * @desc Physical HP/MP damage outline. Blank = use Outline Color.
 * @default
 *
 * @param Magical Damage Outline Color
 * @type string
 * @desc Magical HP/MP damage outline. Blank = use Outline Color.
 * @default
 *
 * @param Certain Hit Damage Outline Color
 * @type string
 * @desc Certain Hit HP/MP damage outline. Blank = use Outline Color.
 * @default
 *
 * @param Certain Hit Damage Animation
 * @type select
 * @option Use Resource Animation
 * @value resource
 * @option impact
 * @option burst
 * @option recoil
 * @option spiral
 * @option bounce
 * @option rise
 * @option fall
 * @option zoom
 * @option slide
 * @option still
 * @desc Override Certain Hit HP/MP damage values only; independent of color.
 * @default resource
 *
 * @param Miss Height
 * @type number
 * @min -2000
 * @max 2000
 * @desc Extra height above the normal popup origin. Positive = higher.
 * @default 36
 *
 * @param Evade Height
 * @type number
 * @min -2000
 * @max 2000
 * @desc Extra height above the normal popup origin. Positive = higher.
 * @default 36
 *
 * @param Critical Text
 * @desc Leave blank to disable this label.
 * @default Critical!
 *
 * @param Critical Color
 * @default #ffcf55
 *
 * @param Critical Animation
 * @type select
 * @option impact
 * @option burst
 * @option recoil
 * @option spiral
 * @option bounce
 * @option rise
 * @option fall
 * @option zoom
 * @option slide
 * @option still
 * @default impact
 *
 * @param Resist Text
 * @desc Leave blank to disable this label.
 * @default Resist!
 *
 * @param Resist Color
 * @default #a6b8d6
 *
 * @param Resist Animation
 * @type select
 * @option impact
 * @option burst
 * @option recoil
 * @option spiral
 * @option bounce
 * @option rise
 * @option fall
 * @option zoom
 * @option slide
 * @option still
 * @default recoil
 *
 * @param Weakness Text
 * @desc Leave blank to disable this label.
 * @default Weakness!
 *
 * @param Weakness Color
 * @default #ff9360
 *
 * @param Weakness Animation
 * @type select
 * @option impact
 * @option burst
 * @option recoil
 * @option spiral
 * @option bounce
 * @option rise
 * @option fall
 * @option zoom
 * @option slide
 * @option still
 * @default burst
 *
 * @param Absorb Text
 * @desc Leave blank to disable this label.
 * @default Absorb!
 *
 * @param Absorb Color
 * @default #91efc4
 *
 * @param Absorb Animation
 * @type select
 * @option impact
 * @option burst
 * @option recoil
 * @option spiral
 * @option bounce
 * @option rise
 * @option fall
 * @option zoom
 * @option slide
 * @option still
 * @default spiral
 *
 * @param Barrier Damage Color
 * @type string
 * @desc auto = YEP Barrier Color 1. Or enter a CSS color such as #cc88ff.
 * @default auto
 *
 * @param Barrier Damage Animation
 * @type select
 * @option bounce
 * @option rise
 * @option zoom
 * @option impact
 * @option still
 * @default bounce
 *
 * @param Barrier Damage Text
 * @desc Resource suffix when Show Resource Labels is enabled.
 * @default Barrier
 *
 * @param Split Number Gap
 * @type number
 * @min 0
 * @desc Horizontal gap between barrier and HP amounts on split hits.
 * @default 12
 *
 * @param State Group 1 Categories
 * @type string
 * @desc Comma-separated YEP categories. Blank disables this group.
 * @default Positive
 *
 * @param State Group 1 Color
 * @type string
 * @default #80ed9c
 *
 * @param State Group 1 Text Size
 * @type number
 * @min 8
 * @default 24
 *
 * @param State Group 2 Categories
 * @type string
 * @desc Comma-separated YEP categories. Blank disables this group.
 * @default Negative, Poison, Sleep
 *
 * @param State Group 2 Color
 * @type string
 * @default #ff8585
 *
 * @param State Group 2 Text Size
 * @type number
 * @min 8
 * @default 24
 *
 * @param State Group 3 Categories
 * @type string
 * @desc Comma-separated YEP categories. Blank disables this group.
 * @default Neutral
 *
 * @param State Group 3 Color
 * @type string
 * @default #91caff
 *
 * @param State Group 3 Text Size
 * @type number
 * @min 8
 * @default 24
 *
 * @param Show State Plus Sign
 * @type boolean
 * @desc Prefix newly applied state names with +, for example +Poison.
 * @default false
 *
 * @param State Popup Animation
 * @type select
 * @option rise
 * @option bounce
 * @option zoom
 * @option still
 * @option burst
 * @option spiral
 * @default rise
 *
 * @param State Popup Duration
 * @type number
 * @min 12
 * @desc Frames for each state-name notice. 60 is about one second.
 * @default 60
 *
 * @param State Popup Offset X
 * @type number
 * @min -2000
 * @max 2000
 * @desc Signed offset from damage center. Negative = left; positive = right.
 * @default 0
 *
 * @param State Popup Offset Y
 * @type number
 * @min -2000
 * @max 2000
 * @desc Signed offset below damage, added to State Popup Gap.
 * @default 0
 *
 * @param State Popup Gap
 * @type number
 * @min -2000
 * @max 2000
 * @desc Pixels between damage bottom and state top. Larger = lower.
 * @default 5
 *
 * @param Push Previous States Up
 * @type boolean
 * @desc New state names push older names up within the same hit. False = compact downward rows.
 * @default false
 *
 * @param State Popup Row Gap
 * @type number
 * @min 0
 * @desc Empty pixels between visible state names. 0 = no extra blank row.
 * @default 6
 *
 * @param Head Gap
 * @type number
 * @min -1000
 * @desc Pixels above the top-center of the battler frame.
 * @default 0
 *
 * @param Label Gap
 * @type number
 * @min 0
 * @desc Empty pixels between the number top and label bottom.
 * @default 4
 *
 * @param Label Fan Gap
 * @type number
 * @min 0
 * @desc Horizontal opening between simultaneous labels.
 * @default 8
 *
 * @param Label Fan Travel
 * @type number
 * @min 0
 * @desc Extra outward movement. Keep small for a compact hit group.
 * @default 8
 *
 * @param Label Font Size
 * @type number
 * @default 30
 *
 * @param Label Duration
 * @type number
 * @desc Label duration. A hit group uses the longest member duration.
 * @default 45
 *
 * @param Default Color
 * @type string
 * @desc Default custom-text and miss/evade color.
 * @default #ffffff
 *
 * @param Default Animation
 * @type string
 * @desc bounce, rise, fall, zoom, slide or still.
 * @default rise
 *
 * @param Font Face
 * @type string
 * @desc Use a font already loaded by your game.
 * @default GameFont
 *
 * @param Font Size
 * @type number
 * @desc Default number and custom-text size in pixels.
 * @default 28
 *
 * @param Outline Color
 * @type string
 * @desc Text outline color.
 * @default rgba(0,0,0,0.85)
 *
 * @param Outline Width
 * @type number
 * @desc Outline thickness in pixels.
 * @default 4
 *
 * @param Duration
 * @type number
 * @desc Popup lifetime in frames; 60 frames is about one second.
 * @default 60
 *
 * @param Damage Popup Animation Speed
 * @type number
 * @decimals 2
 * @min 0.1
 * @max 10
 * @desc 1 = current speed; 2 = twice as fast; 0.5 = half speed.
 * @default 1
 *
 * @param Show Full HP Amount
 * @type boolean
 * @desc True = HP amount before HP limits. False = actual HP change.
 * @default false
 *
 * @param Show 0 damage
 * @type boolean
 * @desc Show zero HP/MP attack/skill damage only. Ignore routine zero gains.
 * @default false
 *
 * @param Queue Interval
 * @type number
 * @desc 0 = wait for previous hit group. Positive = frames between groups.
 * @default 0
 *
 * @param Push Previous Popups Up
 * @type boolean
 * @desc Keep newest hit at its origin; push older groups upward. False = old behavior.
 * @default false
 *
 * @param Popup Push Duration
 * @type number
 * @min 0
 * @max 120
 * @desc Smoothing frames for damage/state pushes (about 99% settled). 0 = instant.
 * @default 12
 *
 * @param Popup Push Gap
 * @type number
 * @min 0
 * @desc Target empty pixels between pushed groups, including labels and attached states.
 * @default 8
 *
 * @param Damage Popup Gap
 * @type number
 * @min 0
 * @desc Extra upward pixels per overlapping hit group. 0 = no displacement.
 * @default 0
 *
 * @param Show Value Signs
 * @type boolean
 * @desc Show + for gains and - for losses, including barrier damage.
 * @default true
 *
 * @param Show Resource Labels
 * @type boolean
 * @desc Show HP/MP/TP next to automatic numbers.
 * @default true
 *
 * @param Default Offset X
 * @type number
 * @min -2000
 * @max 2000
 * @desc All popups: signed X offset. Script arguments override this default.
 * @default 0
 *
 * @param Default Offset Y
 * @type number
 * @min -2000
 * @max 2000
 * @desc All popups: signed Y offset. Script arguments override this default.
 * @default 0
 *
 * @help
 * Save as JR_AutoDamagePopup.js. Author: JR. Replace the entire older file.
 * Requires YEP_BattleEngineCore. Place BELOW your YEP battle plugins,
 * YEP_ElementCore, YEP_AbsorptionBarrier, YEP_X_StateCategories and
 * JR_GainHpExtensions. Do not combine with other popup replacements.
 *
 * OPTIMIZATION
 * Origin cached per battler per spriteset update; exact text bounds cached
 * with a 256-entry limit, storing metadata only. Layout and motion work
 * objects are reused. Layout runs once after child updates.
 * Expired sprites are removed after child traversal to avoid skipping
 * siblings during live child-array updates.
 *
 * NUMBERS AND LABELS
 * Automatically displays gainHp/gainMp/gainTp in battle.
 * Critical and elemental labels appear with their value. Negative element
 * rate = Absorb; below 1 = Resist; above 1 = Weakness. Recovery gets no
 * elemental label. Animations affect popup sprites only, never the screen.
 * Hit-type color/outline overrides are disabled when blank. Certain Hit
 * Damage Animation affects attack/skill HP/MP damage values only.
 * Barrier damage retains its own color; auto uses YEP Barrier Color 1.
 * Split hits display barrier and HP portions together.
 * Show Full HP Amount displays the processed amount before HP clamping.
 * MP/TP still show actual change. Damage calculations remain unchanged.
 * Show 0 damage only authorizes confirmed zero HP/MP damaging actions.
 * Routine zero gains, regeneration and unclassified native zeros are ignored.
 *
 * POSITION AND QUEUES
 * X positive = right; negative = left. Y positive = down; negative = up.
 * At default 0,0 visible text sits above the battler artwork top.
 * Head Gap adds upward clearance. Miss/Evade Height are extra upward offsets.
 * Queue Interval 0 waits until the previous damage group finishes.
 * Positive values allow overlapping groups. Animation Speed scales lifetime,
 * travel and fade together. It does not scale Queue Interval or state duration.
 * Push Previous Popups Up false uses the old Damage Popup Gap placement.
 * True keeps new groups at their origin and pushes older groups upward.
 * Popup Push Gap sets target empty space between whole hit groups.
 * Popup Push Duration defaults to 12 frames (about 99% settled).
 * Higher = slower; 0 = instant. Brief overlap can occur during a slide.
 * Numbers, labels and attached states move together; no downward snapping.
 *
 * STATES
 * Three groups match comma-separated YEP state category names, ignoring case.
 * First matching group wins. Unmatched states are hidden.
 * Newly applied states show on the next rendered frame, independently
 * of the damage queue. State-only skills work. Refreshes/removals do not show.
 * State X/Y 0,0 places the first name below damage with State Popup Gap 5.
 * Larger gap = lower. Signed offsets and negative gap are supported.
 * State Popup Row Gap is empty space between visible names; 0 is compact.
 * Push Previous States Up false uses downward rows; true pushes older names
 * upward within their attached hit. Associated values/labels rise for space.
 * Unattached state-only notices share a standalone stack for that battler.
 * Same-frame states start in separate rows; later ones slide older names.
 * Show State Plus Sign adds + independently of resource-number signs.
 *
 * SCRIPT
 * battler.jrCustomDamagePopup('Resist!');
 * battler.jrCustomDamagePopup('Poison', '#b985ff', 'rise', -12, 20);
 * battler.jrCustomDamagePopup('Guard', undefined, 'zoom', 0, 0, false, 36);
 * battler.jrCustomDamagePopup('Guard', undefined, 'zoom', 0, 0, true, 36);
 *
 * Arguments: text, CSS color, animation, X, Y, allowPush, textSize.
 * textSize is optional, in pixels. Omitted/null/blank/invalid/nonpositive
 * uses Font Size. Positive values are rounded, with a minimum of 8 pixels.
 * Size works with independent and queued popups and participates in spacing.
 *
 * allowPush omitted/false: appears next frame outside the damage queue;
 * keeps its own animation/offsets; never pushes or gets pushed by stacking.
 * true: uses the normal damage queue and global push-up settings.
 * It does not force pushing when Push Previous Popups Up is disabled.
 * Independent notices can overlap other text: use offsets when needed.
 * False does not freeze animation or attach the text to a damage hit.
 * Automatic Miss/Evade notices keep normal queue behavior.
 *
 * Example with a constructed string:
 * var text = '+' + $gameVariables.value(10) + '!';
 * battler.jrCustomDamagePopup(text, undefined, 'zoom', 0, 0, false, 36);
 *
 * Other omitted arguments use defaults. Boolean values are true/false,
 * not the strings 'true'/'false'.
 * Animations: bounce, rise, fall, zoom, slide, still, impact, burst,
 * recoil, spiral. Text contains no evaluated code or escape codes.
 *
 * MV plugin commands: JRPopupSigns true / false / default
 * The signs override is saved. All popup queues/caches are temporary.
 * YEP's _damagePopup remains an array. Repeated startDamagePopup calls
 * avoid repeating captured results. Manually duplicated records or custom
 * popups may intentionally create extra displays. Visible sprites required.
 */
(function() {
    'use strict';

    if (typeof Imported === 'undefined' || !Imported.YEP_BattleEngineCore) {
        console.error('JR_AutoDamagePopup requires YEP_BattleEngineCore above it.');
        return;
    }

    var jrParams = PluginManager.parameters('JR_AutoDamagePopup');

    function jrNumber(key, fallback, minimum) {
        var raw = jrParams[key];
        var n = raw === undefined || raw === '' ? fallback : Number(raw);
        return isFinite(n) ? Math.max(minimum, n) : fallback;
    }

    var jrDuration = Math.round(jrNumber('Duration', 60, 12));
    var jrSpeed = Math.min(10, jrNumber('Damage Popup Animation Speed', 1, 0.1));
    var jrFullHp = jrParams['Show Full HP Amount'] === 'true';
    var jrShowZero = jrParams['Show 0 damage'] === 'true';
    var jrInterval = Math.round(jrNumber('Queue Interval', 0, 0));
    var jrFontSize = jrNumber('Font Size', 28, 8);
    var jrOutline = jrNumber('Outline Width', 4, 0);
    var jrDamageGap = jrNumber('Damage Popup Gap', 0, 0);
    var jrPushPrevious = jrParams['Push Previous Popups Up'] === 'true';
    var jrPushGap = jrNumber('Popup Push Gap', 8, 0);
    var jrStatePlus = jrParams['Show State Plus Sign'] === 'true';
    var jrMissHeight = jrNumber('Miss Height', 36, -2000);
    var jrEvadeHeight = jrNumber('Evade Height', 36, -2000);

    var jrTypeColors = [
        String(jrParams['Certain Hit Damage Color'] || '').trim(),
        String(jrParams['Physical Damage Color'] || '').trim(),
        String(jrParams['Magical Damage Color'] || '').trim()
    ];

    var jrTypeOutlines = [
        String(jrParams['Certain Hit Damage Outline Color'] || '').trim(),
        String(jrParams['Physical Damage Outline Color'] || '').trim(),
        String(jrParams['Magical Damage Outline Color'] || '').trim()
    ];

    var jrSigns = jrParams['Show Value Signs'] !== 'false';

    function jrShowSigns() {
        return typeof $gameSystem !== 'undefined' && $gameSystem &&
            typeof $gameSystem._jrPopupSigns === 'boolean' ?
                $gameSystem._jrPopupSigns : jrSigns;
    }

    var jrPluginCommand = Game_Interpreter.prototype.pluginCommand;
    Game_Interpreter.prototype.pluginCommand = function(command, args) {
        jrPluginCommand.apply(this, arguments);
        if (String(command).toLowerCase() !== 'jrpopupsigns') return;
        var value = String(args[0] || '').toLowerCase();
        if (value === 'true' || value === 'false') {
            $gameSystem._jrPopupSigns = value === 'true';
        } else if (value === 'default') {
            delete $gameSystem._jrPopupSigns;
        }
    };

    var jrLabels = jrParams['Show Resource Labels'] !== 'false';
    var jrDefaultColor = jrParams['Default Color'] || '#ffffff';
    var jrAnimations = [
        'bounce', 'rise', 'fall', 'zoom', 'slide', 'still',
        'impact', 'burst', 'recoil', 'spiral'
    ];

    function jrAnimation(value, fallback) {
        var name = String(value || '').trim().toLowerCase();
        return jrAnimations.indexOf(name) >= 0 ? name : fallback;
    }

    var jrCertainAnimation = jrAnimation(
        jrParams['Certain Hit Damage Animation'], null
    );
    var jrDefaultAnimation = jrAnimation(jrParams['Default Animation'], 'rise');
    var jrOffsetX = jrNumber('Default Offset X', 0, -10000);
    var jrOffsetY = jrNumber('Default Offset Y', 0, -10000);

    var jrColors = {
        hp: ['#ff7070', '#70ef98'],
        mp: ['#72b8ff', '#65e1f0'],
        tp: ['#ffc66b', '#c6ef70']
    };

    var jrHeadGap = jrNumber('Head Gap', 0, -1000);
    var jrGap = jrNumber('Label Gap', 4, 0);
    var jrFanGap = jrNumber('Label Fan Gap', 8, 0);
    var jrFanTravel = jrNumber('Label Fan Travel', 8, 0);
    var jrBarrierColorSetting = String(jrParams['Barrier Damage Color'] || 'auto');
    var jrBarrierAnimation = jrAnimation(
        jrParams['Barrier Damage Animation'], 'bounce'
    );
    var jrBarrierText = jrParams['Barrier Damage Text'];
    if (jrBarrierText === undefined) jrBarrierText = 'Barrier';

    var jrSplitGap = jrNumber('Split Number Gap', 12, 0);
    var jrHeadCache = new WeakMap();
    var jrInkCache = new Map();
    var jrRenderEpoch = 0;
    var jrArrangeEpoch = 0;
    var jrHit = null;
    var jrCapture = null;
    var jrStates = new WeakMap();
    var jrResults = new WeakMap();
    var jrCalculating = new WeakMap();
    var jrCalculated = new WeakMap();
    var jrLabelSize = jrNumber('Label Font Size', 30, 8);
    var jrLabelDuration = Math.round(jrNumber('Label Duration', 45, 12));

    var jrLabelDefaults = {
        Critical: ['#ffcf55', 'impact'],
        Resist: ['#a6b8d6', 'recoil'],
        Weakness: ['#ff9360', 'burst'],
        Absorb: ['#91efc4', 'spiral']
    };

    var jrStateGroups = [];
    var jrStateDefaults = [
        ['Positive', '#80ed9c'],
        ['Negative, Poison, Sleep', '#ff8585'],
        ['Neutral', '#91caff']
    ];

    for (var jrGroupIndex = 0; jrGroupIndex < 3; jrGroupIndex++) {
        var jrGroupKey = 'State Group ' + (jrGroupIndex + 1);
        var jrCategoryText = jrParams[jrGroupKey + ' Categories'];

        if (jrCategoryText === undefined) {
            jrCategoryText = jrStateDefaults[jrGroupIndex][0];
        }

        jrStateGroups.push({
            categories: String(jrCategoryText).split(',').map(function(name) {
                return name.trim().toUpperCase();
            }).filter(function(name) {
                return name.length > 0;
            }),
            color: jrParams[jrGroupKey + ' Color'] ||
                jrStateDefaults[jrGroupIndex][1],
            size: jrNumber(jrGroupKey + ' Text Size', 24, 8)
        });
    }

    var jrStateAnimation = jrAnimation(jrParams['State Popup Animation'], 'rise');
    var jrStateDuration = Math.round(jrNumber('State Popup Duration', 60, 12));
    var jrStateX = jrNumber('State Popup Offset X', 0, -2000);
    var jrStateY = jrNumber('State Popup Offset Y', 0, -2000);
    var jrStateGap = jrNumber('State Popup Gap', 5, -2000);
    var jrStateRowGap = jrNumber('State Popup Row Gap', 6, 0);
    var jrPushStates = jrParams['Push Previous States Up'] === 'true';
    var jrPushDuration = Math.min(120, jrNumber('Popup Push Duration', 12, 0));
    var jrPushEase = jrPushDuration > 0 ?
        1 - Math.pow(0.01, 1 / jrPushDuration) : 1;

    function jrStateStyle(state) {
        if (!state || !Array.isArray(state.category)) return null;
        for (var g = 0; g < jrStateGroups.length; g++) {
            var group = jrStateGroups[g];
            for (var c = 0; c < state.category.length; c++) {
                var category = String(state.category[c]).trim().toUpperCase();
                if (group.categories.indexOf(category) >= 0) return group;
            }
        }
        return null;
    }

    var jrAddState = Game_Battler.prototype.addState;
    Game_Battler.prototype.addState = function(stateId) {
        if (!jrInBattle() || !Imported.YEP_X_StateCategories) {
            return jrAddState.apply(this, arguments);
        }

        var state = $dataStates[stateId];
        var style = jrStateStyle(state);

        if (!style || this.isStateAffected(stateId)) {
            return jrAddState.apply(this, arguments);
        }

        var tracker = jrState(this);
        tracker.stateDepth = tracker.stateDepth || {};
        var outer = !tracker.stateDepth[stateId];
        tracker.stateDepth[stateId] = (tracker.stateDepth[stateId] || 0) + 1;

        try {
            var returned = jrAddState.apply(this, arguments);
            if (outer && this.isStateAffected(stateId) && state.name) {
                jrQueue(this, {
                    text: (jrStatePlus ? '+' : '') +
                        String(state.name).replace(/[\r\n]+/g, ' '),
                    color: style.color,
                    size: style.size,
                    animation: jrStateAnimation,
                    duration: jrStateDuration,
                    x: jrOffsetX,
                    y: jrOffsetY,
                    stateNotice: true
                });
            }
            return returned;
        } finally {
            tracker.stateDepth[stateId]--;
        }
    };

    function jrEnsureYepQueue(battler) {
        if (!Array.isArray(battler._damagePopup)) battler._damagePopup = [];
    }

    var jrInitMembers = Game_Battler.prototype.initMembers;
    Game_Battler.prototype.initMembers = function() {
        jrInitMembers.apply(this, arguments);
        jrEnsureYepQueue(this);
    };

    var jrStartBattle = BattleManager.startBattle;
    BattleManager.startBattle = function() {
        $gameParty.members().forEach(jrEnsureYepQueue);
        $gameTroop.members().forEach(jrEnsureYepQueue);
        return jrStartBattle.apply(this, arguments);
    };

    Game_Battler.prototype.isDamagePopupRequested = function() {
        jrEnsureYepQueue(this);
        return this._damagePopup.length > 0;
    };

    Game_Battler.prototype.shiftDamagePopup = function() {
        jrEnsureYepQueue(this);
        return this._damagePopup.shift();
    };

    function jrInBattle() {
        return $gameParty && $gameParty.inBattle();
    }

    function jrState(battler) {
        var state = jrStates.get(battler);
        if (!state) {
            state = {
                queue: [],
                stateQueue: [],
                customQueue: [],
                head: 0,
                cooldown: 0,
                depth: {}
            };
            jrStates.set(battler, state);
        }
        return state;
    }

    function jrSeen(result) {
        var seen = jrResults.get(result);
        if (!seen) {
            seen = {};
            jrResults.set(result, seen);
        }
        return seen;
    }

    function jrQueue(battler, entry, group) {
        if (!jrInBattle() || !battler.isSpriteVisible() || battler.isHidden()) {
            return;
        }
        if (entry.stateNotice) {
            jrState(battler).stateQueue.push(entry);
            return;
        }
        if (entry.independent) {
            jrState(battler).customQueue.push(entry);
            return;
        }

        group = group || { entries: [], queued: false };
        group.entries.push(entry);
        if (!group.queued) {
            group.queued = true;
            jrState(battler).queue.push(group);
        }
    }

    function jrLabel(battler, name, group) {
        var defaults = jrLabelDefaults[name];
        var text = jrParams[name + ' Text'];
        if (text === undefined) text = name + '!';
        if (!text.trim()) return;

        jrQueue(battler, {
            text: text,
            color: jrParams[name + ' Color'] || defaults[0],
            animation: jrAnimation(jrParams[name + ' Animation'], defaults[1]),
            x: jrOffsetX,
            y: jrOffsetY,
            size: jrLabelSize,
            duration: jrLabelDuration,
            label: true
        }, group);
    }

    var jrCalcElementRate = Game_Action.prototype.calcElementRate;
    Game_Action.prototype.calcElementRate = function(target) {
        var rate = jrCalcElementRate.apply(this, arguments);
        var context = jrCalculating.get(this);
        if (context && context.target === target) context.rate = rate;
        return rate;
    };

    var jrMakeDamageValue = Game_Action.prototype.makeDamageValue;
    Game_Action.prototype.makeDamageValue = function(target, critical) {
        var previous = jrCalculating.get(this);
        var context = {
            target: target,
            critical: !!critical,
            rate: undefined
        };
        jrCalculating.set(this, context);

        try {
            var value = jrMakeDamageValue.apply(this, arguments);
            var targets = jrCalculated.get(this);
            if (!targets) {
                targets = new WeakMap();
                jrCalculated.set(this, targets);
            }
            targets.set(target, context);
            return value;
        } finally {
            if (previous) jrCalculating.set(this, previous);
            else jrCalculating.delete(this);
        }
    };

    var jrExecuteDamage = Game_Action.prototype.executeDamage;
    Game_Action.prototype.executeDamage = function(target, value) {
        var previous = jrHit;
        var frame = {
            action: this,
            target: target,
            group: { entries: [], queued: false }
        };
        var item = this.item();
        var damageType = item && item.damage ? item.damage.type : 0;
        var damaging = damageType === 1 || damageType === 2 ||
            damageType === 5 || damageType === 6;

        frame.damageColor = damaging && value >= 0 && item ?
            jrTypeColors[item.hitType] || '' : '';
        frame.damageAnimation = damaging && value >= 0 &&
            item && item.hitType === 0 ? jrCertainAnimation : null;
        frame.damageOutline = damaging && value >= 0 && item ?
            jrTypeOutlines[item.hitType] || '' : '';

        jrHit = frame;

        try {
            var targets = jrCalculated.get(this);
            var context = targets && targets.get(target);
            if (targets) targets.delete(target);

            if (jrInBattle()) {
                var result = target.result();
                if (!result.missed && !result.evaded) {
                    var seen = jrSeen(result);
                    if ((context ? context.critical : result.critical) &&
                        !seen.jrCritical) {
                        jrLabel(target, 'Critical', frame.group);
                        seen.jrCritical = true;
                    }

                    var item = this.item();
                    var type = item && item.damage ? item.damage.type : 0;
                    var damaging = type === 1 || type === 2 ||
                        type === 5 || type === 6;
                    var rate = context && context.rate;

                    if (damaging && typeof rate === 'number' && isFinite(rate)) {
                        if (rate < 0) {
                            jrLabel(target, 'Absorb', frame.group);
                        } else if (rate < 1 - 0.000001) {
                            jrLabel(target, 'Resist', frame.group);
                        } else if (rate > 1 + 0.000001) {
                            jrLabel(target, 'Weakness', frame.group);
                        }
                    }
                }
            }

            var returned = jrExecuteDamage.apply(this, arguments);

            if (jrShowZero && damaging && value >= 0 && jrInBattle()) {
                var result = target.result();
                var hasValue = frame.group.entries.some(function(entry) {
                    return entry.kind === 'hp' || entry.kind === 'mp' ||
                        entry.barrier;
                });
                if (!result.missed && !result.evaded && !hasValue) {
                    var kind = damageType === 2 || damageType === 6 ? 'mp' : 'hp';
                    jrSeen(result)[kind] = result[kind + 'Damage'];
                    jrResource(target, kind, 0, frame.group, true, frame);
                }
            }

            return returned;
        } finally {
            jrHit = previous;
        }
    };

    ['hp', 'mp'].forEach(function(kind) {
        var method = kind === 'hp' ? 'executeHpDamage' : 'executeMpDamage';
        var jrOriginalExecute = Game_Action.prototype[method];

        Game_Action.prototype[method] = function(target, value) {
            var previous = jrCapture;
            jrCapture = jrHit && jrHit.action === this && jrHit.target === target ?
                { frame: jrHit, kind: kind } : null;
            try {
                return jrOriginalExecute.apply(this, arguments);
            } finally {
                jrCapture = previous;
            }
        };
    });

    function jrDamageGroup(battler) {
        if (jrCapture && jrCapture.frame === jrHit &&
            jrCapture.frame.target === battler && jrCapture.kind === 'hp') {
            return jrCapture.frame.group;
        }
        return jrState(battler).hpGroup || null;
    }

    function jrBarrierColor() {
        if (jrBarrierColorSetting.trim().toLowerCase() !== 'auto') {
            return jrBarrierColorSetting;
        }

        var status = BattleManager._statusWindow;
        if (status && status.barrierColor1 &&
            status.windowskin && status.windowskin.isReady()) {
            return status.barrierColor1();
        }

        var index = typeof Yanfly !== 'undefined' && Yanfly.Param ?
            Number(Yanfly.Param.ABRColor1) : 13;
        if (!isFinite(index)) index = 13;

        var skin = ImageManager.loadSystem('Window');
        if (skin && skin.isReady()) {
            return skin.getPixel(
                96 + (index % 8) * 12 + 6,
                144 + Math.floor(index / 8) * 12 + 6
            );
        }
        return '#cc88ff';
    }

    function jrBarrierNumber(battler, amount, group) {
        if (!isFinite(amount) || amount <= 0) return;

        jrQueue(battler, {
            text: (jrShowSigns() ? '-' : '') + amount +
                (jrLabels && jrBarrierText ? ' ' + jrBarrierText : ''),
            color: jrBarrierColorSetting,
            animation: jrBarrierAnimation,
            x: jrOffsetX,
            y: jrOffsetY,
            barrier: true,
            kind: 'barrier'
        }, group || jrDamageGroup(battler));
    }

    if (Imported.YEP_AbsorptionBarrier && Game_Battler.prototype.loseBarrier) {
        var jrLoseBarrier = Game_Battler.prototype.loseBarrier;

        Game_Battler.prototype.loseBarrier = function(value, penRate, penFlat) {
            if (!jrInBattle()) return jrLoseBarrier.apply(this, arguments);

            var state = jrState(this);
            var outer = !state.barrierDepth;
            var before = this.barrierPoints();
            var oldResult = this.result();
            var oldSeen = jrResults.get(oldResult);
            state.barrierDepth = (state.barrierDepth || 0) + 1;

            try {
                var remaining = jrLoseBarrier.apply(this, arguments);
                if (oldSeen && this.result() !== oldResult) {
                    jrResults.set(this.result(), oldSeen);
                }
                if (outer) {
                    jrBarrierNumber(this, before - this.barrierPoints());
                }
                return remaining;
            } finally {
                state.barrierDepth--;
            }
        };
    }

    function jrResource(battler, kind, delta, group, allowZero, sourceFrame) {
        if (!isFinite(delta) || (delta === 0 && !allowZero)) return;

        if (!group && jrCapture && jrCapture.frame === jrHit &&
            jrCapture.frame.target === battler && jrCapture.kind === kind) {
            group = jrCapture.frame.group;
        }
        if (!group && kind === 'hp') group = jrState(battler).hpGroup;

        var gain = delta > 0;
        var key = kind.toUpperCase() + (gain ? ' Gain' : ' Loss');
        var color = jrParams[key + ' Color'] || jrColors[kind][gain ? 1 : 0];
        var animation = jrAnimation(
            jrParams[key + ' Animation'], gain ? 'rise' : 'bounce'
        );
        var outline = '';
        var frame = sourceFrame || (
            jrCapture && jrCapture.frame === jrHit &&
            jrCapture.frame.target === battler && jrCapture.kind === kind ?
                jrCapture.frame : null
        );

        if (!gain && frame && group === frame.group) {
            if (frame.damageColor) color = frame.damageColor;
            if (frame.damageAnimation) animation = frame.damageAnimation;
            if (frame.damageOutline) outline = frame.damageOutline;
        }

        jrQueue(battler, {
            text: (delta !== 0 && jrShowSigns() ? (gain ? '+' : '-') : '') +
                Math.abs(delta) + (jrLabels ? ' ' + kind.toUpperCase() : ''),
            color: color,
            outline: outline,
            animation: animation,
            x: jrOffsetX,
            y: jrOffsetY,
            kind: kind
        }, group);
    }

    Game_Battler.prototype.jrCustomDamagePopup = function(
        text, color, animation, offsetX, offsetY, allowPush, textSize
    ) {
        function jrOffset(value, fallback) {
            return value == null || !isFinite(Number(value)) ?
                fallback : Number(value);
        }

        var size = Number(textSize);
        if (textSize == null || String(textSize).trim() === '' ||
            !isFinite(size) || size <= 0) {
            size = jrFontSize;
        } else {
            size = Math.max(8, Math.round(size));
        }

        jrQueue(this, {
            text: text == null ? '' : String(text).replace(/[\r\n]+/g, ' '),
            color: color == null || color === '' ? jrDefaultColor : String(color),
            animation: jrAnimation(animation, jrDefaultAnimation),
            x: jrOffset(offsetX, jrOffsetX),
            y: jrOffset(offsetY, jrOffsetY),
            critical: false,
            independent: allowPush !== true,
            size: size
        });
    };

    ['hp', 'mp', 'tp'].forEach(function(kind) {
        var method = 'gain' + kind.charAt(0).toUpperCase() + kind.slice(1);
        var jrOriginalGain = Game_Battler.prototype[method];

        Game_Battler.prototype[method] = function(value) {
            if (!jrInBattle()) return jrOriginalGain.apply(this, arguments);

            var state = jrState(this);
            var outer = !state.depth[kind];
            var before = this[kind];
            var previousGroup = state.hpGroup;

            if (outer && kind === 'hp') {
                state.hpGroup = jrDamageGroup(this) ||
                    { entries: [], queued: false };
            }
            state.depth[kind] = (state.depth[kind] || 0) + 1;

            try {
                var returned = jrOriginalGain.apply(this, arguments);
                if (outer) {
                    var result = this.result();
                    jrSeen(result)[kind] = result[kind + 'Damage'];
                    var delta = this[kind] - before;

                    if (kind === 'hp' && jrFullHp && result.hpAffected &&
                        typeof result.hpDamage === 'number' &&
                        isFinite(result.hpDamage)) {
                        delta = -result.hpDamage;
                    }

                    jrResource(this, kind, delta);
                }
                return returned;
            } finally {
                state.depth[kind]--;
                if (outer && kind === 'hp') state.hpGroup = previousGroup;
            }
        };
    });

    var jrClearResult = Game_ActionResult.prototype.clear;
    Game_ActionResult.prototype.clear = function() {
        jrResults.delete(this);
        return jrClearResult.apply(this, arguments);
    };

    function jrReadResult(battler, result) {
        if (!jrInBattle() || !result || typeof result !== 'object') return;

        var seen = jrSeen(result);
        var state = jrState(battler);
        var group = { entries: [], queued: false };

        if (result._barrierAffected) {
            if (state.barrierDepth) return;
            if (seen.jrBarrier !== result.hpDamage) {
                seen.jrBarrier = result.hpDamage;
                jrBarrierNumber(battler, result.hpDamage, group);
            }
            return;
        }

        var miss = result.missed ? 'Miss' : (result.evaded ? 'Evade' : '');
        if (miss && seen.miss !== miss) {
            battler.jrCustomDamagePopup(
                miss, undefined, undefined,
                jrOffsetX,
                jrOffsetY - (miss === 'Miss' ? jrMissHeight : jrEvadeHeight),
                true
            );
            seen.miss = miss;
        }

        if (!miss && result.critical && !seen.jrCritical) {
            jrLabel(battler, 'Critical', group);
            seen.jrCritical = true;
        }

        ['hp', 'mp', 'tp'].forEach(function(kind) {
            if (state.depth[kind]) return;
            var damage = result[kind + 'Damage'];

            if (kind === 'hp' && !result.hpAffected) return;
            if (typeof damage !== 'number' || !isFinite(damage)) return;
            if (seen[kind] === damage) return;

            seen[kind] = damage;
            if (!miss) jrResource(battler, kind, -damage, group);
        });
    }

    Game_Battler.prototype.startDamagePopup = function() {
        jrEnsureYepQueue(this);
        jrReadResult(this, this.result());
    };

    function jrPixels(bitmap, x, y, width, height) {
        try {
            var context = bitmap && (bitmap.context || bitmap._context);
            if (context && width > 0 && height > 0) {
                return context.getImageData(x, y, width, height).data;
            }
        } catch (error) {
            // Use frame/font bounds if canvas pixels are unavailable.
        }
        return null;
    }

    function jrHeadTop(visual, frame) {
        var bitmap = visual.bitmap;
        if (!bitmap || !frame || frame.width <= 0 || frame.height <= 0) return 0;
        if (bitmap.isReady && !bitmap.isReady()) return 0;

        var cache = jrHeadCache.get(bitmap);
        if (!cache) {
            cache = {};
            jrHeadCache.set(bitmap, cache);
        }

        var key = [
            frame.x || 0, frame.y || 0, frame.width, frame.height
        ].join(',');
        if (cache[key] !== undefined) return cache[key];

        var w = Math.floor(frame.width);
        var h = Math.floor(frame.height);
        var data = jrPixels(bitmap, frame.x || 0, frame.y || 0, w, h);
        var top = 0;

        if (data) {
            for (var y = 0; y < h; y++) {
                var found = false;
                for (var x = 0; x < w; x++) {
                    if (data[(y * w + x) * 4 + 3] > 16) {
                        found = true;
                        break;
                    }
                }
                if (found) {
                    top = y;
                    break;
                }
            }
        }

        cache[key] = top;
        return top;
    }

    function jrInkBounds(bitmap, width, height, fontSize, padding) {
        var data = jrPixels(bitmap, 0, 0, width, height);
        var left = width;
        var right = -1;
        var top = height;
        var bottom = -1;

        if (data) {
            for (var y = 0; y < height; y++) {
                for (var x = 0; x < width; x++) {
                    if (data[(y * width + x) * 4 + 3] > 0) {
                        left = Math.min(left, x);
                        right = Math.max(right, x);
                        top = Math.min(top, y);
                        bottom = Math.max(bottom, y);
                    }
                }
            }
        }

        if (bottom < 0) {
            left = padding;
            right = width - padding - 1;
            bottom = Math.round(height / 2 + fontSize * 0.35);
            top = Math.max(0, bottom - fontSize);
        }

        return { left: left, right: right, top: top, bottom: bottom };
    }

    function jrCachedInk(bitmap, text, width, height, padding) {
        var ready = typeof document === 'undefined' ||
            !document.fonts || document.fonts.status === 'loaded';

        var key = JSON.stringify([
            text, bitmap.fontFace, bitmap.fontSize,
            !!bitmap.fontBold, !!bitmap.fontItalic,
            bitmap.textColor, bitmap.outlineColor,
            bitmap.outlineWidth, width, height
        ]);

        if (!ready) jrInkCache.clear();

        if (ready && jrInkCache.has(key)) {
            var cached = jrInkCache.get(key);
            jrInkCache.delete(key);
            jrInkCache.set(key, cached);
            return cached;
        }

        var bounds = jrInkBounds(
            bitmap, width, height, bitmap.fontSize, padding
        );

        if (ready) {
            if (jrInkCache.size >= 256) {
                jrInkCache.delete(jrInkCache.keys().next().value);
            }
            jrInkCache.set(key, bounds);
        }

        return bounds;
    }

    function jrMotion(animation, age, duration, out) {
        var t = Math.min(1, age / duration);
        var dx = 0;
        var dy = 0;
        var scale = 1;

        switch (animation) {
        case 'bounce':
            dy = -Math.abs(Math.sin(t * Math.PI * 2.5)) * 28 * (1 - t);
            break;
        case 'rise':
            dy = -28 * t;
            break;
        case 'fall':
            dy = 24 * t * t;
            break;
        case 'zoom':
            scale = 1 + 0.45 * Math.max(0, 1 - t * 4);
            dy = -12 * t;
            break;
        case 'slide':
            dx = 28 * t;
            dy = -10 * t;
            break;
        case 'impact':
            scale = 1 + 0.65 * Math.pow(Math.max(0, 1 - t * 5), 2);
            dx = Math.sin(age * 2.4) * 5 * Math.max(0, 1 - t * 3);
            dy = -16 * t;
            break;
        case 'burst':
            scale = 1 + 0.22 * Math.sin(Math.min(1, t * 3) * Math.PI);
            dy = -28 * (1 - Math.pow(1 - t, 2));
            break;
        case 'recoil':
            dx = -12 * Math.sin(Math.min(1, t * 2) * Math.PI);
            dy = -8 * t;
            scale = 1 - 0.1 * Math.sin(Math.min(1, t * 2) * Math.PI);
            break;
        case 'spiral':
            dx = Math.sin(t * Math.PI * 2) * 10 * (1 - t);
            dy = -24 * t;
            scale = 1 + 0.1 * Math.sin(t * Math.PI * 4) * (1 - t);
            break;
        }

        out.x = dx;
        out.y = dy;
        out.scale = scale;
        return out;
    }

    function jrSpriteDamagePopup(entry, owner) {
        this.initialize(entry, owner);
    }

    jrSpriteDamagePopup.prototype = Object.create(Sprite.prototype);
    jrSpriteDamagePopup.prototype.constructor = jrSpriteDamagePopup;

    jrSpriteDamagePopup.prototype.initialize = function(entry, owner) {
        Sprite.prototype.initialize.call(this);

        this._jrEntry = entry;
        this._jrOwner = owner;
        this._jrAge = 0;
        this._jrDuration = entry.groupDuration || entry.duration || jrDuration;
        this._jrMotionA = {};
        this._jrMotionB = {};
        this._jrMotionC = {};
        this._jrDisposed = false;
        this._jrFresh = true;

        var bitmap = new Bitmap(1, 1);
        bitmap.fontFace = jrParams['Font Face'] || 'GameFont';
        bitmap.fontSize = entry.size || jrFontSize;
        bitmap.textColor = entry.barrier ? jrBarrierColor() : entry.color;
        bitmap.outlineColor = entry.outline ||
            jrParams['Outline Color'] || 'rgba(0,0,0,0.85)';
        bitmap.outlineWidth = jrOutline;

        var padding = Math.ceil(jrOutline * 2 + 8);
        var width = Math.min(
            4096,
            Math.max(32, Math.ceil(bitmap.measureTextWidth(entry.text)) + padding * 2)
        );
        var height = Math.ceil(bitmap.fontSize * 1.6 + padding * 2);

        bitmap.resize(width, height);
        bitmap.drawText(
            entry.text, padding, padding,
            width - padding * 2, height - padding * 2, 'center'
        );

        this.bitmap = bitmap;

        var ink = jrCachedInk(bitmap, entry.text, width, height, padding);
        this._jrInkHeight = ink.bottom - ink.top + 1;

        var direction = entry.direction || 0;
        this.anchor.x = direction < 0 ? (ink.right + 1) / width :
            direction > 0 ? ink.left / width :
                (ink.left + ink.right + 1) / (2 * width);
        this.anchor.y = (ink.bottom + 1) / height;

        this._jrInkLeft = ink.left - this.anchor.x * width;
        this._jrInkRight = ink.right + 1 - this.anchor.x * width;
        this.jrPosition(0, 0);
    };

    function jrPopupOrigin(owner, layer) {
        var cache = owner._jrOrigin;

        if (!cache) {
            cache = owner._jrOrigin = {
                epoch: -1,
                layer: null,
                point: new PIXI.Point(),
                world: new PIXI.Point(),
                local: new PIXI.Point()
            };
        }

        if (cache.epoch === jrRenderEpoch && cache.layer === layer) {
            return cache.local;
        }

        var visual = owner._mainSprite || owner._effectTarget || owner;
        var frame = visual._frame;
        var width = frame ? frame.width :
            (visual.bitmap ? visual.bitmap.width : 0);
        var height = frame ? frame.height :
            (visual.bitmap ? visual.bitmap.height : 0);
        var anchor = visual.anchor || { x: 0.5, y: 1 };

        cache.point.x = (0.5 - anchor.x) * width;
        cache.point.y = -anchor.y * height + jrHeadTop(visual, frame);

        visual.toGlobal(cache.point, cache.world);
        layer.toLocal(cache.world, null, cache.local);

        cache.epoch = jrRenderEpoch;
        cache.layer = layer;
        return cache.local;
    }

    jrSpriteDamagePopup.prototype.jrPosition = function(dx, dy) {
        var local = jrPopupOrigin(
            this._jrOwner, this.parent || BattleManager._spriteset
        );

        this.x = local.x + this._jrEntry.x + dx;
        this.y = local.y - jrHeadGap + this._jrEntry.y + dy;

        var entry = this._jrEntry;
        if (entry.layout) {
            this.y += (entry.layout.offsetY || 0) +
                (entry.layout.stateLift || 0);
        }

        if (entry.stateNotice) {
            var baseX = local.x + entry.x;
            var baseY = local.y - jrHeadGap + entry.y;
            var follow = entry.stateFollow;

            if (follow && follow.layout.driver) {
                var layout = follow.layout;
                var age = Math.min(follow.duration, follow.age + this._jrAge);
                var driver = layout.driver;
                var motion = jrMotion(
                    driver.animation, age, follow.duration, this._jrMotionB
                );

                baseX = local.x + driver.x + motion.x;
                baseY = -Infinity;

                for (var i = 0; i < layout.numbers.length; i++) {
                    var number = layout.numbers[i];
                    var numberMotion = layout.paired ? motion :
                        jrMotion(
                            number.animation, age, follow.duration, this._jrMotionC
                        );

                    baseY = Math.max(
                        baseY,
                        local.y - jrHeadGap + number.y +
                        numberMotion.y + (layout.offsetY || 0)
                    );
                }
            }

            this.x = baseX + jrStateX + dx;
            this.y = baseY + jrStateGap + jrStateY +
                (entry.stateOffset || 0) + this._jrInkHeight * this.scale.y;
        }
    };

    jrSpriteDamagePopup.prototype.isPlaying = function() {
        return !this._jrDisposed && this._jrAge < this._jrDuration;
    };

    jrSpriteDamagePopup.prototype.jrDispose = function() {
        if (this._jrDisposed) return;

        this._jrDisposed = true;
        if (this.parent) this.parent.removeChild(this);

        var bitmap = this.bitmap;
        this.bitmap = null;

        if (bitmap) {
            if (typeof bitmap.destroy === 'function') bitmap.destroy();
            else if (bitmap._baseTexture) bitmap._baseTexture.destroy();
        }

        this._jrOwner = null;
    };

    jrSpriteDamagePopup.prototype.update = function() {
        if (!this.isPlaying()) return;
        Sprite.prototype.update.call(this);
        this._jrAge++;
        this.jrAnimate();
        // Layout and disposal happen after spriteset child traversal.
    };

    jrSpriteDamagePopup.prototype.jrAnimate = function() {
        var entry = this._jrEntry;
        var t = Math.min(1, this._jrAge / this._jrDuration);
        var motion = jrMotion(
            entry.animation, this._jrAge, this._jrDuration, this._jrMotionA
        );
        var dx = motion.x;
        var dy = motion.y;
        var layout = entry.layout;

        if (entry.label && layout && layout.driver) {
            var driver = jrMotion(
                layout.driver.animation,
                this._jrAge, this._jrDuration, this._jrMotionB
            );
            var direction = entry.direction || 0;

            dx = driver.x + direction * (jrFanGap / 2 + jrFanTravel * t);
            dx += direction ?
                direction * Math.abs(motion.x) * 0.3 : motion.x * 0.3;

            var numberHeight = layout.height * driver.scale;

            if (layout.paired) {
                numberHeight = 0;
                for (var i = 0; i < layout.numbers.length; i++) {
                    var number = layout.numbers[i];
                    var numberMotion = jrMotion(
                        number.animation,
                        this._jrAge, this._jrDuration, this._jrMotionC
                    );
                    numberHeight = Math.max(
                        numberHeight, number.inkHeight * numberMotion.scale
                    );
                }
            }

            dy = driver.y - numberHeight - jrGap;
        } else if (!entry.label && layout && layout.paired) {
            var primary = jrMotion(
                layout.driver.animation,
                this._jrAge, this._jrDuration, this._jrMotionB
            );
            dx = primary.x + entry.direction * jrSplitGap / 2;
            dy = primary.y;
        } else if (entry.label && entry.direction) {
            dx += entry.direction * (jrFanGap / 2 + jrFanTravel * t);
        }

        this.scale.x = this.scale.y = motion.scale;
        this.opacity = Math.round(255 * Math.min(1, (1 - t) / 0.25));
        this.jrPosition(dx, dy);
    };

    function jrEasePush(current, target, advance) {
        if (!advance) return current;
        var next = current + (target - current) * jrPushEase;
        return Math.abs(next - target) < 0.05 ? target : next;
    }

    function jrClearWork(work) {
        for (var i = 0; i < work.buckets.length; i++) {
            var bucket = work.buckets[i];
            bucket.members.length = 0;
            bucket.values.length = 0;
            bucket.states.length = 0;
        }
        work.buckets.length = 0;
        work.hits.length = 0;
    }

    function jrArrangePopups(owner, advance) {
        var active = owner._jrPopupSprites;
        var work = owner._jrWork;

        if (work) jrClearWork(work);
        if (!active || !active.length) return;

        var hasState = false;
        for (var i = 0; i < active.length; i++) {
            if (active[i]._jrEntry.stateNotice && active[i].isPlaying()) {
                hasState = true;
                break;
            }
        }

        if (!jrPushPrevious && !hasState) return;

        if (!work) {
            work = owner._jrWork = {
                buckets: [],
                hits: [],
                standalone: {}
            };
        }

        var stamp = ++jrArrangeEpoch;

        for (var i = 0; i < active.length; i++) {
            var popup = active[i];
            if (!popup.isPlaying() || popup._jrEntry.independent) continue;

            var entry = popup._jrEntry;
            var layout = entry.layout ||
                (entry.stateFollow && entry.stateFollow.layout) ||
                work.standalone;
            var bucket = layout.jrBucket;

            if (!bucket) {
                bucket = layout.jrBucket = {
                    layout: layout,
                    members: [],
                    values: [],
                    states: [],
                    stamp: 0
                };
            }

            if (bucket.stamp !== stamp) {
                bucket.stamp = stamp;
                bucket.hasHit = false;
                work.buckets.push(bucket);
            }

            bucket.members.push(popup);

            if (entry.stateNotice) {
                bucket.states.push(popup);
            } else {
                bucket.values.push(popup);
                if (!bucket.hasHit) {
                    bucket.hasHit = true;
                    work.hits.push(bucket);
                }
            }
        }

        for (var g = 0; g < work.buckets.length; g++) {
            var bucket = work.buckets[g];
            var rows = bucket.states;
            var cursor = 0;
            var lift = 0;

            for (var r = 0; r < rows.length; r++) {
                var popup = rows[jrPushStates ? rows.length - 1 - r : r];
                var entry = popup._jrEntry;
                var height = popup._jrInkHeight * popup.scale.y;
                var old = entry.stateOffset || 0;

                if (jrPushStates) {
                    var target = r === 0 ? 0 : cursor - height - jrStateRowGap;
                    target = Math.min(entry.stateTarget || 0, target);
                    entry.stateTarget = target;
                    entry.stateOffset = popup._jrFresh ?
                        target : jrEasePush(old, target, advance);
                    cursor = target;
                } else {
                    entry.stateOffset = cursor;
                    cursor += height + jrStateRowGap;
                }

                popup.y += entry.stateOffset - old;
                popup._jrFresh = false;
                lift = Math.min(lift, entry.stateOffset);
            }

            if (jrPushStates && rows.length &&
                bucket.layout !== work.standalone) {
                var layout = bucket.layout;
                var previous = layout.stateLift || 0;
                layout.stateLift = Math.min(previous, lift);
                var delta = layout.stateLift - previous;

                for (var n = 0; n < bucket.values.length; n++) {
                    bucket.values[n].y += delta;
                }
            }
        }

        if (!jrPushPrevious) return;

        var hits = work.hits;

        for (var g = hits.length - 1; g >= 0; g--) {
            var bucket = hits[g];
            var layout = bucket.layout;
            var top = Infinity;
            var bottom = -Infinity;

            for (var n = 0; n < bucket.members.length; n++) {
                var popup = bucket.members[n];
                var base = popup.y - (layout.offsetY || 0);
                top = Math.min(
                    top, base - popup._jrInkHeight * popup.scale.y
                );
                bottom = Math.max(bottom, base);
            }

            bucket.top = top;
            var target = layout.pushTarget || 0;

            if (g + 1 < hits.length) {
                var newer = hits[g + 1];
                target = Math.min(
                    target,
                    newer.top + newer.layout.pushTarget - jrPushGap - bottom
                );
            }

            layout.pushTarget = target;
            var old = layout.offsetY || 0;
            layout.offsetY = jrEasePush(old, target, advance);
            var delta = layout.offsetY - old;

            for (var n = 0; n < bucket.members.length; n++) {
                bucket.members[n].y += delta;
            }
        }
    }

    var jrSpritesetUpdate = Spriteset_Battle.prototype.update;
    Spriteset_Battle.prototype.update = function() {
        jrRenderEpoch++;

        var returned = jrSpritesetUpdate.apply(this, arguments);
        var owners = this.battlerSprites();

        for (var i = 0; i < owners.length; i++) {
            var owner = owners[i];
            var active = owner._jrPopupSprites;
            if (!active) continue;

            // Child traversal has finished; removal cannot skip a sibling.
            for (var n = active.length - 1; n >= 0; n--) {
                if (!active[n].isPlaying()) {
                    active[n].jrDispose();
                    active.splice(n, 1);
                }
            }

            jrArrangePopups(owner, true);
        }

        return returned;
    };

    function jrResetSprite(sprite) {
        var active = sprite._jrPopupSprites || [];
        active.forEach(function(popup) {
            popup.jrDispose();
        });

        if (sprite._jrWork) jrClearWork(sprite._jrWork);

        sprite._jrWork = null;
        sprite._jrOrigin = null;
        sprite._jrPopupSprites = [];
        sprite._jrPopupBattler = sprite._battler;
    }

    Sprite_Battler.prototype.setupDamagePopup = function() {
        if (this._jrPopupBattler !== this._battler) jrResetSprite(this);

        var battler = this._battler;
        if (!battler) return;

        jrEnsureYepQueue(battler);

        if (battler._damagePopup.length > 0) {
            var records = battler._damagePopup.splice(0);
            for (var r = 0; r < records.length; r++) {
                jrReadResult(battler, records[r]);
            }
        }

        var state = jrStates.get(battler);
        if (!state) return;

        if (!battler.isSpriteVisible() || battler.isHidden()) {
            state.queue = [];
            state.stateQueue = [];
            state.customQueue = [];
            state.head = 0;
            state.cooldown = 0;
            jrResetSprite(this);
            return;
        }

        var active = this._jrPopupSprites || (this._jrPopupSprites = []);

        for (var i = active.length - 1; i >= 0; i--) {
            if (!active[i].isPlaying()) active.splice(i, 1);
        }

        if (state.cooldown > 0) state.cooldown--;
        if (state.head >= state.queue.length) return;

        var damageActive = active.filter(function(popup) {
            return !popup._jrEntry.stateNotice && !popup._jrEntry.independent;
        });

        if (jrInterval === 0 ? damageActive.length > 0 : state.cooldown > 0) {
            return;
        }
        if (!BattleManager._spriteset) return;

        var entries = state.queue[state.head++].entries;
        var groupDuration = 0;

        var numbers = entries.filter(function(entry) {
            return !entry.label;
        });
        var labels = entries.filter(function(entry) {
            return entry.label;
        });
        var hpEntry = numbers.filter(function(entry) {
            return entry.kind === 'hp';
        })[0];

        var paired = numbers.length === 2 && !!hpEntry &&
            numbers.some(function(entry) {
                return entry.barrier;
            });

        var layout = {
            driver: hpEntry || numbers[0] || null,
            height: 0,
            paired: paired,
            numbers: numbers
        };

        var slot = 0;
        while (damageActive.some(function(popup) {
            return popup._jrEntry.layout &&
                popup._jrEntry.layout.slot === slot;
        })) {
            slot++;
        }

        layout.slot = slot;
        layout.offsetY = jrPushPrevious ? 0 : -slot * jrDamageGap;

        if (paired) {
            for (var k = 0; k < numbers.length; k++) {
                numbers[k].direction = numbers[k].barrier ? -1 : 1;
            }
        }

        for (var j = 0; j < entries.length; j++) {
            groupDuration = Math.max(
                groupDuration, entries[j].duration || jrDuration
            );
        }

        groupDuration = Math.max(1, Math.round(groupDuration / jrSpeed));

        for (var l = 0; l < labels.length; l++) {
            labels[l].direction = labels.length > 1 ?
                (l % 2 === 0 ? -1 : 1) : 0;
        }

        var created = [];
        var stackHeight = 0;

        for (var n = 0; n < entries.length; n++) {
            var entry = entries[n];
            entry.groupDuration = groupDuration;
            entry.layout = layout;

            var popup = new jrSpriteDamagePopup(entry, this);

            if (!entry.label) {
                entry.inkHeight = popup._jrInkHeight;
                if (paired) {
                    layout.height = Math.max(layout.height, popup._jrInkHeight);
                } else {
                    entry.y -= stackHeight;
                    stackHeight += popup._jrInkHeight + jrGap;
                    layout.height = stackHeight - jrGap;
                }
            }

            active.push(popup);
            created.push(popup);
            BattleManager._spriteset.addChild(popup);
        }

        for (var q = 0; q < created.length; q++) {
            created[q].jrAnimate();
        }

        state.cooldown = jrInterval;

        if (state.head === state.queue.length) {
            state.queue = [];
            state.head = 0;
        } else if (state.head >= 128) {
            state.queue = state.queue.slice(state.head);
            state.head = 0;
        }
    };

    var jrSetupDamagePopup = Sprite_Battler.prototype.setupDamagePopup;
    Sprite_Battler.prototype.setupDamagePopup = function() {
        jrSetupDamagePopup.call(this);

        var battler = this._battler;
        var state = battler && jrStates.get(battler);

        if (!state || !BattleManager._spriteset ||
            !battler.isSpriteVisible() || battler.isHidden()) {
            return;
        }

        var active = this._jrPopupSprites || (this._jrPopupSprites = []);

        // Independent notices launch immediately without taking queue slots.
        for (var c = 0; c < state.customQueue.length; c++) {
            var custom = state.customQueue[c];
            custom.groupDuration = Math.max(
                1, Math.round((custom.duration || jrDuration) / jrSpeed)
            );

            var customPopup = new jrSpriteDamagePopup(custom, this);
            active.push(customPopup);
            BattleManager._spriteset.addChild(customPopup);
            customPopup.jrAnimate();
        }
        state.customQueue.length = 0;

        while (state.stateQueue.length) {
            var entry = state.stateQueue.shift();
            var slot = 0;

            while (active.some(function(popup) {
                return popup.isPlaying() && popup._jrEntry.stateNotice &&
                    popup._jrEntry.stateSlot === slot;
            })) {
                slot++;
            }

            entry.stateSlot = slot;
            entry.direction = 0;

            for (var i = active.length - 1; i >= 0; i--) {
                var source = active[i];
                var layout = source._jrEntry.layout;

                if (source.isPlaying() &&
                    !source._jrEntry.stateNotice &&
                    !source._jrEntry.independent &&
                    layout && layout.numbers.length) {
                    entry.stateFollow = {
                        layout: layout,
                        age: source._jrAge,
                        duration: source._jrDuration
                    };
                    break;
                }
            }

            var popup = new jrSpriteDamagePopup(entry, this);
            active.push(popup);
            BattleManager._spriteset.addChild(popup);
            popup.jrAnimate();
        }
    };

    var jrOriginalIsPlaying = Sprite_Battler.prototype.isPopupPlaying;
    Sprite_Battler.prototype.isPopupPlaying = function() {
        if (this._battler && this._battler.isSpriteVisible() &&
            !this._battler.isHidden()) {
            jrEnsureYepQueue(this._battler);
            if (this._battler._damagePopup.length > 0) return true;

            var state = jrStates.get(this._battler);
            if (state && (
                state.head < state.queue.length ||
                state.stateQueue.length ||
                state.customQueue.length
            )) {
                return true;
            }

            var active = this._jrPopupSprites || [];
            for (var i = 0; i < active.length; i++) {
                if (active[i].isPlaying()) return true;
            }
        }

        return jrOriginalIsPlaying.call(this);
    };

    var jrBattleSetup = BattleManager.setup;
    BattleManager.setup = function() {
        jrStates = new WeakMap();
        jrResults = new WeakMap();
        jrCalculating = new WeakMap();
        jrCalculated = new WeakMap();
        jrHit = null;
        jrCapture = null;
        jrHeadCache = new WeakMap();
        jrInkCache.clear();
        return jrBattleSetup.apply(this, arguments);
    };

    var jrBattleEndUpdate = BattleManager.updateBattleEnd;
    BattleManager.updateBattleEnd = function() {
        if (this._spriteset && this._spriteset.isPopupPlaying()) return;
        return jrBattleEndUpdate.apply(this, arguments);
    };

    var jrTerminate = Scene_Battle.prototype.terminate;
    Scene_Battle.prototype.terminate = function() {
        if (this._spriteset && this._spriteset.battlerSprites) {
            this._spriteset.battlerSprites().forEach(jrResetSprite);
        }

        jrStates = new WeakMap();
        jrResults = new WeakMap();
        jrCalculating = new WeakMap();
        jrCalculated = new WeakMap();
        jrHit = null;
        jrCapture = null;
        jrHeadCache = new WeakMap();
        jrInkCache.clear();
        return jrTerminate.apply(this, arguments);
    };
})();