/*:
 * @plugindesc v1.6 Displays an auto-scrolling detail window using PIXI masking with isolated additional info.
 * @author JR
 *
 * @param Detail Title
 * @desc Title text for the detail window.
 * @default Skill Detail
 *
 * @param Exclude Lines
 * @desc Enter line numbers to exclude globally from Learn Custom Text, separated by commas (e.g., 2, 5).
 * @default 
 *
 * @param Scroll Delay Start
 * @type number
 * @decimals 1
 * @desc Time (in seconds) to wait before the text begins scrolling.
 * @default 2.0
 *
 * @param Scroll Speed
 * @type number
 * @decimals 1
 * @desc The speed (in pixels per frame) at which the text scrolls.
 * @default 1.0
 *
 * @param Scroll Delay End
 * @type number
 * @decimals 1
 * @desc Time (in seconds) to wait after reaching the bottom before resetting.
 * @default 2.0
 * 
 * @help
 * Displays a custom window on the right side of the Skill scene.
 * It reads the text inside the <Learn Custom Text>...</Learn Custom Text>
 * and <Skill Additional Info>...</Skill Additional Info> blocks.
 * 
 * Exclude Lines only applies to the <Learn Custom Text> block.
 * Supports YEP_MessageCore tags like <WordWrap>.
 */

(function() {
    var parameters = PluginManager.parameters('JR_CustomSkillDetail');
    
    // Guard against NaN
    var parseNum = function(val, def) {
        if (typeof val === 'undefined' || val === null || String(val).trim() === '') return def;
        var n = Number(val);
        return isNaN(n) ? def : n;
    };

    var detailTitle = String(parameters['Detail Title'] || "Skill Detail");
    
    // Parse the excluded lines into an array of numbers
    var excludeLinesRaw = String(parameters['Exclude Lines'] || "");
    var excludeLines = excludeLinesRaw.split(',').map(function(num) {
        return parseInt(num.trim(), 10);
    }).filter(function(num) {
        return !isNaN(num); // Remove any invalid entries
    });

    // Defensively parse and clamp values
    var startSeconds = parseNum(parameters['Scroll Delay Start'], 2.0);
    var speedValue = parseNum(parameters['Scroll Speed'], 1.0);
    var endSeconds = parseNum(parameters['Scroll Delay End'], 2.0);

    if (!isFinite(startSeconds)) startSeconds = 2.0;
    if (!isFinite(speedValue)) speedValue = 1.0;
    if (!isFinite(endSeconds)) endSeconds = 2.0;

    var delayStart = Math.floor(Math.max(0, startSeconds) * 60);
    var scrollSpeed = Math.max(0.1, speedValue);
    var delayEnd = Math.floor(Math.max(0, endSeconds) * 60);


    // ========================================================================
    // Window_SkillList
    // ========================================================================

    var _Window_SkillList_updateHelp = Window_SkillList.prototype.updateHelp;
    Window_SkillList.prototype.updateHelp = function() {
        _Window_SkillList_updateHelp.call(this);
        if (this._detailWindow) {
            this._detailWindow.setSkill(this.item());
        }
    };

    Window_SkillList.prototype.setDetailWindow = function(detailWindow) {
        this._detailWindow = detailWindow;
    };

    // ========================================================================
    // Scene_Skill
    // ========================================================================
    var _Scene_Skill_createItemWindow = Scene_Skill.prototype.createItemWindow;
    Scene_Skill.prototype.createItemWindow = function() {
        _Scene_Skill_createItemWindow.call(this);
        
        // Shrink the item window to the left half and recreate contents to save memory
        var leftWidth = Math.floor(Graphics.boxWidth / 2);
        this._itemWindow.width = leftWidth;
        this._itemWindow.maxCols = function() {
            return 1;
        };
        this._itemWindow.createContents();
        this._itemWindow.refresh();
        
        // Create Detail window on the right
        var wx = this._itemWindow.width;
        var wy = this._itemWindow.y;
        var ww = Graphics.boxWidth - wx;
        var wh = this._itemWindow.height;
        this._skillDetailWindow = new Window_SkillDetail(wx, wy, ww, wh);
        this.addWindow(this._skillDetailWindow);
        this._itemWindow.setDetailWindow(this._skillDetailWindow);
    };

    // ========================================================================
    // Window_SkillDetail
    // ========================================================================
    function Window_SkillDetail() {
        this.initialize.apply(this, arguments);
    }
    
    Window_SkillDetail.prototype = Object.create(Window_Base.prototype);
    Window_SkillDetail.prototype.constructor = Window_SkillDetail;

    Window_SkillDetail.prototype.initialize = function(x, y, w, h) {
        Window_Base.prototype.initialize.call(this, x, y, w, h);
        this._skill = null;
        this._scrollMax = 0;
        this._scrollY = 0;
        
        // Dummy bitmap used strictly for measuring text height cleanly
        this._measureBitmap = new Bitmap(this.contentsWidth(), 1);
        this.refresh();
    };

    Window_SkillDetail.prototype.setSkill = function(skill) {
        if (this._skill !== skill) {
            this._skill = skill;
            this.refresh();
        }
    };

    // Override drawTextEx to capture the final Y height after rendering
    Window_SkillDetail.prototype.drawTextEx = function(text, x, y) {
        if (text) {
            var textState = { index: 0, x: x, y: y, left: x };
            textState.text = this.convertEscapeCharacters(text);
            textState.height = this.calcTextHeight(textState, false);
            this.resetFontSettings();
            while (textState.index < textState.text.length) {
                this.processCharacter(textState);
            }
            this._lastTextStateY = textState.y + textState.height;
            return textState.x - x;
        } else {
            return 0;
        }
    };

    Window_SkillDetail.prototype.refresh = function() {
        this.contents.clear();
        this._scrollMax = 0;
        this._scrollY = 0;

        if (this._descSprite) {
            this._descSprite.visible = false;
            this._descSprite.y = 0;
        }

        // 1. Draw Fixed Header
        this.changeTextColor(this.systemColor());
        this.drawText(detailTitle, 0, 0, this.contentsWidth(), 'center');
        var descStartY = this.lineHeight(); // Header takes 1 line

        if (!this._skill || !this._skill.note) return;

        // 2. Extract Description Texts
        var note = this._skill.note;
        
        var matchLearn = note.match(/<Learn Custom Text>([\s\S]*?)<\/Learn Custom Text>/i);
        var textLearn = matchLearn ? matchLearn[1].trim() : "";
        
        var matchAdditional = note.match(/<Skill Additional Info>([\s\S]*?)<\/Skill Additional Info>/i);
        var descText2 = matchAdditional ? matchAdditional[1].trim() : "";
        
        var linesLearn = textLearn ? textLearn.split(/\r?\n/) : [];
        var filteredLearn = [];

        // Filter Learn Text ONLY
        for (var i = 0; i < linesLearn.length; i++) {
            // Arrays start at 0, lines start at 1
            if (excludeLines.indexOf(i + 1) === -1) {
                filteredLearn.push(linesLearn[i]);
            }
        }

        var descText1 = filteredLearn.join('\n').trim();

        if (!descText1 && !descText2) return; // Safety check if everything is empty/excluded

        // 3. Measure Content Height on Dummy Bitmap
        var realContents = this.contents;
        this.contents = this._measureBitmap;
        
        var currentY = 0;
        if (descText1) {
            this.drawTextEx(descText1, 0, currentY);
            currentY = this._lastTextStateY;
        }
        if (descText2) {
            this.drawTextEx(descText2, 0, currentY);
            currentY = this._lastTextStateY;
        }
        
        var descHeight = currentY;
        this.contents = realContents; // Swap back immediately

        var availableHeight = Math.max(0, this.contentsHeight() - descStartY);
        this._scrollMax = Math.max(0, descHeight - availableHeight);

        // 4. Render (Direct vs PIXI Sprite Masking)
        if (this._scrollMax === 0) {
            // FAST PATH: Fits entirely. Draw directly to Window_Base contents.
            var drawY = descStartY;
            if (descText1) {
                this.drawTextEx(descText1, 0, drawY);
                drawY = this._lastTextStateY;
            }
            if (descText2) {
                this.drawTextEx(descText2, 0, drawY);
            }
        } else {
            // SLOW PATH: Needs scrolling. Render to masked sprite.
            if (!this._descSprite) {
                this._descSprite = new Sprite();
                this._windowContentsSprite.addChild(this._descSprite);
            }
            this._descSprite.visible = true;

            var neededHeight = Math.ceil(descHeight) + 10;
            if (!this._descSprite.bitmap || this._descSprite.bitmap.height < neededHeight) {
                this._descSprite.bitmap = new Bitmap(this.contentsWidth(), neededHeight);
            } else {
                this._descSprite.bitmap.clear();
            }

            if (!this._descMask) {
                this._descMask = new PIXI.Graphics();
                this._windowContentsSprite.addChild(this._descMask);
                this._descSprite.mask = this._descMask;
            }
            
            this._descMask.clear();
            this._descMask.beginFill(0xFFFFFF);
            this._descMask.drawRect(0, descStartY, this.contentsWidth(), availableHeight);
            this._descMask.endFill();

            // Guard contents swap with try/finally to protect the rendering context
            this.contents = this._descSprite.bitmap;
            try {
                var renderY = 0;
                if (descText1) {
                    this.drawTextEx(descText1, 0, renderY);
                    renderY = this._lastTextStateY;
                }
                if (descText2) {
                    this.drawTextEx(descText2, 0, renderY);
                }
            } finally {
                this.contents = realContents; 
            }

            this._descStartY = descStartY;
            this._descSprite.y = this._descStartY;
            this._scrollState = 'start_delay';
            this._scrollTimer = delayStart;
        }
    };

    Window_SkillDetail.prototype.update = function() {
        Window_Base.prototype.update.call(this);
        
        if (this._scrollMax > 0 && this.isOpen() && this.visible) {
            this.updateScrolling();
        }
    };

    Window_SkillDetail.prototype.updateScrolling = function() {
        switch(this._scrollState) {
            case 'start_delay':
                if (this._scrollTimer > 0) {
                    this._scrollTimer--;
                } else {
                    this._scrollState = 'scrolling_down'; 
                }
                break;
            case 'scrolling_down':
                this._scrollY += scrollSpeed;
                if (this._scrollY >= this._scrollMax) {
                    this._scrollY = this._scrollMax;
                    this._scrollState = 'end_delay';
                    this._scrollTimer = delayEnd;
                }
                this._descSprite.y = this._descStartY - this._scrollY;
                break;
            case 'end_delay':
                if (this._scrollTimer > 0) {
                    this._scrollTimer--;
                } else {
                    this._scrollState = 'scrolling_up'; 
                }
                break;
            case 'scrolling_up':
                this._scrollY -= scrollSpeed;
                if (this._scrollY <= 0) {
                    this._scrollY = 0;
                    this._scrollState = 'start_delay';
                    this._scrollTimer = delayStart;
                }
                this._descSprite.y = this._descStartY - this._scrollY;
                break;
        }
    };

})();