/*:
 * @plugindesc Dynamically extends Item List, fixes Sort Window, and fixes MSX selection bug.
 * @author Assistant
 * @help 
 * This plugin must be placed BELOW YEP_ItemCore, 
 * MSX_InventoryCategories, and BO_SortingOptions.
 */
(function() {
    
    // ======================================================================
    // 1. Hook into Category Selection to dynamically change layout
    // ======================================================================
    var _Scene_Item_onCategoryOk = Scene_Item.prototype.onCategoryOk;
    Scene_Item.prototype.onCategoryOk = function() {
        // Run the original MSX code first
        _Scene_Item_onCategoryOk.call(this);
        
        var symbol = this._categoryWindow.currentSymbol();
        var isItemCategory = false;
        
        // Check if it's the main Item menu or a sub-category
        if (symbol === 'tlm_item' || symbol === 'item') {
            isItemCategory = true;
        } else {
            var itemCats = MSX.InventoryCategories.ItemCategories.toLowerCase().split(',');
            if (itemCats.includes(symbol) || symbol === 'keyitem') {
                isItemCategory = true;
            }
        }
        
        this._isItemListExpanded = isItemCategory;

        // Resize the main Item window
        if (isItemCategory) {
            if (this._infoWindow) this._infoWindow.hide();
            this._itemWindow.width = Graphics.boxWidth;
        } else {
            if (this._infoWindow) {
                this._infoWindow.show();
                this._itemWindow.width = this._infoWindow.x; 
            } else {
                this._itemWindow.width = Graphics.boxWidth / 2;
            }
        }

        // ======================================================================
        // 2. BO_SortingOptions Compatibility 
        // ======================================================================
        if (this._sortInfoWindow) {
            if (isItemCategory) {
                // Expand to full bottom bar
                this._sortInfoWindow.width = Graphics.boxWidth;
                this._sortInfoWindow.height = 70;
                this._sortInfoWindow.paintInHeightDir = false;
                this._sortInfoWindow.y = this._itemWindow.y + this._itemWindow.height - 70;
            } else {
                // Shrink to half bottom box
                this._sortInfoWindow.width = this._itemWindow.width;
                this._sortInfoWindow.height = 120;
                this._sortInfoWindow.paintInHeightDir = true;
                this._sortInfoWindow.y = this._itemWindow.y + this._itemWindow.height - 120;
            }
            // Force the sort window to redraw with the new dimensions
            this._sortInfoWindow.createContents();
            this._sortInfoWindow.refresh();
        }
        
        // Force the item window to recalculate and redraw
        this._itemWindow.createContents();
        this._itemWindow.refresh();
    };

    // ======================================================================
    // 3. Set Max Columns Dynamically
    // ======================================================================
    var _Window_ItemList_maxCols = Window_ItemList.prototype.maxCols;
    Window_ItemList.prototype.maxCols = function() {
        if (SceneManager._scene instanceof Scene_Item && SceneManager._scene._isItemListExpanded) {
            return 2;
        }
        return _Window_ItemList_maxCols.call(this);
    };

    // ======================================================================
    // 4. Fix MSX Category Selection Bug
    // ======================================================================
    Scene_Item.prototype.onCustomCategoryOk = function() {
        this._itemWindow.activate();
        this._itemWindow.select(0); // Replaced MSX's selectLast() with select(0)
    };

})();