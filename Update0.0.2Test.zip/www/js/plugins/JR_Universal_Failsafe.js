/*:
 * @plugindesc v1.96 Universal Failsafe: Bypasses missing assets and generates an ErrorLog/ErrorLog.txt file.
 * @author JR
 *
 * @help
 * Universal Missing Asset Failsafe
 * ============================================================================
 * Normally, RPG Maker MV will try to load a missing image 3 times, causing
 * the game to hang for several seconds. If it fails, it triggers a "Loading Error" 
 * screen and permanently freezes the game. Missing audio files also trap the 
 * game in infinite loading screen loops.
 * 
 * This plugin globally intercepts these failures at the source:
 * 1. Missing images instantly resolve as blank, fully-loaded transparent images
 *    and properly clear their event listeners to prevent memory leaks.
 * 2. Missing audio instantly resolves as a valid 1-sample silent buffer.
 * 3. The audio queue safely releases, preventing BGM/ME restoration bugs and
 *    stopping broken Html5Audio elements from attempting to autoplay.
 * 4. Legitimate fatal errors (like missing JSON data) are left untouched so 
 *    the engine can safely catch them.
 * 
 * Logging System:
 * When a file goes missing, you will see a yellow warning in the F8 console.
 * Additionally, the plugin will create an "ErrorLog" folder in your game's 
 * main directory and overwrite an "ErrorLog.txt" file inside it, listing 
 * all missing files bypassed during that session (deduplicated for performance).
 * 
 * NOTE: This does NOT protect against missing Database JSON files (like 
 * Actors.json), as the game mathematically cannot run without its core data.
 */

(function() {
    'use strict';

    // ====================================================================
    // 0. FILE SYSTEM LOGGING (NW.js Only)
    // ====================================================================
    var _missingAssetsLog = [];
    var _missingAssetsSeen = {};

    var writeToErrorLog = function(assetType, url) {
        // Ensure we are in a desktop environment that supports file writing
        if (typeof require === 'undefined' || typeof process === 'undefined' || !process.mainModule) {
            return;
        }

        // Deduplicate WITHOUT using the timestamp
        var assetKey = assetType + "|" + url;
        if (_missingAssetsSeen[assetKey]) {
            return;
        }
        _missingAssetsSeen[assetKey] = true;

        var timestamp = new Date().toLocaleTimeString();
        var logEntry = "[" + timestamp + "] Missing " + assetType + ": " + url;
        _missingAssetsLog.push(logEntry);

        try {
            var fs = require('fs');
            var path = require('path');
            var baseDirectory = path.dirname(process.mainModule.filename);
            var logDir = path.join(baseDirectory, 'ErrorLog');
            
            // Create the ErrorLog folder if it doesn't exist
            if (!fs.existsSync(logDir)) {
                fs.mkdirSync(logDir);
            }

            var logPath = path.join(logDir, 'ErrorLog.txt');

            var fileContent = "=== Universal Failsafe: Missing Files Log ===\n";
            fileContent += "Session Date: " + new Date().toLocaleDateString() + "\n\n";
            fileContent += _missingAssetsLog.join('\n');

            // Overwrite the file with the updated array
            fs.writeFileSync(logPath, fileContent, 'utf8');
        } catch (e) {
            console.warn("Universal Failsafe: Failed to write to ErrorLog.txt", e);
        }
    };

    // ====================================================================
    // 1. ELIMINATE THE FREEZE & CRASH FOR MEDIA ASSETS ONLY
    // ====================================================================
    if (typeof ResourceHandler !== 'undefined') {
        var _ResourceHandler_createLoader = ResourceHandler.createLoader;
        ResourceHandler.createLoader = function(url, retryMethod, resignMethod, retryInterval) {
            // Bypass the retry cycle entirely for images and audio
            if (typeof url === 'string' && url.match(/\.(?:png|jpe?g|ogg|m4a|mp3)$/i)) {
                return function() {
                    if (resignMethod) {
                        resignMethod();
                    }
                };
            }
            return _ResourceHandler_createLoader.call(this, url, retryMethod, resignMethod, retryInterval);
        };
    }

    // ====================================================================
    // 2. FORCE MISSING IMAGES TO RESOLVE AS A COMPLETED DUMMY
    // ====================================================================
    Bitmap.prototype._onError = function() {
        var missingUrl = this._url || "Unknown Image";
        console.warn("🖼️ Universal Failsafe: Bypassed missing image -> " + missingUrl);
        writeToErrorLog("Image", missingUrl);

        // Clean up native image listeners to prevent memory leaks
        if (this._image) {
            if (this._loadListener) {
                this._image.removeEventListener('load', this._loadListener);
            }
            if (this._errorListener) {
                this._image.removeEventListener('error', this._errorListener);
            }
        }

        // Treat the failed image as successfully completed.
        this._loadingState = 'loaded';

        if (this._callLoadListeners) {
            this._callLoadListeners();
        }
    };

    // ====================================================================
    // 3. PREVENT MISSING AUDIO FROM CRASHING OR FREEZING
    // ====================================================================
    if (typeof AudioManager !== 'undefined') {
        AudioManager.checkWebAudioError = function(webAudio) {
            if (webAudio && webAudio.isError()) {
                var missingUrl = webAudio._url || webAudio.url || "Unknown WebAudio";
                
                if (WebAudio._context && !webAudio._buffer) {
                    try {
                        webAudio._buffer = WebAudio._context.createBuffer(
                            1, 
                            1, 
                            WebAudio._context.sampleRate
                        );
                        
                        webAudio._totalTime = webAudio._buffer.duration;
                        webAudio._loopStart = 0;
                        webAudio._loopLength = 0;

                        // Clear error only after recovery succeeded
                        webAudio._hasError = false;
                        console.warn("🎵 Universal Failsafe: Generated silent buffer for -> " + missingUrl);
                        writeToErrorLog("Audio (WebAudio)", missingUrl);

                        if (typeof webAudio._onLoad === 'function') {
                            webAudio._onLoad();
                        }
                    } catch (e) {
                        console.warn("Universal Failsafe: Could not create silent audio buffer.", e);
                    }
                }
            }
        };
    }

    // HTML5AUDIO FALLBACK FIX
    if (typeof Html5Audio !== 'undefined') {
        var applyHtml5Fix = function() {
            var missingUrl = this._url || this.url || "Unknown Html5Audio";
            console.warn("🎵 Universal Failsafe: Bypassed missing Html5Audio -> " + missingUrl);
            writeToErrorLog("Audio (Html5)", missingUrl);
            
            this._hasError = false;
            this._buffered = true; 
            this._isLoading = false;

            this._autoPlay = false;
            
            if (typeof this._onLoad === 'function') {
                this._onLoad();
            }
        };
        
        if (Html5Audio.prototype && Html5Audio.prototype._onError) {
            Html5Audio.prototype._onError = applyHtml5Fix;
        } else if (Html5Audio._onError) {
            Html5Audio._onError = applyHtml5Fix;
        }
    }

})();