//=============================================================================
// AutoUpdater.js
//=============================================================================

/*:
 * @plugindesc v1.13 Checks for a new game build, supports df.json cleanup, downloads
 * and applies it, then restarts. Shows a version tag on the title screen.
 * @author JR
 *
 * @param Update Server URL
 * @desc URL to a JSON manifest: {"version":"1.1.0","url":"https://.../update.zip", "hash":"..."}
 * @default https://raw.githubusercontent.com/USER/REPO/main/version.json
 *
 * @param Content Folder Name
 * @desc Name of your project's content folder (default MV/MZ uses "www"). Change if yours is renamed.
 * @default www
 *
 * @param Exclude Paths
 * @desc Comma-separated path prefixes (inside the zip) to never overwrite. Protects save data.
 * @default save/
 *
 * @param Connection Timeout
 * @desc Milliseconds to wait for the manifest before assuming "no internet".
 * @default 8000
 *
 * @param Prompt Text
 * @desc Text shown when an update is found. %1 is replaced with the new version number.
 * @default Update version %1 is available! Would you like to download and install it now?
 *
 * @param Version Text Format
 * @desc %1 is replaced with the version number.
 * @default Version %1
 *
 * @param Version Text X
 * @desc X position on title screen. Leave blank for auto (bottom-right).
 * @default
 *
 * @param Version Text Y
 * @desc Y position on title screen. Leave blank for auto (bottom-right).
 * @default
 *
 * @param Version Text Font Size
 * @default 16
 *
 * @param Version Text Color
 * @default #ffffff
 *
 * @help
 * ============================================================================
 * SETUP
 * ============================================================================
 * 1. Host a version.json somewhere reachable (GitHub raw file works well):
 * { "version": "1.1.0", "url": "https://.../update.zip", "hash": "SHA256_STRING" }
 * "url" should point to a zip relative to the folder containing Game.exe.
 * Example ZIP entry: www/js/plugins/AutoUpdater.js
 * Do NOT include your save/ folder in that zip.
 * "hash" should be the SHA-256 hash of your update.zip file.
 *
 * 2. Set "Update Server URL" above to that manifest's raw URL.
 *
 * 3. In your project's www folder, run:
 * npm install adm-zip
 * This plugin requires adm-zip to unpack updates. It must be installed
 * inside www so require('adm-zip') can resolve it after export.
 *
 * 4. Build/export your game as usual. The local version record is created
 * automatically on first run (defaults to 0.0.0, so your very first
 * manifest version will always be treated as "newer").
 *
 * 5. Test this on an actual EXPORTED build, not inside the editor's
 * Playtest window. Playtest does not have the same exe/www layout and
 * the restart step will not behave correctly there.
 *
 * PLATFORM SUPPORT
 * Automatic updates and the title version label run only in desktop NW.js.
 * Mobile and browser builds skip the update scene and hide the version label.
 * You may leave this plugin ON when exporting for mobile/browser.
 *
 * OPTIONAL FILE AND FOLDER CLEANUP
 * Put df.json at the ROOT of update.zip, next to www/, not inside www/.
 * Example:
 * {"files":["www/img/Old.png"],"folders":["www/img/old_assets"]}
 * Paths are relative to the folder containing Game.exe.
 * Use exact paths. No wildcards, absolute paths or '..'.
 * Both files and folders are optional arrays; at least one must be present.
 * folders removes ALL contents, subfolders, then the named folder itself.
 * Standalone files are removed first, then folder trees from inside out.
 * Files covered by folders and nested/duplicate folders are deduplicated.
 * Missing paths are skipped. No df.json means no deletion.
 * The game root, content root and protected paths cannot be deleted.
 * A folder containing a protected path or a ZIP entry is also refused.
 * Entire folder trees are checked before any update writes.
 * Newly added files during cleanup are not swept: nonempty folders cause
 * an error rather than recursively deleting unexpected new contents.
 * df.json is read directly from the verified ZIP and is not extracted.
 * Save folders, Exclude Paths and the version record are protected.
 * All paths are checked before extraction; links are refused.
 * Cleanup runs after extraction and before recording the new version.
 * The update screen shows "Cleaning up redundant files:" and a path below.
 * Cleanup is asynchronous so the update screen can keep rendering.
 * Rapid file operations may finish between screen refreshes.
 * Invalid cleanup instructions abort the update before extraction.
 * I/O errors may still leave a partially applied update; no rollback.
 * Keep the deletion list cumulative for players skipping older releases.
 * Remove a path from this list if you reintroduce that file.
 *
 * FIRST ROLLOUT: old clients cannot execute these new cleanup instructions.
 * First distribute this plugin, then use df.json in a later update.
 * Clients older than v1.13 do not support folders; upgrade them first.
 * Keep this plugin's filename AutoUpdater.js.
 *
 * This plugin does not modify the core scripts; it hooks SceneManager.run
 * so its update check runs before Scene_Boot.
 * ============================================================================
 */

//-----------------------------------------------------------------------------
// AutoUpdater — core logic (Node/NW.js side)
//-----------------------------------------------------------------------------

var AutoUpdater = {};

// No Node.js modules are loaded when this check returns false.
AutoUpdater.isDesktopRuntime = function() {
    return typeof Utils !== 'undefined' &&
        typeof Utils.isNwjs === 'function' && Utils.isNwjs() &&
        !(typeof Utils.isMobileDevice === 'function' && Utils.isMobileDevice()) &&
        typeof require === 'function';
};

AutoUpdater.params = PluginManager.parameters('AutoUpdater');
AutoUpdater.manifestUrl = String(AutoUpdater.params['Update Server URL'] || '');
AutoUpdater.versionFile = 'config.bin';
AutoUpdater.excludePaths = String(AutoUpdater.params['Exclude Paths'] || 'save/')
    .split(',').map(function(s) { return s.trim(); }).filter(function(s) { return s; });
AutoUpdater.timeoutMs = Number(AutoUpdater.params['Connection Timeout'] || 8000);
AutoUpdater.contentFolderName = String(AutoUpdater.params['Content Folder Name'] || 'www');
AutoUpdater.promptText = String(AutoUpdater.params['Prompt Text'] || 'Update version %1 is available! Would you like to download and install it now?');

// Folder that contains Game.exe (one level above your content folder, e.g. "www").
// Locates the configured content-folder name in the running script's path and
// returns everything above it. Falls back to "one level up" if that name
// isn't found (e.g. if it was renamed but the parameter wasn't updated).
AutoUpdater.getBaseDir = function() {
    var path = require('path');
    var scriptDir = path.dirname(process.mainModule.filename);
    var parts = scriptDir.split(path.sep);
    var idx = parts.lastIndexOf(AutoUpdater.contentFolderName);
    if (idx !== -1) {
        var base = parts.slice(0, idx).join(path.sep);
        return base || path.sep;
    }
    return path.join(scriptDir, '..');
};

AutoUpdater.getVersionFilePath = function() {
    var path = require('path');
    return path.join(AutoUpdater.getBaseDir(), AutoUpdater.versionFile);
};

AutoUpdater.readLocalVersion = function() {
    var fs = require('fs');
    try {
        var raw = fs.readFileSync(AutoUpdater.getVersionFilePath(), 'utf8');

        // Backward compatibility
        if (raw.trim().indexOf('{') === 0) {
            return JSON.parse(raw).version || '0.0.0';
        }

        // Decode the Base64 string
        var decoded = Buffer.from(raw, 'base64').toString('utf8');
        var data = JSON.parse(decoded);
        return data.version || '0.0.0';
    } catch (e) {
        return '0.0.0';
    }
};

AutoUpdater.writeLocalVersion = function(version) {
    var fs = require('fs');
    var jsonString = JSON.stringify({ version: version });

    // Base64 encoding is not encryption.
    var encoded = Buffer.from(jsonString, 'utf8').toString('base64');
    var root = AutoUpdater.checkedRoot(AutoUpdater.getBaseDir());
    var target = AutoUpdater.checkedTarget(root, AutoUpdater.versionFile, false);
    fs.writeFileSync(target, encoded);
};

AutoUpdater.isNewer = function(remote, local) {
    var r = String(remote).split('.').map(Number);
    var l = String(local).split('.').map(Number);
    var len = Math.max(r.length, l.length);
    for (var i = 0; i < len; i++) {
        var rv = r[i] || 0, lv = l[i] || 0;
        if (rv > lv) return true;
        if (rv < lv) return false;
    }
    return false;
};

// GET with timeout + redirect following, returns raw string body.
AutoUpdater.httpGet = function(url, callback, redirectCount) {
    redirectCount = redirectCount || 0;
    if (redirectCount > 5) {
        callback(new Error('Too many redirects'));
        return;
    }
    var lib = url.indexOf('https') === 0 ? require('https') : require('http');
    var req = lib.get(url, function(res) {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
            res.resume();
            AutoUpdater.httpGet(res.headers.location, callback, redirectCount + 1);
            return;
        }
        if (res.statusCode !== 200) {
            res.resume();
            callback(new Error('HTTP ' + res.statusCode));
            return;
        }
        var chunks = [];
        res.on('data', function(c) {
            chunks.push(c);
        });
        res.on('end', function() {
            callback(null, Buffer.concat(chunks).toString('utf8'));
        });
    });
    req.setTimeout(AutoUpdater.timeoutMs, function() {
        req.abort();
        callback(new Error('Timeout'));
    });
    req.on('error', function(err) {
        callback(err);
    });
};

AutoUpdater.fetchManifest = function(callback) {
    AutoUpdater.httpGet(AutoUpdater.manifestUrl, function(err, body) {
        if (err) {
            callback(err);
            return;
        }
        try {
            callback(null, JSON.parse(body));
        } catch (e) {
            callback(e);
        }
    });
};

AutoUpdater.downloadFile = function(url, dest, onProgress, callback, redirectCount) {
    redirectCount = redirectCount || 0;
    if (redirectCount > 5) {
        callback(new Error('Too many redirects'));
        return;
    }
    var fs = require('fs');
    var lib = url.indexOf('https') === 0 ? require('https') : require('http');
    var req = lib.get(url, function(res) {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
            res.resume();
            AutoUpdater.downloadFile(
                res.headers.location, dest, onProgress, callback, redirectCount + 1
            );
            return;
        }
        if (res.statusCode !== 200) {
            res.resume();
            callback(new Error('HTTP ' + res.statusCode));
            return;
        }
        var total = parseInt(res.headers['content-length'] || '0', 10);
        var received = 0;
        var file = fs.createWriteStream(dest);
        res.on('data', function(chunk) {
            received += chunk.length;
            if (total) onProgress(Math.floor((received / total) * 100));
        });
        res.pipe(file);
        file.on('finish', function() {
            file.close(function() {
                callback(null);
            });
        });
        file.on('error', function(err) {
            callback(err);
        });
    });
    req.setTimeout(AutoUpdater.timeoutMs * 4, function() {
        req.abort();
        callback(new Error('Download timeout'));
    });
    req.on('error', function(err) {
        callback(err);
    });
};

//-----------------------------------------------------------------------------
// SHA-256 verification
//-----------------------------------------------------------------------------

AutoUpdater.calculateFileHash = function(filePath, callback) {
    var fs = require('fs');
    var crypto = require('crypto');
    var hash = crypto.createHash('sha256');
    var stream = fs.createReadStream(filePath);

    stream.on('data', function(data) {
        hash.update(data);
    });

    stream.on('end', function() {
        callback(null, hash.digest('hex'));
    });

    stream.on('error', function(err) {
        callback(err);
    });
};

//-----------------------------------------------------------------------------
// Path validation
//-----------------------------------------------------------------------------

// Paths use strict portable Windows rules, even when tested on another OS.
AutoUpdater.cleanRelativePath = function(value, directory) {
    if (typeof value !== 'string' || !value) {
        throw new Error('Empty/invalid path');
    }
    var name = value.replace(/\\/g, '/');
    if (directory) name = name.replace(/\/$/, '');
    var parts = name.split('/');
    parts.forEach(function(part) {
        if (!part || part === '.' || part === '..' ||
            /[\x00-\x1f\x7f<>:"|?*]/.test(part) || /[. ]$/.test(part) ||
            /^(con|prn|aux|nul|com[0-9]|lpt[0-9])(?:\.|$)/i.test(part)) {
            throw new Error('Unsafe path: ' + value);
        }
    });
    return parts.join('/');
};

AutoUpdater.pathKey = function(value) {
    return value.replace(/\\/g, '/').toLowerCase();
};

AutoUpdater.isWithin = function(root, target) {
    var path = require('path');
    var rel = path.relative(root, target);
    return !!rel && rel !== '..' && rel.indexOf('..' + path.sep) !== 0 &&
        !path.isAbsolute(rel);
};

// Fail closed if the configured game root disagrees with the running EXE.
AutoUpdater.checkedRoot = function(destDir) {
    var fs = require('fs');
    var path = require('path');
    var root = fs.realpathSync(destDir);
    var exeDir = fs.realpathSync(path.dirname(process.execPath));
    var same = process.platform === 'win32' ?
        root.toLowerCase() === exeDir.toLowerCase() : root === exeDir;
    if (!same || path.dirname(root) === root) {
        throw new Error('Cannot safely identify the game folder');
    }
    return root;
};

// Inspect EVERY existing component; never follow symlinks/junctions.
AutoUpdater.checkedTarget = function(root, name, directory) {
    var fs = require('fs');
    var path = require('path');
    name = AutoUpdater.cleanRelativePath(name, directory);
    var target = path.resolve(root, name);
    if (!AutoUpdater.isWithin(root, target)) {
        throw new Error('Path outside game');
    }
    var parts = name.split('/');
    var current = root;
    for (var i = 0; i < parts.length; i++) {
        current = path.join(current, parts[i]);
        var stat;
        try {
            stat = fs.lstatSync(current);
        } catch (e) {
            if (e.code === 'ENOENT') return target;
            throw e;
        }
        if (stat.isSymbolicLink()) {
            throw new Error('Link path refused: ' + name);
        }
        if (!AutoUpdater.isWithin(root, fs.realpathSync(current))) {
            throw new Error('Resolved path outside game: ' + name);
        }
        var needsDir = i < parts.length - 1 || directory;
        if (needsDir ? !stat.isDirectory() : !stat.isFile()) {
            throw new Error('Unexpected file/folder type: ' + name);
        }
        if (!needsDir && stat.nlink > 1) {
            throw new Error('Hard-linked file refused: ' + name);
        }
    }
    return target;
};

AutoUpdater.protectedPaths = function(excludeList) {
    var content = AutoUpdater.cleanRelativePath(AutoUpdater.contentFolderName, true);
    var result = ['save', content + '/save', AutoUpdater.versionFile, 'df.json'];
    (excludeList || []).forEach(function(value) {
        value = AutoUpdater.cleanRelativePath(value, true);
        result.push(value);
        if (AutoUpdater.pathKey(value).indexOf(AutoUpdater.pathKey(content) + '/') !== 0) {
            result.push(content + '/' + value);
        }
    });
    return result.map(AutoUpdater.pathKey);
};

AutoUpdater.isProtected = function(name, protectedList) {
    var key = AutoUpdater.pathKey(name);
    return protectedList.some(function(ex) {
        return key === ex || key.indexOf(ex + '/') === 0;
    });
};

AutoUpdater.ensureDirectory = function(root, dir) {
    var fs = require('fs');
    var path = require('path');
    if (dir === root) return;
    var rel = path.relative(root, dir).replace(/\\/g, '/');
    AutoUpdater.checkedTarget(root, rel, true);
    AutoUpdater.ensureDirectory(root, path.dirname(dir));
    try {
        fs.mkdirSync(dir);
    } catch (e) {
        if (e.code !== 'EEXIST') throw e;
    }
    AutoUpdater.checkedTarget(root, rel, true);
};

//-----------------------------------------------------------------------------
// Cleanup preflight
//-----------------------------------------------------------------------------

// Preflight cleanup and build an explicit, non-recursive deletion queue.
AutoUpdater.buildCleanupPlan = function(root, data, protectedList, zipNames) {
    var fs = require('fs');
    var path = require('path');
    var own = Object.prototype.hasOwnProperty;

    if (!data || typeof data !== 'object' || Array.isArray(data)) {
        throw new Error('df.json must be an object');
    }

    var hasFiles = own.call(data, 'files');
    var hasFolders = own.call(data, 'folders');

    if ((!hasFiles && !hasFolders) ||
        (hasFiles && !Array.isArray(data.files)) ||
        (hasFolders && !Array.isArray(data.folders))) {
        throw new Error('df.json requires files and/or folders arrays');
    }

    var zipKeys = Object.keys(zipNames);
    var content = AutoUpdater.pathKey(
        AutoUpdater.cleanRelativePath(AutoUpdater.contentFolderName, true)
    );

    function covers(parent, child) {
        return parent === child || child.indexOf(parent + '/') === 0;
    }

    function validate(name, directory) {
        var key = AutoUpdater.pathKey(name);

        if (AutoUpdater.isProtected(name, protectedList) ||
            (directory && (covers(key, content) || protectedList.some(function(ex) {
                return covers(key, ex);
            })))) {
            throw new Error('Protected cleanup path: ' + name);
        }

        if (zipKeys.some(function(zipKey) {
            return covers(key, zipKey) ||
                (zipNames[zipKey] === 'file' && covers(zipKey, key));
        })) {
            throw new Error('Path both installed and deleted: ' + name);
        }

        return AutoUpdater.checkedTarget(root, name, directory);
    }

    function unique(values, directory) {
        var seen = Object.create(null);
        var result = [];

        values.forEach(function(value) {
            var name = AutoUpdater.cleanRelativePath(value, directory);
            validate(name, directory);
            var key = AutoUpdater.pathKey(name);

            if (!seen[key]) {
                seen[key] = true;
                result.push(name);
            }
        });

        return result;
    }

    var folders = unique(hasFolders ? data.folders : [], true);
    var files = unique(hasFiles ? data.files : [], false);
    var folderKeys = Object.create(null);

    folders.forEach(function(name) {
        folderKeys[AutoUpdater.pathKey(name)] = true;
    });

    function coveredByFolder(name, includeSelf) {
        var parts = AutoUpdater.pathKey(name).split('/');
        if (!includeSelf) parts.pop();

        while (parts.length) {
            if (folderKeys[parts.join('/')]) return true;
            parts.pop();
        }

        return false;
    }

    folders = folders.filter(function(name) {
        return !coveredByFolder(name, false);
    });

    var jobs = files.filter(function(name) {
        return !coveredByFolder(name, true);
    }).map(function(name) {
        return { name: name, directory: false };
    });

    folders.forEach(function(folder) {
        var stack = [{
            name: folder,
            directory: true,
            visited: false
        }];

        while (stack.length) {
            var item = stack.pop();
            var target = validate(item.name, item.directory);

            if (!item.directory || item.visited) {
                jobs.push({
                    name: item.name,
                    directory: item.directory
                });
                continue;
            }

            var children;
            try {
                children = fs.readdirSync(target);
            } catch (e) {
                if (e.code === 'ENOENT') continue;
                throw e;
            }

            stack.push({
                name: item.name,
                directory: true,
                visited: true
            });

            for (var i = children.length - 1; i >= 0; i--) {
                var childName = AutoUpdater.cleanRelativePath(
                    item.name + '/' + children[i], false
                );

                var stat;
                try {
                    stat = fs.lstatSync(path.join(target, children[i]));
                } catch (e) {
                    if (e.code === 'ENOENT') continue;
                    throw e;
                }

                // checkedTarget rejects links, hard links and special files.
                validate(childName, stat.isDirectory());

                stack.push({
                    name: childName,
                    directory: stat.isDirectory(),
                    visited: false
                });
            }
        }
    });

    return jobs;
};

//-----------------------------------------------------------------------------
// ZIP extraction
//-----------------------------------------------------------------------------

AutoUpdater.extractZip = function(zipPath, destDir, excludeList, onStatus, onComplete) {
    var AdmZip = require('adm-zip');
    var fs = require('fs');
    var path = require('path');

    var root = AutoUpdater.checkedRoot(destDir);
    var zip = new AdmZip(zipPath);
    var protectedList = AutoUpdater.protectedPaths(excludeList);
    var entries = [];
    var names = Object.create(null);
    var dfEntry = null;
    var deletions = [];

    // Validate all archive names before writing any files.
    zip.getEntries().forEach(function(entry) {
        var name = AutoUpdater.cleanRelativePath(entry.entryName, entry.isDirectory);
        var key = AutoUpdater.pathKey(name);

        if (names[key]) {
            throw new Error('Duplicate ZIP path: ' + name);
        }

        names[key] = entry.isDirectory ? 'directory' : 'file';

        var unixType = (Number(entry.header && entry.header.attr) >>> 16) & 0xf000;
        if (unixType && unixType !== 0x8000 && unixType !== 0x4000) {
            throw new Error('Special ZIP entry refused: ' + name);
        }

        if (key === 'df.json') {
            if (entry.isDirectory) {
                throw new Error('df.json must be a file');
            }
            dfEntry = entry;
            return;
        }

        if (AutoUpdater.isProtected(name, protectedList)) return;

        AutoUpdater.checkedTarget(root, name, entry.isDirectory);
        entries.push({
            name: name,
            entry: entry
        });
    });

    // Catch file-vs-directory conflicts in the archive before extraction.
    Object.keys(names).forEach(function(key) {
        var parts = key.split('/');
        parts.pop();

        while (parts.length) {
            if (names[parts.join('/')] === 'file') {
                throw new Error('ZIP file/folder conflict: ' + key);
            }
            parts.pop();
        }
    });

    if (dfEntry) {
        var data = JSON.parse(
            dfEntry.getData().toString('utf8').replace(/^\uFEFF/, '')
        );
        deletions = AutoUpdater.buildCleanupPlan(
            root, data, protectedList, names
        );
    }

    // Validate the version record too, before changing the client.
    AutoUpdater.checkedTarget(root, AutoUpdater.versionFile, false);

    entries.forEach(function(item) {
        if (item.entry.isDirectory) return;

        var outPath = AutoUpdater.checkedTarget(root, item.name, false);
        var bytes = item.entry.getData();

        AutoUpdater.ensureDirectory(root, path.dirname(outPath));
        AutoUpdater.checkedTarget(root, item.name, false);

        fs.writeFileSync(outPath, bytes);
    });

    if (typeof onComplete === 'function') {
        AutoUpdater.cleanupFiles(root, deletions, onStatus, onComplete);
        return;
    }

    // Preserve the original synchronous API for callers without callbacks.
    var deleted = 0;

    deletions.forEach(function(job) {
        var target = AutoUpdater.checkedTarget(
            root, job.name, job.directory
        );

        try {
            if (job.directory) fs.rmdirSync(target);
            else fs.unlinkSync(target);
            deleted++;
        } catch (e) {
            if (e.code !== 'ENOENT') throw e;
        }
    });

    console.log('AutoUpdater: cleanup complete; entries deleted: ' + deleted);
};

//-----------------------------------------------------------------------------
// Asynchronous file/folder cleanup
//-----------------------------------------------------------------------------

// Delete sequentially, yielding to the UI without a delay for every file.
AutoUpdater.cleanupFiles = function(root, files, onStatus, onComplete) {
    var fs = require('fs');

    files = files.map(function(item) {
        return typeof item === 'string' ?
            { name: item, directory: false } : item;
    });

    var index = 0;
    var deleted = 0;
    var finished = false;
    var lastStatusAt = 0;
    var sliceStarted = Date.now();
    var shownAt = 0;

    function finish(err) {
        if (finished) return;
        finished = true;

        if (err) {
            onComplete(err);
            return;
        }

        console.log('AutoUpdater: cleanup complete; entries deleted: ' + deleted);

        // Keep short cleanups visible without slowing each individual deletion.
        var remaining = shownAt ?
            Math.max(0, 200 - (Date.now() - shownAt)) : 0;

        if (remaining) {
            setTimeout(function() {
                onComplete(null);
            }, remaining);
        } else {
            onComplete(null);
        }
    }

    function showPath(name) {
        if (typeof onStatus === 'function') {
            onStatus('Cleaning up redundant files:\n' + name);
        }
        lastStatusAt = Date.now();
    }

    function step() {
        if (finished) return;

        if (index >= files.length) {
            finish(null);
            return;
        }

        var job = files[index++];
        var name = job.name;
        var target;

        try {
            // Limit bitmap redraws while processing many small files.
            if (Date.now() - lastStatusAt >= 50 || index === files.length) {
                showPath(name);
            }

            // Recheck immediately before deletion, after the initial validation.
            target = AutoUpdater.checkedTarget(root, name, job.directory);

            // rmdir only removes an empty directory. No recursive deletion here.
            var remove = job.directory ? fs.rmdir : fs.unlink;

            remove.call(fs, target, function(err) {
                if (finished) return;

                if (err && err.code !== 'ENOENT') {
                    finish(err);
                    return;
                }

                if (!err) deleted++;

                if (Date.now() - sliceStarted >= 8) {
                    setTimeout(function() {
                        sliceStarted = Date.now();
                        step();
                    }, 0);
                } else {
                    step();
                }
            });
        } catch (e) {
            finish(e);
        }
    }

    if (!files.length) {
        finish(null);
        return;
    }

    try {
        showPath(files[0].name);
        shownAt = Date.now();
    } catch (e) {
        finish(e);
        return;
    }

    // Let the scene render the cleanup heading before starting disk operations.
    setTimeout(function() {
        sliceStarted = Date.now();
        step();
    }, 32);
};

//-----------------------------------------------------------------------------
// Restart
//-----------------------------------------------------------------------------

AutoUpdater.restartGame = function() {
    if (!AutoUpdater.isDesktopRuntime()) return;

    var path = require('path');
    var child_process = require('child_process');
    var gui = require('nw.gui');
    var exePath = process.execPath;
    var args = process.argv.slice(1);

    try {
        child_process.spawn(exePath, args, {
            detached: true,
            stdio: 'ignore',
            cwd: path.dirname(exePath)
        }).unref();
    } catch (e) {
        console.error('AutoUpdater restart failed:', e);
    }

    gui.App.quit();
};

//-----------------------------------------------------------------------------
// Main entry point
//-----------------------------------------------------------------------------

// onStatus(text) — called with progress strings
// onDone() — no update available / update skipped / error → proceed to normal boot
// onUpdated() — update applied successfully → caller should restart
AutoUpdater.run = function(onStatus, onDone, onUpdated) {
    if (!AutoUpdater.isDesktopRuntime()) {
        onDone();
        return;
    }

    var fs = require('fs');
    var path = require('path');

    if (!AutoUpdater.manifestUrl) {
        onDone();
        return;
    }

    onStatus('Checking for updates...');

    AutoUpdater.fetchManifest(function(err, manifest) {
        if (err || !manifest || !manifest.version || !manifest.url) {
            // No internet, server unreachable, or bad manifest — skip silently.
            onDone();
            return;
        }

        var localVersion = AutoUpdater.readLocalVersion();

        if (!AutoUpdater.isNewer(manifest.version, localVersion)) {
            onDone();
            return;
        }

        var promptMessage = AutoUpdater.promptText.replace('%1', manifest.version);
        var wantsUpdate = window.confirm(promptMessage);

        if (!wantsUpdate) {
            // User clicked "Cancel", skip the update and boot the game normally.
            onDone();
            return;
        }

        onStatus('New version ' + manifest.version + ' found. Downloading... 0%');

        var tmpZip = path.join(
            require('os').tmpdir(),
            'game_update_' + Date.now() + '.zip'
        );

        AutoUpdater.downloadFile(manifest.url, tmpZip, function(pct) {
            onStatus('Downloading update... ' + pct + '%');
        }, function(err) {
            if (err) {
                console.error('AutoUpdater download failed:', err);
                onStatus('Update download failed. Continuing...');
                setTimeout(onDone, 1200);
                return;
            }

            if (!manifest.hash) {
                console.error('AutoUpdater: Manifest missing hash. Aborting update.');
                onStatus('Update verification failed (no hash). Continuing...');
                fs.unlink(tmpZip, function() {});
                setTimeout(onDone, 1200);
                return;
            }

            onStatus('Verifying update integrity...');

            AutoUpdater.calculateFileHash(tmpZip, function(hashErr, calculatedHash) {
                if (hashErr || calculatedHash !== manifest.hash) {
                    console.error(
                        'AutoUpdater hash mismatch! Expected:',
                        manifest.hash,
                        'Got:',
                        calculatedHash
                    );
                    onStatus('Update verification failed! Continuing...');
                    fs.unlink(tmpZip, function() {});
                    setTimeout(onDone, 1200);
                    return;
                }

                onStatus('Applying update...');

                var applyFinished = false;

                function finishApply(err) {
                    if (applyFinished) return;
                    applyFinished = true;

                    if (!err) {
                        try {
                            AutoUpdater.writeLocalVersion(manifest.version);
                        } catch (e) {
                            err = e;
                        }
                    }

                    fs.unlink(tmpZip, function() {});

                    if (err) {
                        console.error('AutoUpdater apply failed:', err);
                        onStatus('Failed to apply update. Continuing...');
                        setTimeout(onDone, 1200);
                        return;
                    }

                    onStatus('Update applied. Restarting...');
                    setTimeout(onUpdated, 800);
                }

                try {
                    AutoUpdater.extractZip(
                        tmpZip,
                        AutoUpdater.getBaseDir(),
                        AutoUpdater.excludePaths,
                        onStatus,
                        finishApply
                    );
                } catch (e) {
                    finishApply(e);
                }
            });
        });
    });
};

//-----------------------------------------------------------------------------
// Scene_UpdateCheck — runs before Scene_Boot
//-----------------------------------------------------------------------------

function Scene_UpdateCheck() {
    this.initialize.apply(this, arguments);
}

// Inherit directly from Stage (PIXI) instead of Scene_Base to avoid plugin conflicts.
Scene_UpdateCheck.prototype = Object.create(Stage.prototype);
Scene_UpdateCheck.prototype.constructor = Scene_UpdateCheck;

Scene_UpdateCheck.prototype.initialize = function() {
    if (Stage.prototype.initialize) {
        Stage.prototype.initialize.call(this);
    } else {
        PIXI.Container.call(this);
    }

    this._statusText = '';
    this._finished = false;
};

Scene_UpdateCheck.prototype.create = function() {
    var backSprite = new Sprite(new Bitmap(Graphics.width, Graphics.height));
    backSprite.bitmap.fillAll('#000000');
    this.addChild(backSprite);

    this._statusSprite = new Sprite(new Bitmap(Graphics.width, 88));
    this._statusSprite.y = Graphics.height - 120;
    this.addChild(this._statusSprite);
};

// Add standard SceneManager lifecycle methods that Scene_Base used to provide.
Scene_UpdateCheck.prototype.update = function() {
    for (var i = 0; i < this.children.length; i++) {
        if (this.children[i] && this.children[i].update) {
            this.children[i].update();
        }
    }
};

Scene_UpdateCheck.prototype.isReady = function() {
    return true;
};

Scene_UpdateCheck.prototype.isBusy = function() {
    return false;
};

Scene_UpdateCheck.prototype.stop = function() {};
Scene_UpdateCheck.prototype.terminate = function() {};
Scene_UpdateCheck.prototype.attachReservation = function() {};
Scene_UpdateCheck.prototype.detachReservation = function() {};
Scene_UpdateCheck.prototype.initCustomWindowPositions = function() {};

Scene_UpdateCheck.prototype.setStatus = function(text) {
    this._statusText = String(text);

    var bmp = this._statusSprite.bitmap;
    var lines = this._statusText.split('\n');

    bmp.clear();
    bmp.textColor = '#ffffff';
    bmp.fontSize = 22;

    var padding = 20;
    var width = Math.max(1, bmp.width - padding * 2);

    if (lines.length === 1) {
        bmp.drawText(
            lines[0], padding, 0, width, bmp.height, 'center'
        );
    } else {
        bmp.drawText(
            lines[0], padding, 8, width, 32, 'center'
        );

        bmp.fontSize = 18;

        bmp.drawText(
            lines.slice(1).join(' '), padding, 42, width, 30, 'center'
        );
    }
};

Scene_UpdateCheck.prototype.start = function() {
    var self = this;

    if (!AutoUpdater.isDesktopRuntime() || Utils.isOptionValid('test')) {
        this.proceed();
        return;
    }

    AutoUpdater.run(
        function(status) {
            self.setStatus(status);
        },
        function() {
            self.proceed();
        },
        function() {
            AutoUpdater.restartGame();
        }
    );
};

Scene_UpdateCheck.prototype.proceed = function() {
    if (this._finished) return;

    this._finished = true;
    SceneManager.goto(Scene_Boot);
};

var _AutoUpdater_SceneManager_run = SceneManager.run;

SceneManager.run = function(sceneClass) {
    var firstScene = AutoUpdater.isDesktopRuntime() ?
        Scene_UpdateCheck : sceneClass;

    _AutoUpdater_SceneManager_run.call(this, firstScene);
};

//-----------------------------------------------------------------------------
// Scene_Title — version tag
//-----------------------------------------------------------------------------

var _AutoUpdater_Scene_Title_createForeground =
    Scene_Title.prototype.createForeground;

Scene_Title.prototype.createForeground = function() {
    _AutoUpdater_Scene_Title_createForeground.call(this);
    this.createVersionText();
};

Scene_Title.prototype.createVersionText = function() {
    if (!AutoUpdater.isDesktopRuntime()) return;

    var version = AutoUpdater.readLocalVersion();
    var format = String(
        AutoUpdater.params['Version Text Format'] || 'Version %1'
    );
    var text = format.replace('%1', version);

    var w = 300;
    var h = 40;
    var sprite = new Sprite(new Bitmap(w, h));

    sprite.bitmap.fontSize = Number(
        AutoUpdater.params['Version Text Font Size'] || 16
    );
    sprite.bitmap.textColor = String(
        AutoUpdater.params['Version Text Color'] || '#ffffff'
    );
    sprite.bitmap.drawText(text, 0, 0, w, h, 'right');

    var xParam = AutoUpdater.params['Version Text X'];
    var yParam = AutoUpdater.params['Version Text Y'];

    sprite.x = (xParam === '' || xParam === undefined) ?
        Graphics.width - w - 10 : Number(xParam);

    sprite.y = (yParam === '' || yParam === undefined) ?
        Graphics.height - h - 10 : Number(yParam);

    this.addChild(sprite);
};