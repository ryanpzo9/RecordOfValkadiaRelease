/*:
 * @plugindesc Adds a draggable vertical scrollbar and fixes number overlap.
 * @author JR
 * @help 
 * This plugin creates a visual scroll track and thumb that can be clicked 
 * and dragged with a mouse or touch screen.
 * 
 * Please place this plugin BELOW ItemMenuExtension, YEP_ItemCore, YEP_SkillCore, 
 * YEP_ShopMenuCore, YEP_ItemSynthesis, recipecrafting, JR_Bestiary, and YEP_SkillLearnSystem.
 * 
 * @param Number Padding
 * @type number
 * @min 0
 * @default 20
 * @desc How many pixels to push the item numbers/skill costs/prices to the left to avoid overlapping the scrollbar.
 */
(function() {

    // Fetch the plugin parameter dynamically
    var scriptName = document.currentScript ? document.currentScript.src.match(/([^\/]+)\.js/)[1] : 'JR';
    var parameters = PluginManager.parameters(scriptName);
    var numberPadding = Number(parameters['Number Padding'] || 20);

    // ======================================================================
    // 1. Create the Scrollbar Sprite Class
    // ======================================================================
    function Sprite_JRScrollBar() {
        this.initialize.apply(this, arguments);
    }
    
    Sprite_JRScrollBar.prototype = Object.create(Sprite.prototype);
    Sprite_JRScrollBar.prototype.constructor = Sprite_JRScrollBar;

    Sprite_JRScrollBar.prototype.initialize = function(parentWindow) {
        Sprite.prototype.initialize.call(this);
        this._parentWindow = parentWindow;
        this.bitmap = new Bitmap(12, 100); 
        this._isDragging = false;
        this.z = 10; 
    };

    Sprite_JRScrollBar.prototype.update = function() {
        Sprite.prototype.update.call(this);
        this.updatePositionAndSize();
        this.updateTouch();
    };

    Sprite_JRScrollBar.prototype.updatePositionAndSize = function() {
        var win = this._parentWindow;
        
        if (!win || !win.isOpen() || !win.visible || win.maxRows() <= win.maxPageRows()) {
            this.visible = false;
            return;
        }
        this.visible = true;

        var padding = win.padding;
        var h = win.height - padding * 2;
        var w = 12; 

        if (this.bitmap.height !== h) {
            this.bitmap = new Bitmap(w, h);
        }

        if (SceneManager._scene instanceof Scene_Item && SceneManager._scene._isItemListExpanded) {
            this.x = win.width / 2 - (w / 2); 
        } else {
            this.x = win.width - padding - w; 
        }
        this.y = padding;

        this.bitmap.clear();
        this.bitmap.fillRect(0, 0, w, h, 'rgba(0, 0, 0, 0.5)'); 

        var maxTopRow = win.maxTopRow();
        var thumbHeight = Math.max(h * (win.maxPageRows() / win.maxRows()), 24); 
        var thumbY = 0;
        
        if (maxTopRow > 0) {
            thumbY = (win.topRow() / maxTopRow) * (h - thumbHeight);
        }
        
        this.bitmap.fillRect(2, thumbY, w - 4, thumbHeight, 'rgba(255, 255, 255, 0.8)');
    };

    Sprite_JRScrollBar.prototype.updateTouch = function() {
        var win = this._parentWindow;
        
        // Prevent dragging if the window is hidden or inactive
        if (!this.visible || !win || !win.active) {
            this._isDragging = false;
            return;
        }
        
        var localY = win.canvasToLocalY(TouchInput.y) - win.padding;
        var localX = win.canvasToLocalX(TouchInput.x);
        
        if (TouchInput.isTriggered()) {
            if (localX >= this.x - 20 && localX <= this.x + this.bitmap.width + 20 && 
                localY >= -20 && localY <= this.bitmap.height + 20) {
                this._isDragging = true;
            }
        }
        
        if (this._isDragging) {
            if (TouchInput.isPressed()) {
                var maxTopRow = win.maxTopRow();
                var h = this.bitmap.height;
                var thumbHeight = Math.max(h * (win.maxPageRows() / win.maxRows()), 24);
                
                var ratio = (localY - (thumbHeight / 2)) / (h - thumbHeight);
                ratio = ratio.clamp(0, 1);
                
                var newTopRow = Math.round(ratio * maxTopRow);
                win.setTopRow(newTopRow);
            } else {
                this._isDragging = false;
            }
        }
    };

    // ======================================================================
    // 2. Inject Scrollbar into relevant Windows (Duplicate-Safe Helper)
    // ======================================================================
    function addScrollBar(win) {
        if (win._jrscrollBar) return;
        win._jrscrollBar = new Sprite_JRScrollBar(win);
        win.addChild(win._jrscrollBar);
    }

    var _Window_ItemList_initialize = Window_ItemList.prototype.initialize;
    Window_ItemList.prototype.initialize = function() {
        _Window_ItemList_initialize.apply(this, arguments);
        addScrollBar(this);
    };

    var _Window_ShopBuy_initialize = Window_ShopBuy.prototype.initialize;
    Window_ShopBuy.prototype.initialize = function() {
        _Window_ShopBuy_initialize.apply(this, arguments);
        addScrollBar(this);
    };
    
    var _Window_SkillList_initialize = Window_SkillList.prototype.initialize;
    Window_SkillList.prototype.initialize = function() {
        _Window_SkillList_initialize.apply(this, arguments);
        addScrollBar(this);
    };

    if (typeof Window_RecipeList !== 'undefined') {
        var _Window_RecipeList_initialize = Window_RecipeList.prototype.initialize;
        Window_RecipeList.prototype.initialize = function() {
            _Window_RecipeList_initialize.apply(this, arguments);
            addScrollBar(this);
        };
    }

    if (typeof Window_BestiaryList !== 'undefined') {
        var _Window_BestiaryList_initialize = Window_BestiaryList.prototype.initialize;
        Window_BestiaryList.prototype.initialize = function() {
            _Window_BestiaryList_initialize.apply(this, arguments);
            addScrollBar(this);
        };
    }

    if (typeof Window_SynthesisList !== 'undefined') {
        var _Window_SynthesisList_initialize = Window_SynthesisList.prototype.initialize;
        Window_SynthesisList.prototype.initialize = function() {
            _Window_SynthesisList_initialize.apply(this, arguments);
            addScrollBar(this);
        };
    }

    // ======================================================================
    // 3. Prevent accidental item selection while dragging
    // ======================================================================
    var _Window_Selectable_processTouch = Window_Selectable.prototype.processTouch;
    Window_Selectable.prototype.processTouch = function() {
        if (this._jrscrollBar && this._jrscrollBar._isDragging) {
            return; 
        }
        _Window_Selectable_processTouch.call(this);
    };

    // ======================================================================
    // 4. Adjust Number/Cost Padding to avoid overlap (Conditional on Scrolling)
    // ======================================================================
    var _Window_ItemList_drawItemNumber = Window_ItemList.prototype.drawItemNumber;
    Window_ItemList.prototype.drawItemNumber = function(item, x, y, width) {
        var adjustedWidth = (this.maxRows() > this.maxPageRows()) ? width - numberPadding : width;
        _Window_ItemList_drawItemNumber.call(this, item, x, y, adjustedWidth);
    };

    var _Window_SkillList_drawSkillCost = Window_SkillList.prototype.drawSkillCost;
    Window_SkillList.prototype.drawSkillCost = function(skill, x, y, width) {
        var adjustedWidth = (this.maxRows() > this.maxPageRows()) ? width - numberPadding : width;
        return _Window_SkillList_drawSkillCost.call(this, skill, x, y, adjustedWidth);
    };

    if (Window_ShopBuy.prototype.drawBuyPrice) {
        var _Window_ShopBuy_drawBuyPrice = Window_ShopBuy.prototype.drawBuyPrice;
        Window_ShopBuy.prototype.drawBuyPrice = function(item, rect) {
            var adjustedWidth = (this.maxRows() > this.maxPageRows()) ? rect.width - numberPadding : rect.width;
            var adjustedRect = new Rectangle(rect.x, rect.y, adjustedWidth, rect.height);
            _Window_ShopBuy_drawBuyPrice.call(this, item, adjustedRect);
        };
    }

    if (typeof Window_RecipeList !== 'undefined') {
        var _Window_RecipeList_drawText = Window_RecipeList.prototype.drawText;
        Window_RecipeList.prototype.drawText = function(text, x, y, maxWidth, align) {
            if (align === 'right' && maxWidth === this.contents.width && this.maxRows() > this.maxPageRows()) {
                maxWidth -= numberPadding;
            }
            _Window_RecipeList_drawText.call(this, text, x, y, maxWidth, align);
        };
    }

    if (typeof Window_BestiaryList !== 'undefined') {
        var _Window_BestiaryList_itemRect = Window_BestiaryList.prototype.itemRect;
        Window_BestiaryList.prototype.itemRect = function(index) {
            var rect = _Window_BestiaryList_itemRect.call(this, index);
            if (this.maxRows() > this.maxPageRows()) {
                rect.width -= numberPadding;
            }
            return rect;
        };
    }

    if (typeof Window_SynthesisList !== 'undefined') {
        var _Window_SynthesisList_drawItemNumber = Window_SynthesisList.prototype.drawItemNumber;
        Window_SynthesisList.prototype.drawItemNumber = function(item, wx, wy, ww) {
            var adjustedWidth = (this.maxRows() > this.maxPageRows()) ? ww - numberPadding : ww;
            _Window_SynthesisList_drawItemNumber.call(this, item, wx, wy, adjustedWidth);
        };
    }

    // Fix for YEP_SkillLearnSystem "Skill Learned!" text Overlap
    if (typeof Window_SkillLearn !== 'undefined') {
        var _Window_SkillLearn_drawItemLearned = Window_SkillLearn.prototype.drawItemLearned;
        Window_SkillLearn.prototype.drawItemLearned = function(skill, wx, wy, ww) {
            // Check if the skill is learned. Unlearned costs are handled by the drawSkillCost alias.
            var isLearned = this._actor.isLearnedSkillRaw(skill.id);
            var adjustedWidth = (isLearned && this.maxRows() > this.maxPageRows()) ? ww - numberPadding : ww;
            _Window_SkillLearn_drawItemLearned.call(this, skill, wx, wy, adjustedWidth);
        };
    }

    // ======================================================================
    // 5. Force refresh on scrollbar state & Handle Vertical Wheel Scrolling
    // ======================================================================
    var _Window_Selectable_update = Window_Selectable.prototype.update;
    Window_Selectable.prototype.update = function() {
        
        // INTERCEPT MOUSE WHEEL BEFORE OTHER PLUGINS SEE IT
        // (Removed the maxRows check so it now applies to ALL multi-column lists)
        if (this.isOpenAndActive() && this.maxCols() > 1) {
            if (TouchInput.wheelY >= 20) {
                var prevIndex = this.index();
                var nextIndex = prevIndex + this.maxCols();
                
                if (nextIndex < this.maxItems()) {
                    this.select(nextIndex);
                    SoundManager.playCursor();
                } else if (this.maxItems() > 0) {
                    // Only snap if the last item is physically on a row below us
                    var currentRow = Math.floor(prevIndex / this.maxCols());
                    var lastItemRow = Math.floor((this.maxItems() - 1) / this.maxCols());
                    
                    if (lastItemRow > currentRow) {
                        this.select(this.maxItems() - 1);
                        SoundManager.playCursor();
                    }
                }
                TouchInput._wheelY = 0; // Wipe the evidence
            } else if (TouchInput.wheelY <= -20) {
                var prevIndex = this.index();
                var upIndex = prevIndex - this.maxCols();
                if (upIndex >= 0) {
                    this.select(upIndex);
                    SoundManager.playCursor();
                }
                TouchInput._wheelY = 0; // Wipe the evidence
            }
        }

        // Run the normal update loop
        _Window_Selectable_update.call(this);

        // Maintain the padding state fix for visual overlap
        if (this._jrscrollBar) {
            var needsPadding = this.maxRows() > this.maxPageRows();
            if (this._jrPaddingState === undefined) {
                this._jrPaddingState = needsPadding;
            } else if (this._jrPaddingState !== needsPadding) {
                this._jrPaddingState = needsPadding;
                this.refresh();
            }
        }
    };

})();