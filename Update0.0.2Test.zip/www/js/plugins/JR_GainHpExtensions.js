//=============================================================================
// JR_GainHpExtensions.js
//=============================================================================
/*:
 * @plugindesc v1.1 Combines Barrier fixes, Undead healing, and Certain Hit bypass.
 * @author JR
 *
 * @param Undead Categories
 * @desc A comma-separated list of state categories that will invert healing into damage.
 * @default Undead, Decay
 *
 * @help
 * ============================================================================
 * Introduction
 * ============================================================================
 * 
 * This plugin safely intercepts the .gainHp() function to apply custom 
 * mechanics. 
 * 
 * Place this plugin BELOW:
 * - YEP_AbsorptionBarrier
 * - YEP_BuffsStatesCore 
 * - YEP_X_StateCategories
 *
 * ============================================================================
 * Feature 1: Absorption Barrier Fix
 * ============================================================================
 * Direct calls to .gainHp(-x) via script calls, events, or slip damage 
 * will now correctly strike the absorption barrier first instead of bypassing it.
 *
 * ============================================================================
 * Feature 2: Undead Healing Inversion
 * ============================================================================
 * If a battler is affected by a state containing one of the categories defined 
 * in the parameters (e.g., <Category: Undead>), healing is inverted to damage.
 * 
 * Script Call:
 *   battler.isGainHpInvert() 
 *   - Returns true if the battler is undead/inverted, false otherwise.
 *
 * ============================================================================
 * Feature 3: Certain Hit Barrier Pierce
 * ============================================================================
 * By default, all skills and items set to "Certain Hit" will completely 
 * bypass the Absorption Barrier, dealing direct HP damage.
 */

var JR = JR || {};
JR.GainHpExt = JR.GainHpExt || {};
JR.GainHpExt.Parameters = PluginManager.parameters('JR_GainHpExtensions');

(function() {
    // Check prerequisites
    if (!Imported.YEP_AbsorptionBarrier || !Imported.YEP_BuffsStatesCore || !Imported.YEP_X_StateCategories) {
        console.warn("JR_GainHpExtensions requires YEP_AbsorptionBarrier, YEP_BuffsStatesCore, and YEP_X_StateCategories.");
    }

    // Parse Undead Categories
    var rawCategories = String(JR.GainHpExt.Parameters['Undead Categories'] || 'Undead, Decay');
    var categoryList = rawCategories.split(',');
    JR.GainHpExt.categories = [];
    for (var i = 0; i < categoryList.length; i++) {
        JR.GainHpExt.categories.push(categoryList[i].trim().toUpperCase());
    }

    // --- Helper Function: Check Undead Status ---
    Game_Battler.prototype.isGainHpInvert = function() {
        if (!Imported.YEP_X_StateCategories) return false;
        for (var i = 0; i < JR.GainHpExt.categories.length; i++) {
            if (this.isStateCategoryAffected(JR.GainHpExt.categories[i])) {
                return true;
            }
        }
        return false;
    };

    // --- Feature 3: Certain Hit Barrier Pierce ---
    if (Imported.YEP_AbsorptionBarrier) {
        var _Game_Action_isAffectBarrierPoints = Game_Action.prototype.isAffectBarrierPoints;
        Game_Action.prototype.isAffectBarrierPoints = function(target, value) {
            if (this.isCertainHit()) return false; // Ignore barrier entirely if Certain Hit
            return _Game_Action_isAffectBarrierPoints.call(this, target, value);
        };
    }

    // --- Prevent Double-Dipping and Track Action Types ---
    var _Game_Action_executeHpDamage = Game_Action.prototype.executeHpDamage;
    Game_Action.prototype.executeHpDamage = function(target, value) {
        target._isActionHpDamage = true;
        target._isCertainHitAction = this.isCertainHit(); // Flag hit type for gainHp logic
        
        _Game_Action_executeHpDamage.call(this, target, value);
        
        target._isActionHpDamage = false;
        target._isCertainHitAction = false;
    };

    // --- Master gainHp Intercept ---
    var _Game_Battler_gainHp = Game_Battler.prototype.gainHp;
    Game_Battler.prototype.gainHp = function(value) {
        var wasInverted = false;

        // 1. Undead Healing Inversion
        if (value > 0 && this.isGainHpInvert()) {
            value = -value; // Flip heal to damage
            wasInverted = true;
        }

        // 2. Barrier Absorption 
        if (value < 0 && this.barrierPoints() > 0) {
            // Never absorb Certain Hit actions, even if they were inverted heals
            if (!this._isCertainHitAction) {
                // Absorb if it's NOT an action (slip damage/events) OR if it was an inverted heal
                if (!this._isActionHpDamage || wasInverted) {
                    var incomingDamage = Math.abs(value);
                    var remainingDamage = this.loseBarrier(incomingDamage, 1, 0);
                    value = -remainingDamage;
                }
            }
        }

        // 3. Apply the final HP change
        _Game_Battler_gainHp.call(this, value);
    };

})();