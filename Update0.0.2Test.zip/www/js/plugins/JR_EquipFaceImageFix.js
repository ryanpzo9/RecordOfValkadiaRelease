/*:
 * @plugindesc Fixes Async Image Loading for Equip, Party, and Item menus.
 * @author Assistant
 * @help Leave this plugin ON to prevent missing faces and sprites.
 * 
 * Please ensure this plugin is placed BELOW YEP_EquipCore and 
 * YEP_PartySystem in your Plugin Manager list.
 */
(function() {
    
    // ======================================================================
    // FIX 1: YEP Equip Core (Window_SkillStatus)
    // ======================================================================
    if (typeof Window_SkillStatus !== 'undefined') {
        var _Window_SkillStatus_refresh = Window_SkillStatus.prototype.refresh;
        
        Window_SkillStatus.prototype.refresh = function() {
            if (this._actor) {
                var faceBitmap = ImageManager.loadFace(this._actor.faceName());
                if (!faceBitmap.isReady()) {
                    faceBitmap.addLoadListener(this.refresh.bind(this));
                }
            }
            _Window_SkillStatus_refresh.call(this);
        };
    }

    // ======================================================================
    // FIX 2: YEP Party System (Window_PartySelect)
    // ======================================================================
    if (typeof Window_PartySelect !== 'undefined') {
        var _Window_PartySelect_drawActor = Window_PartySelect.prototype.drawActor;
        
        Window_PartySelect.prototype.drawActor = function(rect, actor) {
            // Check Face
            if (Yanfly.Param.PartyShowFace) {
                var faceBitmap = ImageManager.loadFace(actor.faceName());
                if (!faceBitmap.isReady()) {
                    faceBitmap.addLoadListener(this.refresh.bind(this));
                }
            }
            
            // Check Sprite
            if (Yanfly.Param.PartyShowCharacter) {
                var charBitmap = ImageManager.loadCharacter(actor.characterName());
                if (!charBitmap.isReady()) {
                    charBitmap.addLoadListener(this.refresh.bind(this));
                }
            }
            
            _Window_PartySelect_drawActor.call(this, rect, actor);
        };
    }

    // ======================================================================
    // FIX 3: Default Actor Select / Menu Status (Window_MenuStatus)
    // ======================================================================
    if (typeof Window_MenuStatus !== 'undefined') {
        var _Window_MenuStatus_drawItemImage = Window_MenuStatus.prototype.drawItemImage;
        
        Window_MenuStatus.prototype.drawItemImage = function(index) {
            var actor = $gameParty.members()[index];
            if (actor) {
                var faceBitmap = ImageManager.loadFace(actor.faceName());
                if (!faceBitmap.isReady()) {
                    // Force this specific row to redraw once the image is ready
                    faceBitmap.addLoadListener(this.redrawItem.bind(this, index));
                }
            }
            
            // Call the original drawing function
            _Window_MenuStatus_drawItemImage.call(this, index);
        };
    }

})();