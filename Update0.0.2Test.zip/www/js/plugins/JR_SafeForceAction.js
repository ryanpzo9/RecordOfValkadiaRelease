/*:
 * @plugindesc v1.40 HP/state reactions, dialogue and last actions for YEP CTB.
 * @author JR
 *
 * @help
 * JR_SafeForceAction.js - v1.40
 * Author: JR
 *
 * 1. INSTALLATION AND PURPOSE
 * ---------------------------
 * Save as js/plugins/JR_SafeForceAction.js, enable it in Plugin Manager,
 * and place it BELOW all of these that you use:
 *   YEP_BattleEngineCore
 *   YEP_X_BattleSysCTB
 *   YEP_X_ActSeqPack1 / 2 / 3
 *   YEP_BuffsStatesCore
 * Keep the existing relative order of the YEP plugins themselves.
 * Battle Engine Core and CTB are required. CTB must be the active system.
 * There are no plugin parameters. Configure enemy notes or battle scripts.
 * Restart your playtest after replacing the file or editing database data.
 *
 * The plugin provides three ways to request a skill:
 *   A. jrSafeForceAction: queue a reaction now.
 *   B. jrSafeForceActionWhen: register a condition to watch during battle.
 *   C. jrLastAction: arm an enemy's final skill for lethal HP damage.
 * Each can optionally run a dialogue common event BEFORE the skill.
 * Ordinary reactions also work for actors. Last actions are enemy-only.
 * Use SKILL IDs, not item IDs, actor IDs or enemy database IDs.
 *
 * Requests wait until the current action sequence, event and movement
 * finish. They do not interrupt actor command input. Existing native
 * Force Action commands are unchanged; use JR calls for deferred behavior.
 *
 * 2. CHOOSING A BATTLER
 * ---------------------
 * Inside an Event Command: Script, select the user first:
 *   var boss = $gameTroop.members()[0];
 *   var secondEnemy = $gameTroop.members()[1];
 *   var actor = $gameActors.actor(3);
 *   var firstPartyMember = $gameParty.battleMembers()[0];
 *
 * Troop/party array positions start at 0. Actor database IDs start at 1.
 * The reacting user must be a living, appeared battle member.
 * Use the correct troop slot even if that enemy moves around visually.
 * These variables are examples, not built-in global variables.
 * Write your variable declaration in the same Script command as the call.
 * Use scripts during battle; registration outside battle is rejected.
 *
 * 3. ALL SUPPORTED ENEMY NOTETAGS
 * -------------------------------
 * Put these in Database > Enemies > the enemy's Notes box.
 * They do not belong in Skill, State, Actor or Troop notes.
 * Use plain keys such as BossPhase2 or LastBreath; avoid commas and >.
 *
 * A. Once-per-battle HP reaction:
 *   <JR Safe Force: 15, 125, BossFinalPhase>
 *
 * 15 = HP percentage, 125 = skill ID, BossFinalPhase = trigger key.
 * After gainHp reduces HP, queue the skill if HP is STRICTLY below 15%
 * and the enemy is still alive. At exactly 15%, it does not trigger.
 * Target defaults to random according to the skill's scope.
 * This tag does not prevent death, and does not trigger merely because
 * an enemy starts below the threshold. A later HP loss is required.
 * For continuous checks or direct setHp changes, use a condition watcher.
 *
 * Multiple HP tags are allowed, for example:
 *   <JR Safe Force: 50, 120, Phase2>
 *   <JR Safe Force: 15, 125, Phase3>
 * One hit can qualify for both; both queue in tag order. They are not
 * mutually exclusive. Use scripted conditions for different behavior.
 *
 * Optional dialogue before the HP reaction:
 *   <JR Safe Force: 15, 125, BossFinalPhase, 12>
 * 12 = common event ID. Omit it or use 0 for no dialogue.
 * This triggers ONCE per battler/key per battle, not on every hit below
 * 15%. Healing above 15% and falling below again does not reset the key.
 * The key is claimed when queued, before dialogue or skill execution.
 *
 * B. Once-per-battle reaction while affected by a state:
 *   <JR Safe Force State: 73, 126, EnrageState>
 * With optional dialogue:
 *   <JR Safe Force State: 73, 126, EnrageState, 13>
 * 73 = STATE database ID, 126 = SKILL ID, EnrageState = key,
 * 13 = common event ID. These go in the ENEMY's Notes, not the State.
 * The enemy must be alive, appeared and actually affected by state 73.
 * Checks run after addState and on battle updates, so an already-present
 * state can qualify. Resisted/unsuccessful applications do not qualify.
 * Reapplying, removing and re-adding the state does not reset the key.
 * Removing the state after queuing does not cancel the reaction.
 * If the queue is full, checks retry while the state remains present.
 * Multiple state tags with different keys can queue different reactions.
 * This does not grant death protection; the Death state is not a way
 * to run a final action. Use JR Last Action for lethal HP damage.
 *
 * HP and state tags are INDEPENDENT triggers, not an AND condition.
 * Use different keys to permit both reactions, or the same key so the
 * first qualifying tag wins (OR, one reaction total). There is no
 * priority rule between unlike triggers; whichever queues first wins.
 * For HP below 15% AND state 73, use this Turn 0 watcher instead:
 *   var boss = $gameTroop.members()[0];
 *   boss.jrSafeForceActionWhen(125, -1, 'afterAction', 'LowHPWithState',
 *       function(user) {
 *           return user.hpRate() < 0.15 && user.isStateAffected(73);
 *       }, 12);
 *
 * C. Final action after lethal HP damage, without dialogue:
 *   <JR Last Action: 125, LastBreath>
 *
 * D. Final action with a dialogue common event:
 *   <JR Last Action: 125, LastBreath, 12>
 *
 * 125 = final skill ID, LastBreath = key, 12 = common event ID.
 * Only the first JR Last Action tag is read. Use one per enemy.
 * Omit the common event or use 0 for no dialogue.
 * Use either a last-action tag OR its script registration, not both.
 * The tag is sufficient by itself; no troop event is required.
 * Tags are case-insensitive; keys are case-sensitive.
 * Invalid tags/skill IDs may be ignored. Check your database IDs.
 *
 * 4. QUEUE AN ORDINARY REACTION NOW
 * --------------------------------
 * Full battler call:
 *   battler.jrSafeForceAction(skillId, target, timing, key, commonEventId);
 *
 * Equivalent BattleManager call:
 *   BattleManager.jrForceAction(battler, skillId, target, timing,
 *       key, commonEventId);
 *
 * Minimal example, repeatable because no key is supplied:
 *   var boss = $gameTroop.members()[0];
 *   boss.jrSafeForceAction(125);
 *
 * Once per battle, with dialogue:
 *   var boss = $gameTroop.members()[0];
 *   boss.jrSafeForceAction(125, -1, 'afterAction', 'Enrage', 12);
 *
 * Keep defaults while specifying later arguments using undefined:
 *   boss.jrSafeForceAction(125, undefined, undefined, 'Enrage', 12);
 *
 * Returns true if queued. Returns false if rejected or already claimed.
 * It queues and returns immediately; it does NOT wait for the skill.
 * Subsequent event commands run before the deferred reaction.
 * Do not put a wait-until-reaction-finishes loop in that event.
 *
 * 5. TARGETS, TIMING AND OPTIONAL ARGUMENTS
 * ----------------------------------------
 * target:
 *   omitted / undefined = -1, random target
 *   -1 = random target
 *   -2 = user's last target, following MV's normal behavior
 *   0, 1, 2, ... = zero-based index in the skill's target unit
 *   battler object = that battler, resolved again at execution
 *
 * For an enemy's opponent skill, 0 means the first party member.
 * For its friend skill, 0 means the first enemy in the troop.
 * The skill's scope still controls self, all-target and random-hit skills.
 * A target argument does not turn an all-target skill into single-target.
 * Numeric targets and dead targets retain normal MV targeting/fallback.
 * An explicit object in the wrong unit, removed or hidden is invalid:
 * ordinary reactions skip it; last actions fall back to random targeting.
 *
 * Examples (assume boss has already been selected):
 *   boss.jrSafeForceAction(125, 0, 'afterAction', 'FirstTarget');
 *   boss.jrSafeForceAction(125, -2, 'afterAction', 'LastTarget');
 *   var target = $gameParty.battleMembers()[0];
 *   boss.jrSafeForceAction(125, target, 'afterAction', 'SpecificTarget');
 *
 * timing:
 *   omitted / undefined / 'afterAction' = wait for sequence and movement
 *   'idle' = also wait for remaining battle animations before dispatch
 * 'immediate' is NOT supported. Use the exact timing strings above.
 * Last actions always use afterAction; they have no timing argument.
 *
 * key:
 *   Ordinary immediate queue calls may omit it to allow repeated requests.
 *   Conditional watchers and last actions REQUIRE a nonempty key.
 * commonEventId:
 *   omitted / undefined / 0 = no pre-action common event
 *   positive integer = an existing Common Event ID
 * Passing an invalid common event rejects the registration/request.
 * IDs such as 125, 12 and 3 in this help are examples; replace them.
 *
 * 6. CONDITIONAL REACTIONS: REGISTER ONCE, CHECK REPEATEDLY
 * -------------------------------------------------------
 * Full battler call:
 *   battler.jrSafeForceActionWhen(skillId, target, timing, key,
 *       conditionFunction, commonEventId);
 *
 * Equivalent BattleManager call:
 *   BattleManager.jrForceActionWhen(battler, skillId, target, timing,
 *       key, conditionFunction, commonEventId);
 *
 * Setup:
 *   1. Open Database > Troops > your troop.
 *   2. Create a battle event with Turn: 0 + 0 * X and Span: Battle.
 *   3. Add a Script command containing the registration.
 * The Turn 0 page only registers it. The plugin does the later checks;
 * the troop event does not need to repeat or use a CTB Turn 7 condition.
 *
 * HP below 15%, with common event 12 before skill 125:
 *   var boss = $gameTroop.members()[0];
 *   boss.jrSafeForceActionWhen(125, -1, 'afterAction', 'LowHP',
 *       function(user) {
 *           return user.hpRate() < 0.15;
 *       }, 12);
 *
 * user is the reacting battler supplied by the plugin.
 * Return true when the reaction should queue. Use a FUNCTION, not a
 * Boolean expression evaluated once at registration.
 * Keep it read-only: no damage, healing, messages or new registrations.
 * Keep it inexpensive: checks may run every battle update, after gainHp,
 * and after a normal CTB turn completes. No watcher work runs when empty.
 * Do not expect arbitrary temporary changes between checks to be recorded.
 *
 * The first qualifying check queues once, then removes the watcher.
 * Healing or a condition becoming false afterward does not cancel it.
 * If the ordinary queue is full, the watcher retries on later checks.
 * A condition error disables that watcher and logs one warning in F8.
 * Dead/hidden/removed users lose their watchers when checked; registering
 * again after revival is needed if their key has not already been claimed.
 *
 * 7. OR / AND / SWITCH / STATE EXAMPLES
 * -------------------------------------
 * || means OR; && means AND. Parentheses group conditions.
 * hpRate() uses fractions: 0.15 = 15%, 0.25 = 25%.
 * < is strictly below; <= includes equality.
 *
 * Boss HP below 15% OR actor 3 HP below 25% OR boss finished 7 turns:
 *   var boss = $gameTroop.members()[0];
 *   boss.jrSafeForceActionWhen(125, -1, 'afterAction', 'BossPhase',
 *       function(user) {
 *           var actor = $gameActors.actor(3);
 *           return user.hpRate() < 0.15 ||
 *               (actor && actor.isBattleMember() &&
 *                   actor.hpRate() < 0.25) ||
 *               user.jrCtbTurnCount() >= 7;
 *       }, 12);
 *
 * A dead actor has 0 HP, so the actor condition above includes KO.
 * Add actor.isAlive() if the actor must still be alive.
 *
 * Boss HP at/below 25% AND switch 10 ON:
 *   boss.jrSafeForceActionWhen(125, -1, 'afterAction', 'SwitchPhase',
 *       function(user) {
 *           return user.hpRate() <= 0.25 && $gameSwitches.value(10);
 *       });
 *
 * State 73 present OR variable 20 at least 3:
 *   boss.jrSafeForceActionWhen(125, -1, 'afterAction', 'StatePhase',
 *       function(user) {
 *           return user.isStateAffected(73) ||
 *               $gameVariables.value(20) >= 3;
 *       });
 *
 * For mutually exclusive outcomes, make your conditions mutually
 * exclusive. Different keys allow multiple reactions to queue.
 * There is no automatic repeating-every-N-turns watcher in this version.
 *
 * 8. THE INDIVIDUAL CTB TURN COUNTER
 * ---------------------------------
 *   battler.jrCtbTurnCount()
 * Returns completed NORMAL CTB turns for that battler, starting at 0.
 * It does not use troop global turns or YEP's self-turn setting.
 * It excludes JR reactions, native forced actions and instant casts that
 * retain the turn. A skipped/invalid normal action counts if CTB actually
 * finishes that battler's turn. It is not a count of hits or animations.
 *
 * After the boss's seventh completed turn:
 *   return user.jrCtbTurnCount() >= 7;
 * At exactly seven completed turns:
 *   return user.jrCtbTurnCount() === 7;
 * Prefer >= when late registration should still qualify.
 * Neither expression means BEFORE its seventh action.
 * Counts persist through revival in that battle and reset at battle end
 * and setup. Calling outside battle returns 0.
 *
 * 9. ONCE-PER-BATTLE KEYS AND TROOP SPAN
 * -------------------------------------
 * Keys belong to individual battler objects, not enemy database IDs.
 * Two copies of the same enemy can each use 'LastBreath' once.
 * 'Phase2' and 'phase2' are different keys. Reuse one key deliberately
 * when several callers should compete for ONE reaction.
 * The field sometimes called 'phase' is simply this trigger key.
 * No fixed naming format or numbered order is required. Examples:
 *   AngryBoss   PoisonRetaliation   Final Warning   Boss_Phase_2
 * Names do not change the boss's state or enforce a phase sequence.
 * In notetags omit quotes, avoid commas/angle brackets and leading or
 * trailing spaces. In scripts use a quoted string with the same spelling.
 *
 * The key is claimed when a request QUEUES, not when its skill executes.
 * It remains claimed if that queued request is later skipped.
 * Registering a watcher reserves that watcher name, but does not claim
 * the execution key yet. A direct call with that key can win first.
 *
 * Span: Battle prevents one troop event PAGE from repeating.
 * The key prevents duplicate JR requests for the same battler/key.
 * You can put the same keyed direct call on several Battle-span pages
 * to achieve OR, but dialogue/other commands on those pages are not
 * deduplicated. A single conditional watcher is usually simpler.
 * No manual reset switch is needed. Keys reset every battle.
 *
 * 10. LASTBREATH: FINAL ACTION AFTER LETHAL HP DAMAGE
 * --------------------------------------------------
 * Full call (enemy battlers only):
 *   boss.jrLastAction(skillId, target, key, commonEventId);
 * Example, registered at Turn 0 / Span: Battle:
 *   var boss = $gameTroop.members()[0];
 *   boss.jrLastAction(125, -1, 'LastBreath', 12);
 * There is no separate BattleManager.jrLastAction method.
 * Register while the boss is alive, BEFORE lethal damage occurs.
 * Do not wait for HP <= 0 to register. The enemy notetag is an alternative.
 * Only one last-action registration is accepted per enemy per battle.
 *
 * Lifecycle:
 *   1. Normal damage/gainHp/setHp would reduce HP to 0 or below.
 *   2. Boss stays at a minimum of 1 HP and its death becomes pending.
 *   3. Remaining hits/current sequence finish; attacker returns home.
 *   4. Optional dialogue common event runs to completion.
 *   5. Final skill executes once, then the boss dies/collapses.
 *
 * Healing does not cancel the pending death. Further lethal hits and
 * ordinary Death-state applications cannot kill the pending boss early.
 * Its pending ordinary JR requests/watchers are discarded when lethal
 * damage starts LastBreath. An already executing reaction can finish.
 * Other battlers' queued requests remain. LastBreath joins the queue;
 * it is not a global priority interrupt. It bypasses the 32-request cap.
 * Its normal charged action is not restored after the final skill.
 *
 * Use a DISTINCT key from ordinary HP phases. If an ordinary reaction
 * has already claimed the last-action key, that last action cannot arm.
 * Revival after LastBreath does not grant another last action that battle.
 * Healing during dialogue cannot save the boss from its committed death.
 *
 * Limits:
 *   - Direct instant-death/Death-state application BEFORE lethal HP does
 *     not trigger this feature. It handles lethal HP changes.
 *   - Direct _hp writes and custom death systems may bypass interception.
 *   - Removed/hidden users or an early battle end can skip the skill;
 *     pending death is finalized so protection does not persist.
 *   - Defeat/victory checks are deferred DURING the final skill. A battle
 *     ending before dispatch can still cancel a pending final reaction.
 *   - HP displays at least 1 while protected; damage popup behavior still
 *     depends on your engine and popup plugins.
 *   - Do not wait for HP=0 or boss death inside its dialogue/skill event.
 *
 * 11. DIALOGUE COMMON EVENTS: STEP BY STEP
 * ---------------------------------------
 * 1. Create Common Event 12 in Database > Common Events.
 * 2. Set Trigger: None. No autorun/parallel trigger is needed.
 * 3. Add Show Text with the boss portrait and:
 *      You are coming with me!
 * 4. Add more text, choices, branches or waits as desired.
 * 5. Supply 12 as the commonEventId in a JR call or last-action tag.
 *
 * The plugin runs the event AFTER the current battle activity settles,
 * but BEFORE starting the configured skill. It waits for event completion
 * and message dismissal. LastBreath protection stays active throughout.
 * Do not add a native Force Action command to launch the configured skill;
 * the plugin does that when the event ends. Such commands are skipped with
 * an F8 warning, including inside nested common events.
 * Direct force-action scripts are also unsupported inside this dialogue.
 * Do not make loops that wait for CTB turns or the queued skill to finish.
 *
 * Uses its own interpreter, preserving existing troop interpreter work
 * and common-event reservations. This is a battle dialogue event, not a
 * map-event context. Map movement/transfer workflows are not supported.
 * Choices do not automatically cancel the reaction; their branches run,
 * then the configured skill follows. There is no cancellation API.
 *
 * In a Script command INSIDE the dialogue, access its reacting user:
 *   var speaker = BattleManager.jrDialogueUser();
 *   if (speaker) $gameVariables.setValue(21, speaker.name());
 * Then a later Show Text can use \V[21] to display that name.
 * The accessor returns null outside a JR pre-action dialogue.
 * Do not use BattleManager._subject as the dialogue speaker: the forced
 * skill has not started yet, so it may still refer to an earlier battler.
 *
 * Omit commonEventId or use 0 to disable dialogue.
 * Remove any duplicate dialogue previously added to the skill's sequence.
 * Do not also add the same common event to the skill's Effects list unless
 * you intentionally want the engine to run it again later.
 *
 * 12. BUFFS & STATES CORE AND gainHp
 * ----------------------------------
 * Place JR below YEP_BuffsStatesCore. Its custom regeneration, turn-end,
 * and action-end effects may call gainHp normally. For example:
 *   <Custom Regenerate Effect>
 *   user.gainHp(-100);
 *   </Custom Regenerate Effect>
 * For a registered/tagged LastBreath user, lethal damage from this call
 * uses the same protection/dialogue/final-skill path. The state effect
 * does not need to manually launch a conversation or forced skill.
 * Normal MV gainHp(-100) removes HP; gainHp(100) heals. Other plugins
 * that change gainHp behavior can change which call is actually lethal.
 *
 * v1.30 runs BSC custom Action End effects for JR skills before cleanup.
 * Action-start/end state effects, skill costs, damage and explicit skill
 * CTB effects still apply. These reactions are not free of all side effects.
 * They avoid normal CTB end-turn cleanup and the YEP self-turn increment;
 * pending normal actions are restored only if the user remains eligible.
 * Death/incapacity can invalidate those saved actions.
 * Use 0 MP/TP costs if the reaction should cost nothing.
 *
 * 13. ACTION SEQUENCE REQUIREMENTS
 * --------------------------------
 * The plugin waits for movement; it does not invent return-home commands.
 * In a custom finish block, retain your cleanup and include:
 *   <finish action>
 *   perform finish
 *   wait for movement
 *   </finish action>
 * If the block already exists, edit it instead of adding a second one.
 * Do not replace other needed cleanup, such as your immortality cleanup.
 * Dialogue does not need to be placed in the sequence.
 * Do not mix native forced actions into an executing JR reaction.
 * Complete custom sequences normally; infinite waits cannot be fixed here.
 *
 * 14. RETURN VALUES, CAPACITY, SAVES AND TROUBLESHOOTING
 * -----------------------------------------------------
 * All three registration/queue methods return true on acceptance, false
 * on rejection. For When/LastAction, true means REGISTERED, not executed.
 * Example during battle:
 *   var accepted = boss.jrLastAction(125, -1, 'LastBreath', 12);
 *   console.log('LastBreath registered:', accepted);
 *
 * Common rejection reasons: missing/dead/hidden user, wrong battle system,
 * outside battle, invalid skill/common-event ID, invalid timing/target,
 * duplicate key, missing required key, or capacity reached.
 * Ordinary pending requests: maximum 32. Active watchers: maximum 32.
 * Last actions bypass the ordinary queue cap when lethal damage triggers.
 * Unkeyed repeated calls can queue duplicates; do not run them every frame.
 * HP notetags/direct requests rejected by capacity do not auto-retry that
 * same attempt. Watchers retry while their condition remains true.
 * State notetags also retry while the state remains present.
 *
 * Nothing happens:
 *   Check enabled/plugin order/active CTB, IDs, troop slot and return value.
 *   Save database changes, restart the playtest, and check F8 warnings.
 *   Register watchers/last actions at Turn 0, not after their user dies.
 *   Make sure no actor input, running event or movement is still pending.
 *   For HP notes, confirm an actual HP decrease and strict < threshold.
 *   For LastBreath with dialogue, ensure the common event ID exists.
 *
 * Battle seems stuck:
 *   Close pending text/choices. Check the dialogue event for infinite loops,
 *   force-action scripts or waits for a reaction that cannot start yet.
 *   Check custom action sequences and return-home movement.
 *
 * Unexpected duplicates:
 *   Use a shared nonempty key for one reaction. Check for duplicate native
 *   troop commands, different keys, or dialogue also inside the skill.
 *
 * Final action did not trigger:
 *   Ordinary safe reactions do not grant death protection. Use LastAction.
 *   Check for a reused key, instant death, direct _hp edits or battle ending.
 *
 * This plugin stores no new save fields. Queue/watchers/keys/counters and
 * last-action/dialogue state are battle-local and cleared on setup/end.
 * Mid-battle save/resume is not supported by this plugin's runtime state.
 * Test normal damage, BSC damage, multi-hits, dialogue, CTB charge, battle
 * end and a second battle with your full plugin stack before release.
 *
 * 15. VERSION NOTES
 * ------------------
 * v1.00: Deferred CTB reactions and HP notetags.
 * v1.10: Conditional OR/AND watchers and individual completed-turn counter.
 * v1.20: Optional final action after lethal HP damage.
 * v1.30: Pre-action common events and BSC action-end compatibility.
 * v1.40: Optional HP-tag dialogue, state-trigger tags and key examples.
 */

var Imported = Imported || {};
Imported.JR_SafeForceAction = true;

(function() {
    'use strict';

    var BM = BattleManager;
    var jrQueue = [];
    var jrClaims = [];
    var jrActive = null;
    var jrEnding = false;
    var jrTagsLoaded = false;
    var jrHasStateTags = false;
    var jrWatchers = [];
    var jrTurns = [];
    var jrPolling = false;
    var jrTurnContext = null;
    var jrLasts = [];
    var jrPrelude = null;

    function jrReset() {
        jrQueue = [];
        jrClaims = [];
        jrActive = null;
        jrEnding = false;
        jrWatchers = [];
        jrTurns = [];
        jrPolling = false;
        jrTurnContext = null;
        jrLasts = [];
        jrPrelude = null;
    }

    function jrSupported() {
        return Imported.YEP_BattleEngineCore && Imported.YEP_X_BattleSysCTB &&
            BM.isCTB && BM.isCTB();
    }

    function jrMember(battler) {
        return battler && BM.allBattleMembers().indexOf(battler) >= 0 &&
            battler.isAlive() && battler.isAppeared();
    }

    function jrClaimed(battler, key) {
        return jrClaims.some(function(entry) {
            return entry.battler === battler && entry.key === key;
        });
    }

    function jrLastRecord(user) {
        for (var i = 0; i < jrLasts.length; i++) {
            if (jrLasts[i].battler === user) return jrLasts[i];
        }
        return null;
    }

    function jrDeathPending(user) {
        var record = jrLastRecord(user);
        return record && record.status === 'pending';
    }

    Game_Battler.prototype.jrLastAction = function(skill, target, key, commonEventId) {
        var request = jrRequest(this, skill, target, 'afterAction', key, commonEventId);
        if (!request || !this.isEnemy() || !request.key ||
            jrLastRecord(this) || jrClaimed(this, request.key)) return false;
        request.status = 'armed';
        jrLasts.push(request);
        return true;
    };

    function jrBeginLast(user) {
        if (!$gameParty || !$gameParty.inBattle() || !jrSupported() ||
            !jrMember(user) || BM._phase === 'battleEnd' ||
            BM._phase === 'aborting') return false;
        var record = jrLastRecord(user);
        if (!record && user.isEnemy()) {
            var tag = user.enemy()._jrLastActionTag;
            if (tag) user.jrLastAction(tag.skill, -1, tag.key, tag.commonEventId);
            record = jrLastRecord(user);
        }
        if (!record) return false;
        if (record.status === 'pending') return true;
        if (record.status !== 'armed' || jrClaimed(user, record.key)) return false;
        record.status = 'pending';
        jrClaims.push({ battler: user, key: record.key });
        jrQueue = jrQueue.filter(function(entry) { return entry.battler !== user; });
        jrWatchers = jrWatchers.filter(function(entry) { return entry.battler !== user; });
        jrQueue.push({ battler: user, skill: record.skill, target: record.target,
            timing: 'afterAction', key: record.key, last: record,
            commonEventId: record.commonEventId });
        return true;
    }

    function jrFinishLast(record, collapse) {
        if (!record || record.status !== 'pending') return;
        record.status = 'done';
        var user = record.battler;
        // Release YEP sequence immortality before applying the postponed death.
        user._immortalState = false;
        user.setHp(0);
        if (!user.isDeathStateAffected()) user.addNewState(user.deathStateId());
        user.resetAllCTB();
        user.setActionState('undecided');
        if (collapse && user.isAppeared()) user.performCollapse();
    }

    var jrSetHp = Game_BattlerBase.prototype.setHp;
    Game_BattlerBase.prototype.setHp = function(value) {
        if (value <= 0 && (jrDeathPending(this) || jrBeginLast(this))) value = 1;
        return jrSetHp.call(this, value);
    };

    var jrAddState = Game_Battler.prototype.addState;
    Game_Battler.prototype.addState = function(stateId) {
        if (stateId === this.deathStateId() && jrDeathPending(this)) return;
        var result = jrAddState.apply(this, arguments);
        jrCheckStateTags(this);
        return result;
    };

    function jrCheckStateTags(user) {
        if (!jrHasStateTags || !$gameParty || !$gameParty.inBattle() ||
            !jrSupported() || !user.isEnemy() || !jrMember(user) ||
            jrDeathPending(user)) return;
        var tags = user.enemy()._jrSafeForceStateTags || [];
        for (var i = 0; i < tags.length; i++) {
            var tag = tags[i];
            if (!jrClaimed(user, tag.key) && user.isStateAffected(tag.stateId)) {
                user.jrSafeForceAction(tag.skill, -1, 'afterAction',
                    tag.key, tag.commonEventId);
            }
        }
    }

    function jrPollStateTags() {
        if (!jrHasStateTags || !$gameParty || !$gameParty.inBattle()) return;
        var enemies = $gameTroop.members();
        for (var i = 0; i < enemies.length; i++) jrCheckStateTags(enemies[i]);
    }

    var jrDie = Game_BattlerBase.prototype.die;
    Game_BattlerBase.prototype.die = function() {
        if (jrDeathPending(this)) return;
        return jrDie.apply(this, arguments);
    };

    function jrRequest(battler, skillId, target, timing, key, commonEventId) {
        timing = timing === undefined ? 'afterAction' : timing;
        target = target === undefined ? -1 : target;
        skillId = Number(skillId);
        commonEventId = commonEventId === undefined ? 0 : Number(commonEventId);
        if (!isFinite(commonEventId) || commonEventId < 0 ||
            Math.floor(commonEventId) !== commonEventId ||
            (commonEventId && (!$dataCommonEvents[commonEventId] ||
                !$dataCommonEvents[commonEventId].list))) return null;
        if (!jrSupported() || !$gameParty.inBattle() || !BM._phase ||
            BM._phase === 'battleEnd' || BM._phase === 'aborting' ||
            !jrMember(battler) || !Number.isFinite(skillId) ||
            Math.floor(skillId) !== skillId || !$dataSkills[skillId] ||
            (timing !== 'afterAction' && timing !== 'idle')) return null;
        if (typeof target === 'number') {
            if (!isFinite(target) || Math.floor(target) !== target || target < -2) {
                return false;
            }
        } else if (!target || typeof target.index !== 'function') {
            return false;
        }
        key = key === undefined || key === null ? '' : String(key);
        return { battler: battler, skill: skillId, target: target,
            timing: timing, key: key, commonEventId: commonEventId };
    }

    BM.jrForceAction = function(battler, skillId, target, timing, key, commonEventId) {
        var request = jrRequest(battler, skillId, target, timing, key, commonEventId);
        if (!request || jrDeathPending(battler) || jrQueue.length >= 32 ||
            (request.key && jrClaimed(battler, request.key))) return false;
        jrQueue.push(request);
        if (request.key) jrClaims.push({ battler: battler, key: request.key });
        return true;
    };

    Game_Battler.prototype.jrSafeForceAction = function(skill, target, timing, key, commonEventId) {
        return BM.jrForceAction(this, skill, target, timing, key, commonEventId);
    };

    BM.jrForceActionWhen = function(battler, skill, target, timing, key, condition, commonEventId) {
        var request = jrRequest(battler, skill, target, timing, key, commonEventId);
        if (!request || jrDeathPending(battler) || !request.key || typeof condition !== 'function' ||
            jrWatchers.length >= 32 || jrClaimed(battler, request.key)) return false;
        for (var i = 0; i < jrWatchers.length; i++) {
            if (jrWatchers[i].battler === battler &&
                jrWatchers[i].key === request.key) return false;
        }
        request.condition = condition;
        jrWatchers.push(request);
        return true;
    };

    Game_Battler.prototype.jrSafeForceActionWhen = function(skill, target, timing, key, fn, commonEventId) {
        return BM.jrForceActionWhen(this, skill, target, timing, key, fn, commonEventId);
    };

    function jrPollConditions() {
        if (!jrWatchers.length || jrPolling || !jrSupported() ||
            !$gameParty.inBattle() || !BM._phase || BM._phase === 'battleEnd' ||
            BM._phase === 'aborting') return;
        jrPolling = true;
        try {
            for (var i = 0; i < jrWatchers.length;) {
                var watch = jrWatchers[i];
                var remove = !jrMember(watch.battler) ||
                    jrClaimed(watch.battler, watch.key);
                if (!remove) {
                    var matches = false;
                    try {
                        matches = !!watch.condition.call(watch.battler, watch.battler);
                    } catch (error) {
                        console.warn('[JR_SafeForceAction] Disabled condition: ' +
                            watch.key, error);
                        remove = true;
                    }
                    if (matches) {
                        remove = BM.jrForceAction(watch.battler, watch.skill,
                            watch.target, watch.timing, watch.key, watch.commonEventId);
                    }
                }
                if (remove) jrWatchers.splice(i, 1);
                else i++;
            }
        } finally {
            jrPolling = false;
        }
    }

    function jrTurnRecord(battler) {
        for (var i = 0; i < jrTurns.length; i++) {
            if (jrTurns[i].battler === battler) return jrTurns[i];
        }
        var record = { battler: battler, count: 0 };
        jrTurns.push(record);
        return record;
    }

    Game_Battler.prototype.jrCtbTurnCount = function() {
        if (!$gameParty.inBattle()) return 0;
        return jrTurnRecord(this).count;
    };

    var jrInstantCast = Game_Battler.prototype.checkCTBEndInstantCast;
    Game_Battler.prototype.checkCTBEndInstantCast = function() {
        var result = jrInstantCast.apply(this, arguments);
        if (result && jrTurnContext && jrTurnContext.battler === this) {
            jrTurnContext.instant = true;
        }
        return result;
    };

    var jrEndTurnCTB = Game_Battler.prototype.endTurnAllCTB;
    Game_Battler.prototype.endTurnAllCTB = function() {
        var previous = jrTurnContext;
        var context = { battler: this, instant: false };
        var count = jrSupported() && jrEnding && !jrActive &&
            BM._subject === this && !BM._processingForcedAction &&
            !(BM._forceActionQueue && BM._forceActionQueue.length);
        jrTurnContext = context;
        try {
            var result = jrEndTurnCTB.apply(this, arguments);
            if (count && !context.instant && $gameParty.inBattle() &&
                BM._phase !== 'battleEnd' && BM._phase !== 'aborting') {
                jrTurnRecord(this).count++;
                // Queue before YEP hands control to the next charged battler.
                jrPollConditions();
            }
            return result;
        } finally {
            jrTurnContext = previous;
        }
    };

    var jrSetup = BM.setup;
    BM.setup = function() {
        jrReset();
        return jrSetup.apply(this, arguments);
    };

    var jrEndBattle = BM.endBattle;
    BM.endBattle = function() {
        jrLasts.forEach(function(record) { jrFinishLast(record, false); });
        jrReset();
        return jrEndBattle.apply(this, arguments);
    };

    var jrCheckBattleEnd = BM.checkBattleEnd;
    BM.checkBattleEnd = function() {
        if (jrActive && jrActive.last && this._phase !== 'aborting' &&
            !(this.isAborting && this.isAborting())) return false;
        return jrCheckBattleEnd.apply(this, arguments);
    };

    function jrVisualBusy(timing) {
        var scene = SceneManager._scene;
        var sprites = BM._spriteset || (scene && scene._spriteset);
        if (!sprites) return true;
        var checks = ['isAnyoneMoving', 'isAnyoneJumping',
            'isAnyoneFloating', 'isAnyoneChangingOpacity'];
        if (timing === 'idle') checks.push('isAnimationPlaying');
        return checks.some(function(name) {
            return sprites[name] && sprites[name]();
        });
    }

    function jrTargetIndex(request) {
        if (typeof request.target === 'number') return request.target;
        var action = new Game_Action(request.battler, true);
        action.setSkill(request.skill);
        var unit = action.isForOpponent() ? request.battler.opponentsUnit() :
            request.battler.friendsUnit();
        var index = unit.members().indexOf(request.target);
        return index >= 0 && request.target.isAppeared() ? index : null;
    }

    function jrDispatch(request, index) {
        var user = request.battler;
        jrActive = {
            battler: user,
            actions: user._actions,
            actionState: user._actionState,
            actionBattlers: BM._actionBattlers.slice(),
            phase: BM._phase,
            last: request.last || null
        };
        // Do not clear normal actions when merely requesting a reaction.
        // Isolate them only now, immediately before native dispatch.
        user._actions = [];
        user.forceAction(request.skill, index);
        BM.forceAction(user);
        BM.processForcedAction();
    }

    BM.jrDialogueUser = function() {
        return jrPrelude ? jrPrelude.request.battler : null;
    };

    function jrDialogueInterpreter(depth) {
        var interpreter = new Game_Interpreter(depth || 0);
        interpreter.command339 = function() {
            console.warn('[JR_SafeForceAction] Force Action skipped in pre-action dialogue.');
            return true;
        };
        interpreter.setupChild = function(list, eventId) {
            this._childInterpreter = jrDialogueInterpreter(this._depth + 1);
            this._childInterpreter.setup(list, eventId);
        };
        return interpreter;
    }

    function jrStartPrelude(request) {
        var event = $dataCommonEvents[request.commonEventId];
        if (!event || !event.list) {
            console.warn('[JR_SafeForceAction] Missing dialogue common event; reaction skipped.');
            jrFinishLast(request.last, true);
            return;
        }
        var interpreter = jrDialogueInterpreter(0);
        interpreter.setup(event.list, 0);
        jrPrelude = { request: request, interpreter: interpreter };
    }

    function jrUpdatePrelude() {
        var prelude = jrPrelude;
        var request = prelude.request;
        if (BM._phase === 'aborting' || BM._phase === 'battleEnd' ||
            !$gameParty.inBattle() || !jrMember(request.battler)) {
            jrPrelude = null;
            jrFinishLast(request.last, true);
            return;
        }
        prelude.interpreter.update();
        if (jrPrelude !== prelude) return;
        if (BM._phase === 'aborting' || BM._phase === 'battleEnd') return;
        if (prelude.interpreter.isRunning() || $gameMessage.isBusy() ||
            BM.isBusy() || jrVisualBusy(request.timing) ||
            SceneManager.isSceneChanging()) return;
        jrPrelude = null;
        // Dialogue scripts can change the user or target. Revalidate now.
        if (!jrMember(request.battler) ||
            (!request.last && jrDeathPending(request.battler))) {
            jrFinishLast(request.last, true);
            return;
        }
        if (BM.checkBattleEnd()) return;
        var index = jrTargetIndex(request);
        if (index === null && request.last) index = -1;
        if (index !== null) jrDispatch(request, index);
    }

    var jrUpdate = BM.update;
    BM.update = function() {
        jrPollStateTags();
        if (jrPrelude) {
            jrUpdatePrelude();
            return;
        }
        jrPollConditions();
        if (!jrQueue.length || jrActive || !jrSupported()) {
            return jrUpdate.apply(this, arguments);
        }
        // CTB input and every BEC sequence phase must complete first.
        if (this._phase !== 'ctb' && this._phase !== 'turnEnd') {
            return jrUpdate.apply(this, arguments);
        }
        if (this._processingForcedAction || this.isActionForced() ||
            (this._forceActionQueue && this._forceActionQueue.length) ||
            $gameTroop.isEventRunning()) {
            return jrUpdate.apply(this, arguments);
        }
        if (SceneManager.isSceneChanging() || this.isBusy() ||
            $gameMessage.isBusy()) return;
        if (this.checkBattleEnd()) return;
        while (jrQueue.length) {
            var request = jrQueue[0];
            var index = jrMember(request.battler) ? jrTargetIndex(request) : null;
            if (request.last && jrMember(request.battler) && index === null) index = -1;
            if (index === null) {
                jrQueue.shift();
                jrFinishLast(request.last, true);
                continue;
            }
            // Hold CTB here so another ready battler cannot overtake the queue.
            if (jrVisualBusy(request.timing)) return;
            jrQueue.shift();
            if (request.commonEventId) jrStartPrelude(request);
            else jrDispatch(request, index);
            return;
        }
        return jrUpdate.apply(this, arguments);
    };

    // YEP CTB can start the next charged action inside endCTBAction itself.
    // Let normal cleanup finish, but yield to the queue before that handoff.
    var jrEndCTBAction = BM.endCTBAction;
    BM.endCTBAction = function() {
        var previous = jrEnding;
        jrEnding = true;
        try {
            return jrEndCTBAction.apply(this, arguments);
        } finally {
            jrEnding = previous;
        }
    };

    var jrGetCharged = BM.getChargedCTBBattler;
    BM.getChargedCTBBattler = function() {
        if (jrEnding && jrQueue.length && !jrActive) return false;
        return jrGetCharged.apply(this, arguments);
    };

    if (BM.breakCTBPhase) {
        var jrBreakCTBPhase = BM.breakCTBPhase;
        BM.breakCTBPhase = function() {
            if (jrQueue.length && !jrActive) return true;
            return jrBreakCTBPhase.apply(this, arguments);
        };
    }

    var jrEndAction = BM.endAction;
    BM.endAction = function() {
        if (!jrActive || this._subject !== jrActive.battler) {
            return jrEndAction.apply(this, arguments);
        }
        var saved = jrActive;
        var user = saved.battler;
        if (saved.last && jrVisualBusy('afterAction')) return;
        if (!saved.bscEndDone && Imported.YEP_BuffsStatesCore &&
            user.onActionEndStateEffects) {
            saved.bscEndDone = true;
            user.onActionEndStateEffects();
            if (jrActive !== saved) return;
        }
        // Keep action-end effects, but do NOT call CTB endTurnAllCTB:
        // that would clear the charged action, reset gauges and run turn end.
        user.onAllActionsEnd();
        if (jrActive !== saved) return;
        user._actions = !saved.last && user.canMove() && jrMember(user) ? saved.actions : [];
        if (!user.canMove() || !jrMember(user)) user.resetAllCTB();
        user.setActionState(user.canMove() ? saved.actionState : 'undecided');
        this._actionBattlers = saved.actionBattlers;
        this._processingForcedAction = false;
        this._actionForcedBattler = null;
        this.loadPreForceActionSettings();
        this._phase = saved.phase;
        jrActive = null;
        jrFinishLast(saved.last, true);
        if (user.battler()) user.battler().refreshMotion();
    };

    var jrSelfTurn = Game_Battler.prototype.increaseSelfTurnCount;
    Game_Battler.prototype.increaseSelfTurnCount = function() {
        if (jrActive && jrActive.battler === this) return;
        return jrSelfTurn.apply(this, arguments);
    };

    var jrDatabaseLoaded = DataManager.isDatabaseLoaded;
    DataManager.isDatabaseLoaded = function() {
        if (!jrDatabaseLoaded.apply(this, arguments)) return false;
        if (!jrTagsLoaded) {
            for (var i = 1; i < $dataEnemies.length; i++) {
                var enemy = $dataEnemies[i];
                if (!enemy) continue;
                enemy._jrSafeForceTags = [];
                enemy._jrSafeForceStateTags = [];
                enemy._jrLastActionTag = null;
                var last = /<JR Last Action:\s*(\d+)\s*,\s*([^,>]+?)(?:\s*,\s*(\d+))?\s*>/i.exec(enemy.note || '');
                if (last && $dataSkills[Number(last[1])] && last[2].trim()) {
                    enemy._jrLastActionTag = { skill: Number(last[1]),
                        key: last[2].trim(), commonEventId: Number(last[3] || 0) };
                }
                var regex = /<JR Safe Force:\s*([\d.]+)\s*,\s*(\d+)\s*,\s*([^,>]+?)(?:\s*,\s*(\d+))?\s*>/gi;
                var match;
                while ((match = regex.exec(enemy.note || ''))) {
                    var percent = Number(match[1]);
                    var skill = Number(match[2]);
                    var key = match[3].trim();
                    if (percent > 0 && percent <= 100 && $dataSkills[skill] && key) {
                        enemy._jrSafeForceTags.push({ rate: percent / 100,
                            skill: skill, key: key,
                            commonEventId: Number(match[4] || 0) });
                    }
                }
                var stateRegex = /<JR Safe Force State:\s*(\d+)\s*,\s*(\d+)\s*,\s*([^,>]+?)(?:\s*,\s*(\d+))?\s*>/gi;
                while ((match = stateRegex.exec(enemy.note || ''))) {
                    var stateId = Number(match[1]);
                    var stateSkill = Number(match[2]);
                    var stateKey = match[3].trim();
                    if (stateId > 0 && $dataStates[stateId] &&
                        $dataSkills[stateSkill] && stateKey) {
                        enemy._jrSafeForceStateTags.push({ stateId: stateId,
                            skill: stateSkill, key: stateKey,
                            commonEventId: Number(match[4] || 0) });
                        jrHasStateTags = true;
                    }
                }
            }
            jrTagsLoaded = true;
        }
        return true;
    };

    var jrGainHp = Game_Battler.prototype.gainHp;
    Game_Battler.prototype.gainHp = function(value) {
        var before = this.hp;
        var result = jrGainHp.apply(this, arguments);
        if ($gameParty.inBattle() && this.isEnemy() && this.isAlive() &&
            this.hp < before) {
            var tags = this.enemy()._jrSafeForceTags || [];
            for (var i = 0; i < tags.length; i++) {
                var tag = tags[i];
                if (this.hpRate() < tag.rate) {
                    this.jrSafeForceAction(tag.skill, -1, 'afterAction',
                        tag.key, tag.commonEventId);
                }
            }
        }
        jrPollConditions();
        return result;
    };
})();