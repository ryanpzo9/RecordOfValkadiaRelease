/*:
 * @plugindesc v1.10 Cached per-battler Tick Speed for YEP CTB.
 * @author JR
 *
 * @param Debug Log
 * @type boolean
 * @default false
 * @desc Actor snapshots outside the internal tick loop. Disable for release.
 *
 * @param Debug Test Only
 * @type boolean
 * @default true
 * @desc Only automatically log during Playtest or Battle Test.
 *
 * @param Debug Interval
 * @type number
 * @min 1
 * @default 60
 * @desc BattleManager updates between debug checks. Logs only changed values.
 *
 * @param Minimum Tick Speed
 * @type number
 * @decimals 4
 * @min 0.0001
 * @default 0.01
 * @desc Minimum multiplier: 0.01 = 1 percent speed.
 *
 * @help
 * Place BELOW YEP_BattleEngineCore and YEP_X_BattleSysCTB.
 * Restart the game after replacing the plugin.
 *
 * YEP CTB settings:
 *   Per Tick: AGI * JrTickSpeed
 *   Enable Rubberband: false
 * Alternative Per Tick: user.agi * user.JrTickSpeed
 * Use ONE multiplication only. Parameters are not changed automatically.
 *
 * State / Weapon / Armor / Class / Enemy / Actor notes:
 *   <Tick Speed Modifier: +20%>
 *   <Tick Speed Modifier: -15%>
 *   <Tick Speed Modifier: +(user.luk + user.def)%>
 *   <Tick Speed Modifier: -(user.luk / 2)%>
 *   <Tick Speed Modifier: +(user.hpRate() < 0.5 ? 30 : 0)%>
 *
 * Modifiers ADD: +20% and -10% = 1.10 multiplier.
 * Baseline = 1.00. Minimum defaults to 0.01, so -100% does not stop time.
 * Multiple tags per object and duplicate equipped items are supported.
 * Keep each expression on one line. Final percent sign is required.
 * user / a / subject / battler / this = the affected battler, not caster.
 * s = $gameSwitches._data; v = $gameVariables._data.
 * Expressions must only read data. No random rolls or side effects.
 * Do not reference Tick Speed inside its own modifier expression.
 * Invalid modifiers are ignored with one warning per tag.
 *
 * PERFORMANCE / UPDATE TIMING:
 * - Cached tick reads return immediately, without reading stats or notes.
 * - Numeric modifiers are cached until battler.refresh(). Standard state,
 *   equipment, class, buff and HP changes normally call refresh().
 * - Formula modifiers are also invalidated before each BattleManager.update,
 *   NOT every internal CTB tick. Several internal ticks can occur per update.
 * - Switch/variable setValue changes invalidate active battle caches.
 * - For custom direct field writes or a formula depending on data changed
 *   inside the same CTB loop without refresh, explicitly call:
 *       battler.jrRefreshTickSpeed();
 *   To refresh all current battle members:
 *       JR.CTBTickSpeed.refreshAll();
 * - Custom Per Tick formula inputs otherwise follow YEP refresh semantics.
 * - Database note edits at runtime are not supported by the note cache.
 *
 * Both turn filling and skill charge use this speed, as in YEP CTB.
 * AGI, Full Gauge, Full Turn and current gauge amounts are not modified.
 * Rubberband, if enabled, can still clamp the resulting speed.
 * Extremely low speed can require many more internal CTB iterations.
 *
 * Read multiplier: battler.JrTickSpeed or battler.jrTickSpeed()
 *
 * DEBUG: F8 console in desktop playtest.
 *   JR.CTBTickSpeed.debug = true;
 *   JR.CTBTickSpeed.debug = false;
 *   $gameActors.actor(1).jrLogTickSpeed(); // manual snapshot in CTB battle
 * Automatic logs are sampled outside the internal tick loop, actors only.
 * AGI before = baseline user.agi; Per Tick after = configured formula result.
 * Gain per update includes YEP tickRate and Rubberband.
 * Full Gauge = normal turn gauge; Charge target = skill charge goal.
 * The AGI comparison assumes the recommended Per Tick formula.
 * Internal tick/update is not a rendered frame or a second.
 * Existing Plugin Manager parameter values survive plugin replacement.
 * Runtime caches are not written into saves.
 */
var Imported = Imported || {};
var JR = JR || {};
JR.CTBTickSpeed = JR.CTBTickSpeed || {};
(function() {
    'use strict';
    if (!Imported.YEP_X_BattleSysCTB || !Game_Battler.prototype.ctbTickValue) {
        console.error('[JR Tick Speed] Load below YEP_X_BattleSysCTB. Disabled.');
        return;
    }
    Imported.JR_CTBTickSpeed = true;
    var api = JR.CTBTickSpeed;
    var p = PluginManager.parameters('JR_CTBTickSpeed');
    api.debug = String(p['Debug Log'] || 'false') === 'true';
    var testOnly = String(p['Debug Test Only'] || 'true') === 'true';
    var interval = Math.max(1, Number(p['Debug Interval']) || 60);
    var minimum = Number(p['Minimum Tick Speed'] || 0.01);
    if (!isFinite(minimum) || minimum <= 0) minimum = 0.01;
    var records = new WeakMap();
    var noteCache = new WeakMap();
    var warned = Object.create(null);
    var hasDynamic = false;
    var debugClock = 0;

    function warn(key, message, error) {
        if (warned[key]) return;
        warned[key] = true;
        console.warn('[JR Tick Speed] ' + message, error || '');
    }
    function record(b) {
        var d = records.get(b);
        if (!d) {
            d = { speed: undefined, entries: null, dynamic: false,
                busy: false, agi: 0, lastLog: '' };
            records.set(b, d);
        }
        return d;
    }
    function active() {
        return $gameParty && $gameParty.inBattle() && BattleManager.isCTB();
    }
    function invalidate(b, traits) {
        var d = records.get(b);
        if (d) {
            d.speed = undefined;
            if (traits) d.entries = null;
        }
        b._ctbTickValue = undefined;
        b._ctbTicksToReady = undefined;
    }
    function parse(obj) {
        var list = noteCache.get(obj);
        if (list) return list;
        list = [];
        var re = /<Tick\s+Speed\s+Modifier\s*:\s*([^\r\n]*?)%\s*>/gi;
        var match;
        while ((match = re.exec(obj.note || ''))) {
            var expr = match[1].trim();
            var key = obj.name + ':' + obj.id + ':' + match.index + ':' + expr;
            try {
                var fixed = /^[+-]?\s*(?:\d+\.?\d*|\.\d+)$/.test(expr);
                list.push({ key: key, expr: expr,
                    value: fixed ? Number(expr.replace(/\s/g, '')) : 0,
                    fn: fixed ? null : new Function('user', 'a', 'subject',
                        'battler', 's', 'v', 'return (' + expr + ');') });
            } catch (e) {
                warn(key, 'Invalid modifier: ' + expr, e);
            }
        }
        noteCache.set(obj, list);
        return list;
    }
    function build(b, d) {
        var sources = b.traitObjects();
        d.entries = [];
        d.dynamic = false;
        for (var i = 0; i < sources.length; i++) {
            if (!sources[i]) continue;
            var list = parse(sources[i]);
            for (var j = 0; j < list.length; j++) {
                d.entries.push(list[j]);
                if (list[j].fn) d.dynamic = true;
            }
        }
        if (d.dynamic) hasDynamic = true;
    }
    Game_BattlerBase.prototype.jrTickSpeed = function() {
        var d = record(this);
        if (d.busy) throw new Error('Recursive Tick Speed modifier');
        if (d.speed !== undefined) return d.speed;
        if (!d.entries) build(this, d);
        var sum = 0;
        d.busy = true;
        try {
            for (var i = 0; i < d.entries.length; i++) {
                var tag = d.entries[i];
                try {
                    var n = tag.fn ? tag.fn.call(this, this, this, this, this,
                        $gameSwitches._data, $gameVariables._data) : tag.value;
                    if (typeof n !== 'number' || !isFinite(n) || !isFinite(sum + n)) {
                        throw new Error('Modifier must be a finite number');
                    }
                    sum += n;
                } catch (e) {
                    warn(tag.key, 'Ignored modifier: ' + tag.expr, e);
                }
            }
        } finally {
            d.busy = false;
        }
        d.speed = Math.max(minimum, 1 + sum / 100);
        return d.speed;
    };
    Object.defineProperty(Game_BattlerBase.prototype, 'JrTickSpeed', {
        configurable: true,
        get: function() { return this.jrTickSpeed(); }
    });
    Game_BattlerBase.prototype.jrRefreshTickSpeed = function() {
        invalidate(this, true);
        if (active()) BattleManager.ctbTicksToReadyClear();
    };
    api.refreshAll = function() {
        if (!active()) return;
        var members = BattleManager.allBattleMembers();
        for (var i = 0; i < members.length; i++) {
            if (members[i]) invalidate(members[i], true);
        }
    };
    var refresh = Game_BattlerBase.prototype.refresh;
    Game_BattlerBase.prototype.refresh = function() {
        invalidate(this, true);
        try {
            return refresh.apply(this, arguments);
        } finally {
            // Do not retain a snapshot taken during a nested refresh hook.
            invalidate(this, true);
        }
    };
    Game_Battler.prototype.ctbTickValue = function() {
        // Critical: no stat getters, trait scans or formulas before this check.
        if (this._ctbTickValue !== undefined) return this._ctbTickValue;
        var a = this, user = this, subject = this;
        var AGI = this.agi;
        var JrTickSpeed = this.jrTickSpeed();
        record(this).agi = AGI;
        var code = Yanfly.Param.CTBPerTick;
        try {
            var value = eval(code);
            if (typeof value !== 'number' || !isFinite(value) || value < 0) {
                throw new Error('Per Tick must be finite and nonnegative');
            }
            this._ctbTickValue = value;
        } catch (e) {
            warn('tick:' + code, 'Invalid Per Tick; using AGI * JrTickSpeed.', e);
            this._ctbTickValue = AGI * JrTickSpeed;
        }
        return this._ctbTickValue;
    };
    // Keep YEP's original ctbTicksToReady, ctbSpeedTick and updateCTB methods.
    function refreshDynamic() {
        if (!hasDynamic) return;
        var members = BattleManager.allBattleMembers();
        var changed = false;
        for (var i = 0; i < members.length; i++) {
            var b = members[i];
            if (!b) continue;
            var d = records.get(b);
            if (d && d.dynamic) {
                invalidate(b, false);
                changed = true;
            }
        }
        if (changed) BattleManager.ctbTicksToReadyClear();
    }
    function log(b, force) {
        var gain = b.ctbSpeedTick();
        var d = record(b);
        var full = BattleManager.ctbTarget();
        var charging = b.isCTBCharging();
        var target = charging ? b.ctbChargeDestination() : full;
        var signature = [d.agi, d.speed, b._ctbTickValue, gain,
            full, charging, target].join('|');
        if (!force && d.lastLog === signature) return;
        d.lastLog = signature;
        console.log('[JR Tick Speed] ' + b.name() + ' | ' +
            (charging ? 'CHARGE' : 'FILL') + ' | AGI before=' + d.agi +
            ' | JrTickSpeed=' + d.speed + ' | Per Tick after=' + b._ctbTickValue +
            ' | Gain per update=' + gain + ' | Full Gauge=' + full +
            (charging ? ' | Charge target=' + target : ''));
    }
    var update = BattleManager.update;
    BattleManager.update = function() {
        if (active()) refreshDynamic();
        var result = update.apply(this, arguments);
        if (api.debug && active() &&
            (!testOnly || Utils.isOptionValid('test') || Utils.isOptionValid('btest'))) {
            if (++debugClock >= interval) {
                debugClock = 0;
                var actors = $gameParty.battleMembers();
                for (var i = 0; i < actors.length; i++) {
                    if (actors[i].isAlive()) log(actors[i], false);
                }
            }
        }
        return result;
    };
    function hookChange(proto) {
        var original = proto.onChange;
        proto.onChange = function() {
            var result = original.apply(this, arguments);
            api.refreshAll();
            return result;
        };
    }
    hookChange(Game_Switches.prototype);
    hookChange(Game_Variables.prototype);
    var onCTBStart = Game_Battler.prototype.onCTBStart;
    Game_Battler.prototype.onCTBStart = function() {
        records.delete(this);
        invalidate(this, false);
        return onCTBStart.apply(this, arguments);
    };
    Game_Battler.prototype.jrLogTickSpeed = function() {
        if (active()) log(this, true);
    };
})();