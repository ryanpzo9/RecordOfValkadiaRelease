//=============================================================================
// JR_BarrierDisplay_DreamX.js
//=============================================================================
/*:
 * @plugindesc v1.0 Displays Absorption Barrier points next to HP in DreamX Battle Status.
 * @author JR
 *
 * @param Barrier Text Color
 * @type number
 * @min 0
 * @max 31
 * @desc The text color ID used for the barrier points text (e.g. 13 for cyan).
 * @default 13
 * 
 * @help
 * Place this plugin BELOW:
 * - YEP_AbsorptionBarrier
 * - DreamX_Ext_BattleStatusCore
 */

var JR = JR || {};
JR.BarrierUI = JR.BarrierUI || {};
JR.BarrierUI.Parameters = PluginManager.parameters('JR_BarrierDisplay_DreamX');
JR.BarrierUI.Color = Number(JR.BarrierUI.Parameters['Barrier Text Color'] || 13);

(function() {
    if (!Imported.YEP_AbsorptionBarrier || !Imported.DreamX_Ext_BattleStatusCore) {
        console.warn("JR_BarrierDisplay_DreamX requires YEP_AbsorptionBarrier and DreamX_Ext_BattleStatusCore.");
        return;
    }

    var _Window_BattleStatus_drawCurrentAndMax = Window_BattleStatus.prototype.drawCurrentAndMax;
    Window_BattleStatus.prototype.drawCurrentAndMax = function(current, max, x, y, width, color1, color2, alignment) {
        var actor = this._currentBarrierActor;

        if (actor && actor.barrierPoints() > 0) {
            var hpText = Yanfly.Util.toGroup(current);
            var barrierText = " (" + Yanfly.Util.toGroup(actor.barrierPoints()) + ")";
            
            var hpWidth = this.textWidth(hpText);
            var barrierWidth = this.textWidth(barrierText);
            var totalWidth = hpWidth + barrierWidth;
            
            if (!this._currentMax) {
                var drawX = x;
                
                if (alignment === 'right') {
                    drawX = x + width - totalWidth;
                } else if (alignment === 'center') {
                    drawX = x + (width - totalWidth) / 2;
                }

                this.changeTextColor(color1);
                // FIX: Use the full available 'width' instead of exact 'hpWidth' 
                // to prevent MV from artificially squishing short text like "0".
                this.drawText(hpText, drawX, y, width, 'left');
                
                this.changeTextColor(this.textColor(JR.BarrierUI.Color));
                this.drawText(barrierText, drawX + hpWidth, y, width, 'left');
                return;
            }
        }
        
        _Window_BattleStatus_drawCurrentAndMax.apply(this, arguments);
    };

    var _Window_BattleStatus_drawActorHp = Window_BattleStatus.prototype.drawActorHp;
    Window_BattleStatus.prototype.drawActorHp = function(actor, gaugeRect, rect) {
        this._currentBarrierActor = actor;
        _Window_BattleStatus_drawActorHp.call(this, actor, gaugeRect, rect);
        this._currentBarrierActor = null;
    };
})();