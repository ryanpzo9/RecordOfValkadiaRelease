//=============================================================================
// JR_RecipeCrafting_Subcategories.js
//=============================================================================

/*:
 * @plugindesc Extension for Recipe Crafting MV to add subcategories.
 * @author JR
 *
 * @param Weapon Category Name
 * @desc The exact name or text tag of your Weapons category in recipecrafting.js (e.g., Weapons or #{termwords.weapon})
 * @default Weapons
 *
 * @param Weapon Subcategories
 * @type struct<SubcatEquipment>[]
 * @desc Groupings for Weapon types.
 * @default []
 *
 * @param Armor Category Name
 * @desc The exact name or text tag of your Armor category in recipecrafting.js (e.g., Armors or #{termwords.armor})
 * @default Armors
 *
 * @param Armor Subcategories
 * @type struct<SubcatEquipment>[]
 * @desc Groupings for Armor types.
 * @default []
 *
 * @param Custom Categories
 * @type struct<SubcatCustom>[]
 * @desc Custom note-tag based subcategories (e.g., Reinforcement Crystals).
 * @default []
 *
 * @param Subcategory Help Text
 * @type string
 * @desc Help-window text shown while selecting a subcategory. Supports #{...} expressions.
 * @default Select to view items in this category.
 */
/*~struct~SubcatEquipment:
 * @param Name
 * @type string
 * @desc Name of the subcategory (e.g., Slash Dmg)
 *
 * @param Icon
 * @type number
 * @desc Icon index to display for this subcategory (0 for none)
 * @default 0
 *
 * @param Types
 * @type string
 * @desc Comma-separated list of type IDs to group (e.g., 1, 2)
 */
/*~struct~SubcatCustom:
 * @param Category Match
 * @type string
 * @desc The exact name or text tag of the main crafting category (e.g., #{vluecraftingcrystal})
 *
 * @param Name
 * @type string
 * @desc Name of the subcategory
 *
 * @param Icon
 * @type number
 * @desc Icon index to display for this subcategory (0 for none)
 * @default 0
 *
 * @param Note Tags
 * @type string
 * @desc Comma-separated strings that MUST ALL exist in the item's note box. Most specific matching subcategory wins.
 */

(function() {
    var parameters = PluginManager.parameters('JR_RecipeCrafting_Subcategories');
    
    function parseStructArray(paramString) {
        if (!paramString) return [];
        try {
            return JSON.parse(paramString).map(item => JSON.parse(item));
        } catch (e) {
            return [];
        }
    }

    var weaponCategoryName = parameters['Weapon Category Name'] || "Weapons";
    var armorCategoryName = parameters['Armor Category Name'] || "Armors";
    var subcategoryHelpText = parameters['Subcategory Help Text'] || "Select to view items in this category.";
    
    var weaponSubcats = parseStructArray(parameters['Weapon Subcategories']);
    var armorSubcats = parseStructArray(parameters['Armor Subcategories']);
    var customSubcats = parseStructArray(parameters['Custom Categories']);

    function parseIds(string) {
        if (!string) return [];
        return String(string).split(',').map(id => Number(id.trim())).filter(num => !isNaN(num));
    }

    function parseStrings(string) {
        if (!string) return [];
        return String(string).split(',').map(s => s.trim());
    }

    function resolveCategoryName(name) {
        if (!name) return "";
        var str = String(name).trim();
        if (str.startsWith("#{") && str.endsWith("}")) {
            try {
                return eval(str.substring(2, str.length - 1)) || str;
            } catch (e) {
                return str;
            }
        }
        return str;
    }

    // =========================================================================
    // Optimization: Pre-parse subcategory configuration at Plugin Initialization
    // =========================================================================
    weaponSubcats.forEach(sub => sub._parsedTypes = parseIds(sub['Types']));
    armorSubcats.forEach(sub => sub._parsedTypes = parseIds(sub['Types']));
    customSubcats.forEach(sub => sub._parsedTags = parseStrings(sub['Note Tags']));

    // =========================================================================
    // Window_RecipeList Modifications
    // =========================================================================
    
    var alias_Window_RecipeList_initialize = Window_RecipeList.prototype.initialize;
    Window_RecipeList.prototype.initialize = function(x, y, w, h) {
        this._subCategoryMode = false;
        this._currentSubCategory = null;
        this._currentSubCategoryData = null;
        alias_Window_RecipeList_initialize.call(this, x, y, w, h);
    };

    var alias_Window_RecipeList_setCategory = Window_RecipeList.prototype.setCategory;
    Window_RecipeList.prototype.setCategory = function(category) {
        if (category !== this._category) {
            this._currentSubCategory = null;
            this._currentSubCategoryData = null;
            this._subCategoryMode = this.hasSubcategories(category);
        }
        alias_Window_RecipeList_setCategory.call(this, category);
    };

    Window_RecipeList.prototype.hasSubcategories = function(category) {
        if (this.isReverse()) return false;
        
        var currentCat = resolveCategoryName(category);
        var targetWeapon = resolveCategoryName(weaponCategoryName);
        var targetArmor = resolveCategoryName(armorCategoryName);

        if (currentCat === targetWeapon && weaponSubcats.length > 0) return true;
        if (currentCat === targetArmor && armorSubcats.length > 0) return true;
        
        return customSubcats.some(c => resolveCategoryName(c['Category Match']) === currentCat);
    };

    Window_RecipeList.prototype.enterSubCategory = function(subCategoryName, subCategoryData) {
        this._currentSubCategory = subCategoryName;
        this._currentSubCategoryData = subCategoryData;
        this._subCategoryMode = false;
        this.resetRecipes();
        this.select(0);
        this.activate();
    };

    Window_RecipeList.prototype.exitSubCategory = function() {
        this._currentSubCategory = null;
        this._currentSubCategoryData = null;
        this._subCategoryMode = true;
        this.resetRecipes();
        this.select(0);
        this.activate();
    };

    var alias_Window_RecipeList_resetRecipes = Window_RecipeList.prototype.resetRecipes;
    Window_RecipeList.prototype.resetRecipes = function() {
        // Optimization: Cache resolved category strings ONCE per rebuild 
        // instead of per recipe inside the include loop.
        this._resolvedCurrentCat = resolveCategoryName(this._category);
        this._resolvedWeaponCat = resolveCategoryName(weaponCategoryName);
        this._resolvedArmorCat = resolveCategoryName(armorCategoryName);
        
        // Cache which custom categories belong to the current active tab
        this._matchingCustomSubcats = customSubcats.filter(c => 
            resolveCategoryName(c['Category Match']) === this._resolvedCurrentCat
        );

        if (this._subCategoryMode) {
            this.buildSubCategoryList();
        } else {
            alias_Window_RecipeList_resetRecipes.call(this);
        }
    };

    Window_RecipeList.prototype.buildSubCategoryList = function() {
        this._data = [];
        var subList = [];
        var currentCat = this._resolvedCurrentCat;
        
        if (currentCat === this._resolvedWeaponCat) {
            subList = weaponSubcats;
        } else if (currentCat === this._resolvedArmorCat) {
            subList = armorSubcats;
        } else {
            subList = this._matchingCustomSubcats;
        }

        for (var i = 0; i < subList.length; i++) {
            var subData = subList[i];
            var subName = subData['Name'];
            var subIcon = Number(subData['Icon']) || 0;
            
            this._data.push({
                isSubcategory: true,
                _subName: subName,
                _subData: subData, // Save the actual configuration object reference
                name: function() { return this._subName; },
                _result: { 
                    _item: { 
                        name: subName, 
                        description: resolveCategoryName(subcategoryHelpText), 
                        iconIndex: subIcon,
                        note: "",
                        meta: {}
                    }, 
                    _amount: 1 
                },
                _materials: [],
                _goldCost: 0,
                _level: 0,
                _craftLevel: 0,
                categoryId: function() { return 0; },
                craftable: function() { return true; },
                amountCraftable: function() { return 0; },
                hasCraftLevel: function() { return true; },
                hasLevel: function() { return true; },
                hasGold: function() { return true; },
                known: function() { return true; },
                successRate: function() { return 100; },
                xpGain: function() { return 0; }
            });
        }
        this.refresh();
    };

    var alias_Window_RecipeList_include = Window_RecipeList.prototype.include;
    Window_RecipeList.prototype.include = function(item) {
        var baseInclude = alias_Window_RecipeList_include.call(this, item);
        if (!baseInclude) return false;
        
        if (this._currentSubCategoryData && !this.isReverse()) {
            var dbItem = item._result._item;
            var currentCat = this._resolvedCurrentCat;
            
            // WEAPONS
            if (currentCat === this._resolvedWeaponCat) {
                if (dbItem.wtypeId !== undefined) {
                    return this._currentSubCategoryData._parsedTypes.includes(dbItem.wtypeId);
                }
                return false;
            }
            
            // ARMORS
            if (currentCat === this._resolvedArmorCat) {
                if (dbItem.atypeId !== undefined) {
                    return this._currentSubCategoryData._parsedTypes.includes(dbItem.atypeId);
                }
                return false;
            }
            
            // CUSTOM CATEGORIES
            var requiredTags = this._currentSubCategoryData._parsedTags;
            if (dbItem.note !== undefined && requiredTags && requiredTags.length > 0) {
                var currentMatches = requiredTags.every(tag => dbItem.note.includes(tag));
                if (!currentMatches) return false;

                var highestSpecificity = 0;
                // Use the pre-filtered _matchingCustomSubcats list
                for (var i = 0; i < this._matchingCustomSubcats.length; i++) {
                    var tags = this._matchingCustomSubcats[i]._parsedTags;
                    if (tags.every(tag => dbItem.note.includes(tag))) {
                        if (tags.length > highestSpecificity) {
                            highestSpecificity = tags.length;
                        }
                    }
                }

                return requiredTags.length === highestSpecificity;
            }
            return false;
        }
        return true;
    };

    var alias_Window_RecipeList_drawItemName = Window_RecipeList.prototype.drawItemName;
    Window_RecipeList.prototype.drawItemName = function(recipe, x, y, width) {
        if (recipe && recipe.isSubcategory) {
            width = width || 312;
            var iconBoxWidth = Window_Base._iconWidth + 4;
            var item = recipe._result._item;
            
            this.resetTextColor();
            
            if (item.iconIndex > 0) {
                this.drawIcon(item.iconIndex, x + 2, y + 2);
            }
            
            this.changeTextColor(this.systemColor());
            var textX = item.iconIndex > 0 ? x + iconBoxWidth : x + 4;
            var textW = item.iconIndex > 0 ? width - iconBoxWidth : width - 4;
            
            this.drawText(recipe.name(), textX, y, textW);
            this.resetTextColor();
            return;
        }
        alias_Window_RecipeList_drawItemName.call(this, recipe, x, y, width);
    };

    // =========================================================================
    // Scene_Crafting Intercepts
    // =========================================================================
    
    var alias_Scene_Crafting_listSuccess = Scene_Crafting.prototype.listSuccess;
    Scene_Crafting.prototype.listSuccess = function() {
        var current = this._listWindow.currentItem();
        if (current && current.isSubcategory) {
            this._listWindow.enterSubCategory(current.name(), current._subData);
            return;
        }
        alias_Scene_Crafting_listSuccess.call(this);
    };

    // =========================================================================
    // Cancel Handler Compatibility
    // =========================================================================
    var alias_Scene_Crafting_create = Scene_Crafting.prototype.create;
    Scene_Crafting.prototype.create = function() {
        alias_Scene_Crafting_create.call(this);

        if (!this._listWindow) return;

        var scene = this;
        var originalCancelHandler = this._listWindow._handlers &&
                                    this._listWindow._handlers['cancel'];

        this._listWindow.setHandler('cancel', function() {
            if (scene._listWindow._currentSubCategory !== null) {
                scene._listWindow.exitSubCategory();

                if (scene._detailWindow) {
                    scene._detailWindow.setRecipe(null, false);
                }

                if (scene._confirmWindow) {
                    scene._confirmWindow.setRecipe(null, false);
                }

                scene._listWindow.activate();
                return;
            }

            if (originalCancelHandler) {
                originalCancelHandler();
            }
        });
    };

})();