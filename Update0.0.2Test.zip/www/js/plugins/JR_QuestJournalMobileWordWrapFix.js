//=============================================================================
// JR_QuestJournalMobileWordWrapFix.js
//=============================================================================
/*:
 * @plugindesc v1.00 Fixes YEP_QuestJournal <WordWrap> blank contents on mobile by sizing the quest contents bitmap to the measured wrapped text height.
 * @author JR
 *
 * @help
 * ============================================================================
 * JR Quest Journal Mobile WordWrap Fix
 * ============================================================================
 *
 * Requirements:
 * - YEP_MessageCore.js
 * - YEP_QuestJournal.js
 *
 * Plugin Order:
 * Place this plugin BELOW both YEP_MessageCore.js and YEP_QuestJournal.js.
 *
 * This patch only changes Quest Journal drawing on mobile devices.
 * Desktop/NW.js uses the original YEP_QuestJournal behavior unchanged.
 *
 * The original YEP_QuestJournal multiplies the estimated contents height by
 * 10 whenever <WordWrap> is used. On mobile this can create an excessively
 * tall bitmap/texture and make the Quest Data window appear blank.
 *
 * On mobile, this patch performs a small measurement pass using the real
 * YEP_MessageCore word-wrap logic, then recreates the Quest Data contents at
 * the measured height and draws the text normally.
 *
 * No plugin commands.
 * No parameters.
 */

(function() {
    'use strict';

    if (typeof Window_QuestData === 'undefined') return;
    if (typeof Utils === 'undefined' || !Utils.isMobileDevice) return;

    var _JR_QJMWF_drawEmpty = Window_QuestData.prototype.drawEmpty;
    var _JR_QJMWF_drawQuestData = Window_QuestData.prototype.drawQuestData;

    function jrIsMobile() {
        return Utils.isMobileDevice();
    }

    Window_QuestData.prototype.jrDrawMobileWrappedQuestText = function(text) {
        var standardHeight = Math.max(
            1,
            this.height - this.standardPadding() * 2
        );

        this._allTextHeight = standardHeight;
        this.createContents();
        this.contents.clear();

        this.drawQuestTextEx(text, 0, 0);

        var measuredHeight = Math.max(
            standardHeight,
            Math.ceil(this._allTextHeight || standardHeight)
        );

        this._allTextHeight = measuredHeight;
        this.createContents();
        this.contents.clear();
        this.drawQuestTextEx(text, 0, 0);
    };

    Window_QuestData.prototype.drawEmpty = function() {
        if (!jrIsMobile()) {
            _JR_QJMWF_drawEmpty.call(this);
            return;
        }

        var fmt = Window_QuestData._questNoDataFmt;
        var wordwrap = fmt && fmt.match(/<(?:WordWrap)>/i);

        if (!wordwrap) {
            _JR_QJMWF_drawEmpty.call(this);
            return;
        }

        var text = fmt.format();
        this.jrDrawMobileWrappedQuestText(text);
    };

    Window_QuestData.prototype.drawQuestData = function() {
        if (!jrIsMobile()) {
            _JR_QJMWF_drawQuestData.call(this);
            return;
        }

        Window_QuestData._questDataFmt = JSON.parse(
            Yanfly.Param.QuestDataWindow['Quest Data Format'] || ''
        );

        var questData = $dataQuests[this._questId];
        if (!questData) return;

        var fmt = Window_QuestData._questDataFmt;
        var wordwrap = fmt && fmt.match(/<(?:WordWrap)>/i);

        if (!wordwrap) {
            _JR_QJMWF_drawQuestData.call(this);
            return;
        }

        var title = questData.name;
        title = title.replace(/\\I\[(\d+)\]/gi, '').trim();
        title = title.replace(/\\C\[(\d+)\]/gi, '').trim();

        var difficulty = questData.difficulty;
        var from = questData.from;
        var location = questData.location;
        var description = this.getQuestDescription();
        var objectives = this.getQuestObjectives(wordwrap);
        var rewards = this.getQuestRewards(wordwrap);
        var subtext = this.getQuestSubtext();

        var text = fmt.format(
            title,
            difficulty,
            from,
            location,
            description,
            objectives,
            rewards,
            subtext
        );

        this.jrDrawMobileWrappedQuestText(text);
    };

})();