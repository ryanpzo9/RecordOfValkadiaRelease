﻿//=============================================================================
// MOG_TitlePictureCom.js
//=============================================================================

/*:
 * @plugindesc (v1.6 + Intro Edit 17) Replaces title window with picture commands, intro transition, SEs & Idle Timeout.
 * @author Moghunter (JR Edited)
 *
 * @param Title Sprite
 * @desc Enable the title name as a sprite.
 * Requires the file Title.png in the folder img/titles2/
 * @default true
 * 
 * @param Title Sprite X-Axis
 * @desc X-axis position of the title text/sprite.
 * @default 0
 *
 * @param Title Sprite Y-Axis
 * @desc Y-axis position of the title text/sprite.
 * @default 0 
 *
 * @param Cursor Background
 * @type file
 * @dir img/titles2/
 * @desc Background image behind the selected command. Leave blank or None for no BG.
 * @default 
 * 
 * @param Cursor BG Animation
 * @type select
 * @option None
 * @value 0
 * @option Breathe
 * @value 1
 * @option Float
 * @value 2
 * @option Spin
 * @value 3
 * @desc The idle animation for the Cursor Background.
 * @default 1
 * 
 * @param Command Animation
 * @type select
 * @option None
 * @value 0
 * @option Breathe
 * @value 1
 * @option Float
 * @value 2
 * @option Spin
 * @value 3
 * @desc The idle animation for the actively selected command.
 * @default 1
 *
 * @param Cursor Visible
 * @desc Enable cursor visibility.
 * @default true
 *
 * @param Cursor Wave Animation
 * @desc Enable the sliding wave animation for the cursor.
 * @default true
 * 
 * @param Cursor X-Axis
 * @desc X-axis offset for the cursor.
 * @default 8
 *
 * @param Cursor Y-Axis
 * @desc Y-axis offset for the cursor.
 * @default -10  
 *
 * @param Start Text
 * @desc The text to display before showing commands.
 * @default Press Any Button
 *
 * @param Start Text Size
 * @desc The font size of the start text.
 * @default 28
 *
 * @param Start Text Color
 * @desc The color of the start text (Hex or CSS color).
 * @default #ffffff
 *
 * @param Start Text X
 * @desc X-axis offset of the start text (0 is centered).
 * @default 0
 *
 * @param Start Text Y
 * @desc Y-axis position of the start text.
 * @default 450
 *
 * @param Transition Type
 * @desc 0: Fade | 1: Slide Up | 2: Slide Right (from left) | 3: Slide Left (from right)
 * @default 1
 * 
 * @param Transition Speed
 * @desc How fast the commands slide into position (pixels per frame).
 * @default 8
 * 
 * @param Transition Distance
 * @desc How many pixels away the commands start their slide from.
 * @default 120
 * 
 * @param Idle Timeout (Seconds)
 * @desc Seconds of inactivity before returning to intro text. 0 to disable.
 * @default 10
 * 
 * @param Exit Transition Type
 * @desc 0: Fade | 1: Slide Down | 2: Slide Left | 3: Slide Right
 * @default 1
 * 
 * @param Transition SE
 * @type file
 * @dir audio/se/
 * @desc SE when a command starts sliding IN. Leave blank for none.
 * @default Wind7
 *
 * @param Transition SE Volume
 * @desc Volume of the transition sound effect.
 * @default 90
 *
 * @param Transition SE Pitch
 * @desc Pitch of the transition sound effect.
 * @default 100
 *
 * @param Exit Transition SE
 * @type file
 * @dir audio/se/
 * @desc SE when a command starts sliding OUT. Leave blank or type None for no SE.
 * @default 
 *
 * @param Exit Transition SE Volume
 * @desc Volume of the exit transition sound effect.
 * @default 90
 *
 * @param Exit Transition SE Pitch
 * @desc Pitch of the exit transition sound effect.
 * @default 100
 * 
 * @param Cursor SE
 * @type file
 * @dir audio/se/
 * @desc Custom SE when navigating between commands. Leave blank for default MV sound.
 * @default 
 *
 * @param Cursor SE Volume
 * @desc Volume of the cursor sound effect.
 * @default 90
 *
 * @param Cursor SE Pitch
 * @desc Pitch of the cursor sound effect.
 * @default 100
 *
 * @param Select SE
 * @type file
 * @dir audio/se/
 * @desc Custom SE when confirming/selecting a command. Leave blank for default MV sound.
 * @default 
 *
 * @param Select SE Volume
 * @desc Volume of the select sound effect.
 * @default 90
 *
 * @param Select SE Pitch
 * @desc Pitch of the select sound effect.
 * @default 100
 *
 * @param Command Pos 1
 * @desc Position of command 1 (New Game). E.g: windowWidth / 2 - 100, 460
 * @default 650,460
 *
 * @param Command Pos 2
 * @desc Position of command 2 (Continue). E.g: command1X, command1Y + 30
 * @default 660,490
 *
 * @param Command Pos 3
 * @desc Position of command 3 (Options). E.g: command2X, command2Y + 30
 * @default 665,520
 *
 * @param Command Pos 4
 * @desc Position of command 4.
 * @default 670,550
 *
 * @param Command Pos 5
 * @desc Position of command 5.
 * @default 345,498  
 *
 * @param Command Pos 6
 * @desc Position of command 6.
 * @default 345,530
 *
 * @param Command Pos 7
 * @desc Position of command 7.
 * @default 0,192
 *
 * @param Command Pos 8
 * @desc Position of command 8.
 * @default 0,224
 *
 * @param Command Pos 9
 * @desc Position of command 9.
 * @default 0,256
 *
 * @param Command Pos 10
 * @desc Position of command 10.
 * @default 0,288  
 *
 * @help  
 * =============================================================================
 * +++ MOG - Title Picture Commands (v1.6) +++
 * By Moghunter 
 * https://atelierrgss.wordpress.com/
 * =============================================================================
 * Replaces the default window commands with picture commands.
 * The following files are required:
 *
 * Command_0.png, Command_1.png, Command_2.png , Command_3.png ... 
 * Save the images in the folder: img/titles2/
 * 
 * An image representing the cursor is also required: Cursor.png
 *
 * =============================================================================
 * ** Custom Intro & Transitions Edit **
 * =============================================================================
 * - Added a "Press Any Button" phase with a customizable breathing effect.
 * - Added customizable transition effects (Fade, Slide Up, Left, Right).
 * - Added control over Transition Speed and Transition Distance.
 * - Added Idle Timeout tracking to automatically exit back to the intro phase.
 * - Added customizable Exit Transition effects (animates in reverse order).
 * - Added independent SE controls for Entry, Exit, Cursor Navigation, and Select.
 * - Added smooth gliding Cursor Background behind active commands.
 * - Added customizable idle animations for BOTH Cursor BG and active commands.
 * - Fixed "Double State" sprite display bug during transitions.
 * - Automatically skips disabled commands (like Continue without a save file) when navigating.
 * - Commands stay hidden perfectly during intro phase.
 * - IAVRA Localization support included (loads CommandVi_X.png for Vietnamese).
 * - Q and W keys are now tracked to prevent idle timeouts.
 * 
 * ** Smart Command Positioning **
 * You can now use formulas and screen variables in the Position parameters!
 * 
 * General Screen Variables:
 * - windowWidth  (or boxWidth)  : Returns the total width of the game screen.
 * - windowHeight (or boxHeight) : Returns the total height of the game screen.
 * 
 * Sequential Position Variables:
 * - command1X, command1Y : Returns the final X/Y of Command 1.
 * - command2X, command2Y : Returns the final X/Y of Command 2.
 * (And so on up to command10X and command10Y).
 */

//=============================================================================
// ** PLUGIN PARAMETERS
//=============================================================================
var Imported = Imported || {};
Imported.MOG_Picture_Command = true;
var Moghunter = Moghunter || {}; 

Moghunter.parameters = PluginManager.parameters('MOG_TitlePictureCom');
Moghunter.title_sprite = (Moghunter.parameters['Title Sprite'] || false);
Moghunter.title_x = Number(Moghunter.parameters['Title Sprite X-Axis'] || 0);
Moghunter.title_y = Number(Moghunter.parameters['Title Sprite Y-Axis'] || 0);

Moghunter.title_cursorBg = String(Moghunter.parameters['Cursor Background'] || "");
Moghunter.title_cursorBgAnim = Number(Moghunter.parameters['Cursor BG Animation'] || 1);
Moghunter.title_commandAnim = Number(Moghunter.parameters['Command Animation'] || 1);
Moghunter.title_cursorVisible = String(Moghunter.parameters['Cursor Visible'] || "true");
Moghunter.title_cursorSlide = String(Moghunter.parameters['Cursor Wave Animation'] || "true");
Moghunter.title_cursorX = Number(Moghunter.parameters['Cursor X-Axis'] || 8);
Moghunter.title_cursorY = Number(Moghunter.parameters['Cursor Y-Axis'] || -10);	

Moghunter.title_startText = String(Moghunter.parameters['Start Text'] || "Press Any Button");
Moghunter.title_startTextSize = Number(Moghunter.parameters['Start Text Size'] || 28);
Moghunter.title_startTextColor = String(Moghunter.parameters['Start Text Color'] || "#ffffff");
Moghunter.title_startTextX = Number(Moghunter.parameters['Start Text X'] || 0);
Moghunter.title_startTextY = Number(Moghunter.parameters['Start Text Y'] || 450);
Moghunter.title_transitionType = Number(Moghunter.parameters['Transition Type'] || 1);
Moghunter.title_transitionSpeed = Number(Moghunter.parameters['Transition Speed'] || 8);
Moghunter.title_transitionDistance = Number(Moghunter.parameters['Transition Distance'] || 120);

Moghunter.title_idleTimeout = Number(Moghunter.parameters['Idle Timeout (Seconds)'] || 10);
Moghunter.title_exitTransitionType = Number(Moghunter.parameters['Exit Transition Type'] || 1);

Moghunter.title_transitionSE = String(Moghunter.parameters['Transition SE'] || "");
Moghunter.title_transitionSEVol = Number(Moghunter.parameters['Transition SE Volume'] || 90);
Moghunter.title_transitionSEPit = Number(Moghunter.parameters['Transition SE Pitch'] || 100);

Moghunter.title_exitTransitionSE = String(Moghunter.parameters['Exit Transition SE'] || "");
Moghunter.title_exitTransitionSEVol = Number(Moghunter.parameters['Exit Transition SE Volume'] || 90);
Moghunter.title_exitTransitionSEPit = Number(Moghunter.parameters['Exit Transition SE Pitch'] || 100);

Moghunter.title_cursorSE = String(Moghunter.parameters['Cursor SE'] || "");
Moghunter.title_cursorSEVol = Number(Moghunter.parameters['Cursor SE Volume'] || 90);
Moghunter.title_cursorSEPit = Number(Moghunter.parameters['Cursor SE Pitch'] || 100);

Moghunter.title_selectSE = String(Moghunter.parameters['Select SE'] || "");
Moghunter.title_selectSEVol = Number(Moghunter.parameters['Select SE Volume'] || 90);
Moghunter.title_selectSEPit = Number(Moghunter.parameters['Select SE Pitch'] || 100);

Moghunter.title_com_pos = [];
for (var i = 0; i < 10; i++) {
    Moghunter.title_com_pos[i] = (Moghunter.parameters['Command Pos ' + String(i + 1)] || null);
};	
	
//=============================================================================
// ** SoundManager Override
//=============================================================================	
var _alias_mog_title_SoundManager_playCursor = SoundManager.playCursor;
SoundManager.playCursor = function() {
    var cursorSE = Moghunter.title_cursorSE;
    if (SceneManager._scene instanceof Scene_Title && cursorSE !== "" && cursorSE.toLowerCase() !== "none") {
        AudioManager.playSe({
            name: cursorSE,
            volume: Moghunter.title_cursorSEVol,
            pitch: Moghunter.title_cursorSEPit,
            pan: 0
        });
    } else {
        _alias_mog_title_SoundManager_playCursor.call(this);
    }
};

var _alias_mog_title_SoundManager_playOk = SoundManager.playOk;
SoundManager.playOk = function() {
    var selectSE = Moghunter.title_selectSE;
    if (SceneManager._scene instanceof Scene_Title && selectSE !== "" && selectSE.toLowerCase() !== "none") {
        AudioManager.playSe({
            name: selectSE,
            volume: Moghunter.title_selectSEVol,
            pitch: Moghunter.title_selectSEPit,
            pan: 0
        });
    } else {
        _alias_mog_title_SoundManager_playOk.call(this);
    }
};

//=============================================================================
// ** Window_TitleCommand
//=============================================================================	
var _alias_mog_title_picture_commands_updatePlacement = Scene_Title.prototype.updatePlacement;
Window_TitleCommand.prototype.updatePlacement = function() {
   this.x = -Graphics.boxWidth;
   this.y = -Graphics.boxHeight;
   this.visible = false;
};

Window_TitleCommand.prototype.cursorDown = function(wrap) {
    var index = this.index();
    var maxItems = this.maxItems();
    var maxCols = this.maxCols();
    if (index < maxItems - maxCols || (wrap && maxCols === 1)) {
        var nextIndex = (index + maxCols) % maxItems;
        while (nextIndex !== index && !this.isCommandEnabled(nextIndex)) {
            nextIndex = (nextIndex + maxCols) % maxItems;
        }
        this.select(nextIndex);
    }
};

Window_TitleCommand.prototype.cursorUp = function(wrap) {
    var index = this.index();
    var maxItems = this.maxItems();
    var maxCols = this.maxCols();
    if (index >= maxCols || (wrap && maxCols === 1)) {
        var nextIndex = (index - maxCols + maxItems) % maxItems;
        while (nextIndex !== index && !this.isCommandEnabled(nextIndex)) {
            nextIndex = (nextIndex - maxCols + maxItems) % maxItems;
        }
        this.select(nextIndex);
    }
};

//=============================================================================
// ** Scene Title
//=============================================================================	

var _alias_mog_title_picture_commands_create = Scene_Title.prototype.create;
Scene_Title.prototype.create = function() {
    _alias_mog_title_picture_commands_create.call(this);
    this.createCursorBackground(); 
    this.create_picture_commands();
    if (String(Moghunter.title_cursorVisible) === "true") {this.createCursorCommand()};
    this._comSave = this._commandWindow.isContinueEnabled();
    
    this._introPhase = 0; 
    this._transitionFrames = 0;
    this._exitFrames = 0;
    this._idleFrames = 0;
    this._lastTouchX = 0;
    this._lastTouchY = 0;
    this._globalAnimTimer = 0;
    this._comFramesInitialized = false; 
    
    this._commandWindow.deactivate(); 
    this._commandWindow.deselect();
    if (this._cursor) this._cursor.visible = false;
    
    this.createIntroText();
};

Scene_Title.prototype.createCursorBackground = function() {
    var bgName = Moghunter.title_cursorBg;
    if (bgName !== "" && bgName.toLowerCase() !== "none") {
        this._cursorBg = new Sprite(ImageManager.loadTitle2(bgName));
        this._cursorBg.anchor.x = 0.5;
        this._cursorBg.anchor.y = 0.5;
        this._cursorBg.opacity = 0;
        this.addChild(this._cursorBg);
    }
};

Scene_Title.prototype.set_tcp = function(value) {
    if (!value) {return null};
    
    var command1X = this._com_position[0] ? this._com_position[0][0] : 0;
    var command1Y = this._com_position[0] ? this._com_position[0][1] : 0;
    var command2X = this._com_position[1] ? this._com_position[1][0] : 0;
    var command2Y = this._com_position[1] ? this._com_position[1][1] : 0;
    var command3X = this._com_position[2] ? this._com_position[2][0] : 0;
    var command3Y = this._com_position[2] ? this._com_position[2][1] : 0;
    var command4X = this._com_position[3] ? this._com_position[3][0] : 0;
    var command4Y = this._com_position[3] ? this._com_position[3][1] : 0;
    var command5X = this._com_position[4] ? this._com_position[4][0] : 0;
    var command5Y = this._com_position[4] ? this._com_position[4][1] : 0;
    var command6X = this._com_position[5] ? this._com_position[5][0] : 0;
    var command6Y = this._com_position[5] ? this._com_position[5][1] : 0;
    var command7X = this._com_position[6] ? this._com_position[6][0] : 0;
    var command7Y = this._com_position[6] ? this._com_position[6][1] : 0;
    var command8X = this._com_position[7] ? this._com_position[7][0] : 0;
    var command8Y = this._com_position[7] ? this._com_position[7][1] : 0;
    var command9X = this._com_position[8] ? this._com_position[8][0] : 0;
    var command9Y = this._com_position[8] ? this._com_position[8][1] : 0;
    var command10X = this._com_position[9] ? this._com_position[9][0] : 0;
    var command10Y = this._com_position[9] ? this._com_position[9][1] : 0;

    var parsedValue = value.replace(/windowWidth/g, "Graphics.boxWidth")
                           .replace(/windowHeight/g, "Graphics.boxHeight")
                           .replace(/boxWidth/g, "Graphics.boxWidth")
                           .replace(/boxHeight/g, "Graphics.boxHeight");
                           
    var s = parsedValue.split(',');
    if (!s[0] || !s[1]) {return null};
    
    var finalX = 0, finalY = 0;
    try {
        finalX = Number(eval(s[0]));
        finalY = Number(eval(s[1]));
    } catch (e) {
        console.warn("MOG_TitlePictureCom: Invalid position format.", e);
        finalX = 0;
        finalY = 0;
    }
    
    return [finalX, finalY];
};

var _alias_mog_title_picture_commands_update = Scene_Title.prototype.update;
Scene_Title.prototype.update = function() {
    _alias_mog_title_picture_commands_update.call(this);
    
    if (!this._comFramesInitialized && ImageManager.isReady()) {
        this.refresh_picture_command();
        this._comFramesInitialized = true;
    }
    
    if (this._introPhase === 0) {
        this.updateIntroText();
        if (Input.isTriggered('ok') || Input.isTriggered('cancel') || TouchInput.isTriggered()) {
            this._introPhase = 1;
            this._transitionFrames = 0; 
            this._introTextSprite.visible = false;
        }
    } else if (this._introPhase === 1) {
        this.updateTransition();
    } else if (this._introPhase === 2) {
        this.update_picture_commands();
    } else if (this._introPhase === 3) {
        this.updateExitTransition();
    }
};

Scene_Title.prototype.createIntroText = function() {
    var text = Moghunter.title_startText;
    var size = Moghunter.title_startTextSize;
    var color = Moghunter.title_startTextColor;
    
    this._introTextSprite = new Sprite(new Bitmap(Graphics.boxWidth, size + 20));
    this._introTextSprite.bitmap.fontSize = size;
    this._introTextSprite.bitmap.textColor = color;
    this._introTextSprite.bitmap.drawText(text, 0, 0, Graphics.boxWidth, size + 20, 'center');
    
    this._introTextSprite.x = Moghunter.title_startTextX;
    this._introTextSprite.y = Moghunter.title_startTextY;
    this._introTextPhase = 0; 
    this.addChild(this._introTextSprite);
};

Scene_Title.prototype.updateIntroText = function() {
    if (!this._introTextSprite) return;
    if (this._introTextPhase === 0) {
        this._introTextSprite.opacity -= 3;
        if (this._introTextSprite.opacity <= 80) this._introTextPhase = 1;
    } else {
        this._introTextSprite.opacity += 3;
        if (this._introTextSprite.opacity >= 255) this._introTextPhase = 0;
    }
};

Scene_Title.prototype.updateTransition = function() {
    let allDone = true;
    let speed = Moghunter.title_transitionSpeed;
    let staggerFrames = 10; 
    
    for (let i = 0; i < this._com_sprites.length; i++) {
        
        if (this._transitionFrames === i * staggerFrames) {
            var transSE = Moghunter.title_transitionSE;
            if (transSE !== "" && transSE.toLowerCase() !== "none") {
                AudioManager.playSe({
                    name: transSE,
                    volume: Moghunter.title_transitionSEVol,
                    pitch: Moghunter.title_transitionSEPit,
                    pan: 0
                });
            }
        }
        
        if (this._transitionFrames < i * staggerFrames) {
            allDone = false;
            continue; 
        }
        
        let sprite = this._com_sprites[i];
        let targetX = this._com_position[i][0];
        let targetY = this._com_position[i][1];
        let maxOp = (this._commandWindow._list[i].symbol === 'continue' && !this._comSave) ? 160 : 255;
        
        if (sprite.opacity < maxOp) {
            sprite.opacity += 10;
            if (sprite.opacity > maxOp) sprite.opacity = maxOp;
            allDone = false;
        }
        if (sprite.x !== targetX) {
            if (sprite.x > targetX) { sprite.x = Math.max(sprite.x - speed, targetX); }
            else { sprite.x = Math.min(sprite.x + speed, targetX); }
            allDone = false;
        }
        if (sprite.y !== targetY) {
            if (sprite.y > targetY) { sprite.y = Math.max(sprite.y - speed, targetY); }
            else { sprite.y = Math.min(sprite.y + speed, targetY); }
            allDone = false;
        }
    }
    
    this._transitionFrames++;
    
    if (allDone) {
        this._introPhase = 2;
        this._idleFrames = 0; 
        if (this._cursor) this._cursor.visible = true;
        this._commandWindow.activate();
        
        let defaultIdx = this._comSave ? 1 : 0;
        this._commandWindow.select(defaultIdx);
        this._com_index_old = -2; 
        
        if (this._cursorBg) {
            var data = this._com_pictures_data[defaultIdx];
            if (data) {
                this._cursorBg.x = this._com_position[defaultIdx][0] + (data[1] / 2);
                this._cursorBg.y = this._com_position[defaultIdx][1] + (data[3] / 2);
            }
        }
    }
};

Scene_Title.prototype.updateExitTransition = function() {
    let allDone = true;
    let speed = Moghunter.title_transitionSpeed;
    let staggerFrames = 10; 
    var exitType = Moghunter.title_exitTransitionType;
    var dist = Moghunter.title_transitionDistance;
    
    if (this._cursorBg && this._cursorBg.opacity > 0) {
        this._cursorBg.opacity -= 10;
    }

    for (let i = 0; i < this._com_sprites.length; i++) {
        let reverseIndex = (this._com_sprites.length - 1) - i;
        
        // Return sprites to normal anchors before sweeping out
        let sprite = this._com_sprites[reverseIndex];
        if (sprite.anchor.x !== 0 || sprite.anchor.y !== 0) {
            sprite.anchor.set(0, 0);
            sprite.scale.set(1, 1);
            sprite.rotation = 0;
            sprite.x = this._com_position[reverseIndex][0];
            sprite.y = this._com_position[reverseIndex][1];
        }
        
        if (this._exitFrames === i * staggerFrames) {
            var exitSE = Moghunter.title_exitTransitionSE;
            if (exitSE !== "" && exitSE.toLowerCase() !== "none") {
                AudioManager.playSe({
                    name: exitSE,
                    volume: Moghunter.title_exitTransitionSEVol,
                    pitch: Moghunter.title_exitTransitionSEPit,
                    pan: 0
                });
            }
        }
        
        if (this._exitFrames < i * staggerFrames) {
            allDone = false;
            continue; 
        }
        
        let targetX = this._com_position[reverseIndex][0];
        let targetY = this._com_position[reverseIndex][1];
        
        if (exitType === 1) targetY += dist; 
        if (exitType === 2) targetX -= dist; 
        if (exitType === 3) targetX += dist; 
        
        if (sprite.opacity > 0) {
            sprite.opacity -= 10;
            if (sprite.opacity < 0) sprite.opacity = 0;
            allDone = false;
        }
        if (sprite.x !== targetX) {
            if (sprite.x > targetX) { sprite.x = Math.max(sprite.x - speed, targetX); }
            else { sprite.x = Math.min(sprite.x + speed, targetX); }
            allDone = false;
        }
        if (sprite.y !== targetY) {
            if (sprite.y > targetY) { sprite.y = Math.max(sprite.y - speed, targetY); }
            else { sprite.y = Math.min(sprite.y + speed, targetY); }
            allDone = false;
        }
    }
    
    this._exitFrames++;
    
    if (allDone) {
        this._introPhase = 0; 
        this._introTextSprite.visible = true;
        this._introTextSprite.opacity = 0;
        this._introTextPhase = 1; 
    }
};

Scene_Title.prototype.createCursorCommand = function() {
    this._cursorSlide = [0,0,0,false];
    if (String(Moghunter.title_cursorSlide) === "true") {this._cursorSlide[3] = true};
    this._cursor = new Sprite(ImageManager.loadTitle2("Cursor"));
    this._cursor.anchor.x = 0.5;
    this._cursor.anchor.y = 0.5;
    this._cursor.opacity = 0;
    this.addChild(this._cursor);
};

Scene_Title.prototype.comSprite = function() {
    return this._com_sprites[this._commandWindow._index];
};

Scene_Title.prototype.updateCursor = function() {
     if (this._cursorSlide[3]) {this.updateCursorSlide()};
     this._cursor.opacity += 10;
     var nx = this.comSprite().x + Moghunter.title_cursorX + this._cursorSlide[0];
     var ny = this.comSprite().y + Moghunter.title_cursorY;
     
     // Recalculate based on dynamic anchor shifts for the currently selected command
     var data = this._com_pictures_data[this._commandWindow._index];
     if (this.comSprite().anchor.x === 0.5) {
         nx -= (data[1] / 2);
         ny -= (data[3] / 2);
     }
     
     this._cursor.x = this.cursorMoveto(this._cursor.x, nx, 20);
     this._cursor.y = this.cursorMoveto(this._cursor.y, ny, 20);
};

Scene_Title.prototype.updateCursorBackground = function() {
    this._cursorBg.opacity += 10;
    var index = this._commandWindow._index;
    var data = this._com_pictures_data[index];
    if (data) {
        // Determine original top-left X/Y based on anchor state
        var activeSpr = this.comSprite();
        var baseNx = activeSpr.x;
        var baseNy = activeSpr.y;
        
        if (activeSpr.anchor.x === 0.5) {
            baseNx -= (data[1] / 2);
            baseNy -= (data[3] / 2);
        }
        
        var nx = baseNx + (data[1] / 2);
        var ny = baseNy + (data[3] / 2);
        
        this._cursorBg.x = this.cursorMoveto(this._cursorBg.x, nx, 15);
        this._cursorBg.y = this.cursorMoveto(this._cursorBg.y, ny, 15);
    }
    
    var animType = Moghunter.title_cursorBgAnim;
    if (animType > 0) {
        if (animType === 1) { 
            var s = 1.0 + Math.sin(this._globalAnimTimer * 0.05) * 0.05;
            this._cursorBg.scale.set(s, s);
            this._cursorBg.anchor.y = 0.5;
            this._cursorBg.rotation = 0;
        } else if (animType === 2) { 
            this._cursorBg.scale.set(1, 1);
            this._cursorBg.anchor.y = 0.5 + Math.sin(this._globalAnimTimer * 0.05) * 0.1;
            this._cursorBg.rotation = 0;
        } else if (animType === 3) { 
            this._cursorBg.scale.set(1, 1);
            this._cursorBg.anchor.y = 0.5;
            this._cursorBg.rotation += 0.02;
        }
    } else {
        this._cursorBg.scale.set(1, 1);
        this._cursorBg.anchor.y = 0.5;
        this._cursorBg.rotation = 0;
    }
};

Scene_Title.prototype.updateCommandAnimation = function() {
    if (this._introPhase !== 2) return;
    
    var animType = Moghunter.title_commandAnim;
    var timer = this._globalAnimTimer;
    
    for (var i = 0; i < this._com_sprites.length; i++) {
        var sprite = this._com_sprites[i];
        var data = this._com_pictures_data[i];
        if (!data) continue;
        
        var baseX = this._com_position[i][0];
        var baseY = this._com_position[i][1];
        var w = data[1];
        var h = data[3]; 
        
        if (i === this._commandWindow._index && animType > 0) {
            if (animType === 1) { // Breathe
                sprite.anchor.set(0.5, 0.5);
                var scaleOffset = Math.sin(timer * 0.05) * 0.05;
                sprite.scale.set(1 + scaleOffset, 1 + scaleOffset);
                sprite.x = baseX + w / 2;
                sprite.y = baseY + h / 2;
                sprite.rotation = 0;
            } else if (animType === 2) { // Float
                sprite.anchor.set(0, 0);
                sprite.scale.set(1, 1);
                sprite.x = baseX;
                sprite.y = baseY + Math.sin(timer * 0.05) * 5;
                sprite.rotation = 0;
            } else if (animType === 3) { // Spin
                sprite.anchor.set(0.5, 0.5);
                sprite.scale.set(1, 1);
                sprite.x = baseX + w / 2;
                sprite.y = baseY + h / 2;
                sprite.rotation += 0.02;
            }
        } else {
            // Unselected commands return to standard default layout
            sprite.anchor.set(0, 0);
            sprite.scale.set(1, 1);
            sprite.rotation = 0;
            sprite.x = baseX;
            sprite.y = baseY;
        }
    }
};

Scene_Title.prototype.updateCursorSlide = function() {
     this._cursorSlide[1] ++
     if (this._cursorSlide[1] < 3) {return};
     this._cursorSlide[1] = 0
     this._cursorSlide[2] ++
     if (this._cursorSlide[2] < 15) {
         this._cursorSlide[0] ++;
     } else if (this._cursorSlide[2] < 30) {
         this._cursorSlide[0] --;
     } else {
         this._cursorSlide[0] = 0;
         this._cursorSlide[2] = 0;
     };
};

Scene_Title.prototype.cursorMoveto = function(value,real_value,speed) {
    if (value == real_value) {return value};
    var dnspeed = 5 + (Math.abs(value - real_value) / speed);
    if (value > real_value) {value -= dnspeed;
        if (value < real_value) {value = real_value};}
    else if (value < real_value) {value  += dnspeed;
        if (value  > real_value) {value  = real_value};		
    };
    return Math.floor(value);
};

Scene_Title.prototype.create_picture_commands = function() {
    this._com_position = [];
    for (var i = 0; i < 10; i++) {
        this._com_position[i] = this.set_tcp(Moghunter.title_com_pos[i]);
    };	
    this._csel = false;
    this._com_pictures = [];
    this._com_sprites = [];	
    this._com_pictures_data = [];
    
    var transType = Moghunter.title_transitionType;
    var dist = Moghunter.title_transitionDistance;
    
    for (i = 0; i < this._commandWindow._list.length; i++){
        if (typeof IAVRA !== 'undefined' && IAVRA.I18N.language === 'vi'){
            this._com_pictures.push(ImageManager.loadTitle2("CommandVi_" + i));
        } else {
            this._com_pictures.push(ImageManager.loadTitle2("Command_" + i));
        }
        this._com_sprites.push(new Sprite(this._com_pictures[i]));
        
        this._com_sprites[i].opacity = 0;
        var startX = this._com_position[i][0];
        var startY = this._com_position[i][1];
        
        if (transType === 1) startY += dist; 
        if (transType === 2) startX -= dist; 
        if (transType === 3) startX += dist; 
        
        this._com_sprites[i].x = startX;
        this._com_sprites[i].y = startY;
        
        this.addChild(this._com_sprites[i]);	
    };
    this._com_index_old = -2; 
};

Scene_Title.prototype.refresh_picture_command = function() {
    this._com_index_old = this._commandWindow._index;
    for (i = 0; i < this._com_sprites.length; i++){
        if (this._commandWindow._index != i) {
            var ch = this._com_pictures[i].height / 2;
        } else {
            var ch = 0;
        }
        
        this.cpsx = [this._com_position[i][0],this._com_position[i][1]];
        
        if (this._introPhase === 2) {
            if (this._commandWindow._list[i].symbol === 'continue' && !this._comSave) {
                this._com_sprites[i].opacity = 160;
            } else {
                this._com_sprites[i].opacity = 255;
            }
            // Math overriding shifted to updateCommandAnimation during Phase 2
        }
        
        this._com_sprites[i].setFrame(0, ch, this._com_pictures[i].width, this._com_pictures[i].height / 2);
        this._com_pictures_data[i] = [this._com_position[i][0], this._com_pictures[i].width, this._com_position[i][1], this._com_pictures[i].height / 2];
    }; 
};
  
Scene_Title.prototype.update_picture_commands = function() {
    this._globalAnimTimer++; 
    let inputActive = false;
    
    if (this._lastTouchX !== TouchInput.x || this._lastTouchY !== TouchInput.y) {
        this._lastTouchX = TouchInput.x;
        this._lastTouchY = TouchInput.y;
        inputActive = true;
    }
    if (TouchInput.isTriggered() || TouchInput.wheelY !== 0 || Input.dir4 !== 0 || 
        Input.isTriggered('ok') || Input.isTriggered('cancel') || 
        Input.isTriggered('pageup') || Input.isTriggered('pagedown')) {
        inputActive = true;
    }
    
    if (inputActive) {
        this._idleFrames = 0;
    } else {
        this._idleFrames++;
    }
    
    if (Moghunter.title_idleTimeout > 0 && this._idleFrames >= Moghunter.title_idleTimeout * 60) {
        this._introPhase = 3;
        this._exitFrames = 0;
        this._commandWindow.deactivate();
        if (this._cursor) this._cursor.visible = false;
        return; 
    }
    
    if (this._com_index_old != this._commandWindow._index) { this.refresh_picture_command()};
    
    // Process Command Idle Animation Overrides
    this.updateCommandAnimation();
    
    if (TouchInput.wheelY !== 0 && !this._csel) {
        var lastIndex = this._commandWindow.index(); 
        
        if (TouchInput.wheelY > 0) {
            this._commandWindow.cursorDown();
        } else {
            this._commandWindow.cursorUp();
        }
        
        if (this._commandWindow.index() !== lastIndex) {
            SoundManager.playCursor(); 
        }
    }

    if (TouchInput.isTriggered()) {
        for (i = 0; i < this._com_sprites.length; i++){
            if (this.on_picture_com(i) && !this._csel ) {				
                this._commandWindow._index = i;	 
                this._commandWindow.processOk();
                if (this._commandWindow.isCommandEnabled(i)) {this._csel = true};
           };		
        };
    };
    
    if (this._cursor) {this.updateCursor()};
    if (this._cursorBg) {this.updateCursorBackground()};
};

Scene_Title.prototype.on_picture_com = function(index) {
     if (TouchInput.x < this._com_pictures_data[index][0]) { return false};
     if (TouchInput.x > this._com_pictures_data[index][0] + this._com_pictures_data[index][1]) { return false};
     if (TouchInput.y < this._com_pictures_data[index][2]) { return false};
     if (TouchInput.y > this._com_pictures_data[index][2] + this._com_pictures_data[index][3]) { return false};
     return true;	 
};

var _mog_titlecom_createForeground = Scene_Title.prototype.createForeground;
Scene_Title.prototype.createForeground = function() {
    _mog_titlecom_createForeground.call(this);
    if (String(Moghunter.title_sprite) === "true") {this.createTitleSprite();}
};

Scene_Title.prototype.createTitleSprite = function() {
    if (this._gameTitleSprite) {this.removeChild(this._gameTitleSprite)};
    this._gameTitleSprite = new Sprite(ImageManager.loadTitle2("Title"));
    this.addChild(this._gameTitleSprite);
    this._gameTitleSprite.x = Moghunter.title_x;
    this._gameTitleSprite.y = Moghunter.title_y;
};