//=============================================================================
// JR_AttachAugments_Compare.js
//=============================================================================
/*:
 * @plugindesc Displays the currently equipped augment for comparison when swapping.
 * @author JR
 *
 * @param Window Title
 * @desc The title shown at the top of the equipped augment window.
 * @default Equipped Crystal:
 *
 * @param Title Text Color
 * @type number
 * @desc The text color code (0-31) used for the window title.
 * @default 16
 *
 * @param Title Font Size
 * @type number
 * @desc The font size used for the window title.
 * @default 28
 *
 * @param Info Font Size
 * @type number
 * @desc The font size used for the augment information text.
 * @default 20
 *
 * @param Header Spacing
 * @type number
 * @desc Spacing (in pixels) between the Title/Name row and the Description.
 * @default 12
 *
 * @param Scroll Delay Start
 * @type number
 * @decimals 1
 * @desc Time (in seconds) to wait before the text begins scrolling.
 * @default 2.0
 *
 * @param Scroll Speed
 * @type number
 * @decimals 1
 * @desc The speed (in pixels per frame) at which the text scrolls.
 * @default 1.0
 *
 * @param Scroll Delay End
 * @type number
 * @decimals 1
 * @desc Time (in seconds) to wait after reaching the bottom before resetting.
 * @default 2.0
 */

(function() {
    var parameters = PluginManager.parameters('JR_AttachAugments_Compare');
    
    // Guard against NaN and Empty Strings resulting in 0
    var parseNum = function(val, def) {
        if (typeof val === 'undefined' || val === null || String(val).trim() === '') return def;
        var n = Number(val);
        return isNaN(n) ? def : n;
    };

    var windowTitle = String(parameters['Window Title'] || 'Equipped Crystal:');
    var titleTextColor = parseNum(parameters['Title Text Color'], 16);
    var titleFontSize = parseNum(parameters['Title Font Size'], 28);
    var infoFontSize = parseNum(parameters['Info Font Size'], 20);
    var headerSpacing = parseNum(parameters['Header Spacing'], 12);
    
    // Convert seconds to frames (60 frames = 1 second)
    var delayStart = Math.floor(parseNum(parameters['Scroll Delay Start'], 2.0) * 60);
    var scrollSpeed = parseNum(parameters['Scroll Speed'], 1.0);
    var delayEnd = Math.floor(parseNum(parameters['Scroll Delay End'], 2.0) * 60);

    //=============================================================================
    // Window_AugmentEquippedInfo
    //=============================================================================
    
    function Window_AugmentEquippedInfo() {
        this.initialize.apply(this, arguments);
    }

    Window_AugmentEquippedInfo.prototype = Object.create(Window_Base.prototype);
    Window_AugmentEquippedInfo.prototype.constructor = Window_AugmentEquippedInfo;

    Window_AugmentEquippedInfo.prototype.initialize = function(x, y, width, height) {
        Window_Base.prototype.initialize.call(this, x, y, width, height);
        this._item = null;
        this._slotId = -1;
        this._scrollMax = 0;
        this._scrollY = 0;
        
        // Dummy bitmap used strictly for measuring text height cleanly
        this._measureBitmap = new Bitmap(this.contentsWidth(), 1); 
    };

    Window_AugmentEquippedInfo.prototype.setItem = function(item, slotId) {
        this._item = item;
        this._slotId = slotId;
        this.refresh();
    };

    Window_AugmentEquippedInfo.prototype.drawTextEx = function(text, x, y) {
        if (text) {
            var textState = { index: 0, x: x, y: y, left: x };
            textState.text = this.convertEscapeCharacters(text);
            textState.height = this.calcTextHeight(textState, false);
            this.resetFontSettings();
            while (textState.index < textState.text.length) {
                this.processCharacter(textState);
            }
            this._lastTextStateY = textState.y + textState.height;
            return textState.x - x;
        } else {
            return 0;
        }
    };

    Window_AugmentEquippedInfo.prototype.refresh = function() {
        this.contents.clear();
        this._scrollMax = 0;
        this._scrollY = 0;

        if (this._descSprite) {
            this._descSprite.visible = false;
            this._descSprite.y = 0;
        }

        if (!this._item || this._slotId < 0) return;

        var augment = ItemManager.augmentInSlot(this._item, this._slotId);

        // 1. Draw Fixed Header (Title + Item Name)
        var fixedText = "<WordWrap>\\c[" + titleTextColor + "]\\fs[" + titleFontSize + "]" + windowTitle + " ";
        
        if (!augment) {
            fixedText += "\\fr\\c[0]- None -";
            this.drawTextEx(fixedText, 0, 0);
            return;
        }

        var itemColor = augment.textColor !== undefined ? augment.textColor : 0;
        if (typeof cellicom !== 'undefined' && augment.meta && augment.meta.rarity !== undefined) {
            var rarity = parseInt(augment.meta.rarity);
            if (rarity < cellicom.rarityColors.length) {
                itemColor = cellicom.rarityColors[rarity];
            }
        }

        fixedText += "\\fr\\c[" + itemColor + "]\\i[" + augment.iconIndex + "]" + augment.name;
        this.drawTextEx(fixedText, 0, 0);
        
        var fixedHeight = this._lastTextStateY; 
        var descStartY = fixedHeight + headerSpacing;

        // 2. Compile Description Text (Fixed Trailing <br> issue)
        var descText = "<WordWrap>\\c[0]\\fs[" + infoFontSize + "]";
        
        var textParts = [];
        if (augment.description) textParts.push(augment.description);
        if (augment.infoTextTop) textParts.push(augment.infoTextTop);
        if (augment.infoTextBottom) textParts.push(augment.infoTextBottom);
        
        if (textParts.length > 0) {
            descText += textParts.join("<br>");
        }

        // 3. Measure Content Height
        var realContents = this.contents;
        this.contents = this._measureBitmap;
        this.drawTextEx(descText, 0, 0);
        var descHeight = this._lastTextStateY;
        this.contents = realContents; // Swap back immediately

        var availableHeight = Math.max(0, this.contentsHeight() - descStartY);
        this._scrollMax = Math.max(0, descHeight - availableHeight);

        // 4. Render (Direct vs Sprite)
        if (this._scrollMax === 0) {
            // FAST PATH: Fits entirely. Draw directly to Window_Base contents. No GPU overhead.
            this.drawTextEx(descText, 0, descStartY);
        } else {
            // SLOW PATH: Needs scrolling. Render to masked sprite.
            if (!this._descSprite) {
                this._descSprite = new Sprite();
                this._windowContentsSprite.addChild(this._descSprite);
            }
            this._descSprite.visible = true;

            // Size bitmap precisely to content to save VRAM
            var neededHeight = Math.ceil(descHeight) + 10;
            if (!this._descSprite.bitmap || this._descSprite.bitmap.height < neededHeight) {
                if (this._descSprite.bitmap) this._descSprite.bitmap.destroy(); 
                this._descSprite.bitmap = new Bitmap(this.contentsWidth(), neededHeight);
            } else {
                this._descSprite.bitmap.clear();
            }

            if (!this._descMask) {
                this._descMask = new PIXI.Graphics();
                this._windowContentsSprite.addChild(this._descMask);
                this._descSprite.mask = this._descMask;
            }
            
            this._descMask.clear();
            this._descMask.beginFill(0xFFFFFF);
            this._descMask.drawRect(0, descStartY, this.contentsWidth(), availableHeight);
            this._descMask.endFill();

            // Guard contents swap with try/finally
            this.contents = this._descSprite.bitmap;
            try {
                this.drawTextEx(descText, 0, 0);
            } finally {
                this.contents = realContents; 
            }

            this._descStartY = descStartY;
            this._descSprite.y = this._descStartY;
            this._scrollState = 'start_delay';
            this._scrollTimer = delayStart;
        }
    };

    Window_AugmentEquippedInfo.prototype.update = function() {
        Window_Base.prototype.update.call(this);
        
        if (this._scrollMax > 0 && this.isOpen() && this.visible) {
            this.updateScrolling();
        }
    };

    Window_AugmentEquippedInfo.prototype.updateScrolling = function() {
        switch(this._scrollState) {
            case 'start_delay':
                if (this._scrollTimer > 0) {
                    this._scrollTimer--;
                } else {
                    this._scrollState = 'scrolling_down'; 
                }
                break;
            case 'scrolling_down':
                this._scrollY += scrollSpeed;
                if (this._scrollY >= this._scrollMax) {
                    this._scrollY = this._scrollMax;
                    this._scrollState = 'end_delay';
                    this._scrollTimer = delayEnd;
                }
                this._descSprite.y = this._descStartY - this._scrollY;
                break;
            case 'end_delay':
                if (this._scrollTimer > 0) {
                    this._scrollTimer--;
                } else {
                    this._scrollState = 'scrolling_up'; 
                }
                break;
            case 'scrolling_up':
                this._scrollY -= scrollSpeed;
                if (this._scrollY <= 0) {
                    this._scrollY = 0;
                    this._scrollState = 'start_delay';
                    this._scrollTimer = delayStart;
                }
                this._descSprite.y = this._descStartY - this._scrollY;
                break;
        }
    };

    //=============================================================================
    // Colorize Augments in Action Command Window (The slot list)
    //=============================================================================
    
    var _Window_ItemActionCommand_getAugmentSlotItemName = Window_ItemActionCommand.prototype.getAugmentSlotItemName;
    Window_ItemActionCommand.prototype.getAugmentSlotItemName = function(slot) {
        var originalText = _Window_ItemActionCommand_getAugmentSlotItemName.call(this, slot);
        var item = ItemManager.augmentInSlot(this._item, slot);
        
        if (item) {
            var itemColor = item.textColor !== undefined ? item.textColor : 0;
            
            if (typeof cellicom !== 'undefined' && item.meta && item.meta.rarity !== undefined) {
                var rarity = parseInt(item.meta.rarity);
                if (rarity < cellicom.rarityColors.length) {
                    itemColor = cellicom.rarityColors[rarity];
                }
            }
            
            if (itemColor > 0) {
                // Surgically inject color tag rather than replacing the whole string
                var searchStr = '\\i[' + item.iconIndex + ']';
                if (originalText.indexOf(searchStr) >= 0) {
                    originalText = originalText.replace(searchStr, searchStr + '\\c[' + itemColor + ']');
                    originalText += '\\c[0]';
                }
            }
        }
        return originalText;
    };

    //=============================================================================
    // Colorize Augments in standard Item Info Window
    //=============================================================================
    
    if (Yanfly.Param.AugmentShow) {
        var _Window_ItemInfo_drawAugmentData = Window_ItemInfo.prototype.drawAugmentData;
        Window_ItemInfo.prototype.drawAugmentData = function(slot, dy) {
            
            var originalDrawTextEx = this.drawTextEx;
            this.drawTextEx = function(text, x, y) {
                var item = ItemManager.augmentInSlot(this._item, slot);
                
                if (item) {
                    var itemColor = item.textColor !== undefined ? item.textColor : 0;
                    
                    if (typeof cellicom !== 'undefined' && item.meta && item.meta.rarity !== undefined) {
                        var rarity = parseInt(item.meta.rarity);
                        if (rarity < cellicom.rarityColors.length) {
                            itemColor = cellicom.rarityColors[rarity];
                        }
                    }
                    
                    if (itemColor > 0) {
                        // Surgically inject color tag
                        var searchStr = '\\i[' + item.iconIndex + ']';
                        if (text.indexOf(searchStr) >= 0) {
                            text = text.replace(searchStr, searchStr + '\\c[' + itemColor + ']');
                            text += '\\c[0]';
                        }
                    }
                }
                
                var result = originalDrawTextEx.call(this, text, x, y);
                this.drawTextEx = originalDrawTextEx; 
                return result;
            };
            
            var aliasResult = _Window_ItemInfo_drawAugmentData.call(this, slot, dy);
            this.drawTextEx = originalDrawTextEx; // Safety fallback
            return aliasResult;
        };
    }

    //=============================================================================
    // Scene_Item Integration
    //=============================================================================
    
    var _Scene_Item_createInfoWindow = Scene_Item.prototype.createInfoWindow;
    Scene_Item.prototype.createInfoWindow = function() {
        _Scene_Item_createInfoWindow.call(this);
        
        var wx = this._infoWindow.x;
        var wy = this._infoWindow.y;
        var ww = this._infoWindow.width;
        var wh = this._infoWindow.height;
        
        this._augmentEquippedInfoWindow = new Window_AugmentEquippedInfo(wx, wy, ww, wh);
        this._augmentEquippedInfoWindow.hide();
        this.addWindow(this._augmentEquippedInfoWindow);
    };

    var _Scene_Item_onActionAugment = Scene_Item.prototype.onActionAugment;
    Scene_Item.prototype.onActionAugment = function() {
        _Scene_Item_onActionAugment.call(this);

        this._infoWindow.hide();

        var slotId = this._itemActionWindow.currentExt();
        this._augmentEquippedInfoWindow.setItem(this.item(), slotId);
        this._augmentEquippedInfoWindow.show();
    };

    var _Scene_Item_onAugmentListCancel = Scene_Item.prototype.onAugmentListCancel;
    Scene_Item.prototype.onAugmentListCancel = function() {
        _Scene_Item_onAugmentListCancel.call(this);

        this._infoWindow.show();
        this._augmentEquippedInfoWindow.hide();
    };

})();