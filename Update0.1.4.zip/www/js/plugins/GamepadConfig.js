(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/GamepadConfig.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: GamepadConfig.js', e);
        }
        throw e;
    }
})();
