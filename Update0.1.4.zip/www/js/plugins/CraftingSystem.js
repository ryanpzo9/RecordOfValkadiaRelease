(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/CraftingSystem.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: CraftingSystem.js', e);
        }
        throw e;
    }
})();
