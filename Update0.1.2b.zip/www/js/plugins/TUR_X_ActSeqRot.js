(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/TUR_X_ActSeqRot.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: TUR_X_ActSeqRot.js', e);
        }
        throw e;
    }
})();
