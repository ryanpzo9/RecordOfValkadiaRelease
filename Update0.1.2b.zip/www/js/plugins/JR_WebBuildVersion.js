(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/JR_WebBuildVersion.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: JR_WebBuildVersion.js', e);
        }
        throw e;
    }
})();
