(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/Navash_EncounterBar.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: Navash_EncounterBar.js', e);
        }
        throw e;
    }
})();
