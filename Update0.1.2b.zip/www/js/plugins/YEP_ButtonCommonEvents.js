(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/YEP_ButtonCommonEvents.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: YEP_ButtonCommonEvents.js', e);
        }
        throw e;
    }
})();
