(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/ARP_MOG_Compat.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: ARP_MOG_Compat.js', e);
        }
        throw e;
    }
})();
