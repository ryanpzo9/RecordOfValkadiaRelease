(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/MenuStatInfoWithParam.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: MenuStatInfoWithParam.js', e);
        }
        throw e;
    }
})();
