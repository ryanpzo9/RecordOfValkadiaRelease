(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/battleObject_forYEP.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: battleObject_forYEP.js', e);
        }
        throw e;
    }
})();
