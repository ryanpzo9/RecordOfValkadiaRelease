(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/YED_SkillShop.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: YED_SkillShop.js', e);
        }
        throw e;
    }
})();
