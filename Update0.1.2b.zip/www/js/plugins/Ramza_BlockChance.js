(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/Ramza_BlockChance.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: Ramza_BlockChance.js', e);
        }
        throw e;
    }
})();
