(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/OrangeLightingEventLight.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: OrangeLightingEventLight.js', e);
        }
        throw e;
    }
})();
