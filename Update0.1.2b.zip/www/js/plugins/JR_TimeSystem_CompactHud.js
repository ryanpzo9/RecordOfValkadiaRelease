(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/JR_TimeSystem_CompactHud.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: JR_TimeSystem_CompactHud.js', e);
        }
        throw e;
    }
})();
