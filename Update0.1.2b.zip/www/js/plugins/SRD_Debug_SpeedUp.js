(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/SRD_Debug_SpeedUp.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: SRD_Debug_SpeedUp.js', e);
        }
        throw e;
    }
})();
