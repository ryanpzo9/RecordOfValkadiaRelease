(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/JR_AutoBattle.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: JR_AutoBattle.js', e);
        }
        throw e;
    }
})();
