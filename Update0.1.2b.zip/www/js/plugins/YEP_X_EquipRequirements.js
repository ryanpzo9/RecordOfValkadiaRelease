(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/YEP_X_EquipRequirements.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: YEP_X_EquipRequirements.js', e);
        }
        throw e;
    }
})();
