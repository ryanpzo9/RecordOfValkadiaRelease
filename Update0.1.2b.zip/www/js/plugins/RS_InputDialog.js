(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/RS_InputDialog.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: RS_InputDialog.js', e);
        }
        throw e;
    }
})();
