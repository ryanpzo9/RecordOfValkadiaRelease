(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/YEP_MainMenuManager.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: YEP_MainMenuManager.js', e);
        }
        throw e;
    }
})();
