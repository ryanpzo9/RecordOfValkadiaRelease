(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/Anima_ExpControl.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: Anima_ExpControl.js', e);
        }
        throw e;
    }
})();
