(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/MrTS_PassiveSkills.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: MrTS_PassiveSkills.js', e);
        }
        throw e;
    }
})();
