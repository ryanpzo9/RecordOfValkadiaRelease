(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/BOB_BattleCommandList.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: BOB_BattleCommandList.js', e);
        }
        throw e;
    }
})();
