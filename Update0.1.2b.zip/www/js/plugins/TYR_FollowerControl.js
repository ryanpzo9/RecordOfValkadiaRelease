(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/TYR_FollowerControl.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: TYR_FollowerControl.js', e);
        }
        throw e;
    }
})();
