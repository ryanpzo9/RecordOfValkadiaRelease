(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/JR_CardBattle.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: JR_CardBattle.js', e);
        }
        throw e;
    }
})();
