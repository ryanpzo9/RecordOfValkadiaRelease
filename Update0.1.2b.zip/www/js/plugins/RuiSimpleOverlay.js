(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/RuiSimpleOverlay.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: RuiSimpleOverlay.js', e);
        }
        throw e;
    }
})();
