(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/TerraxLighting.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: TerraxLighting.js', e);
        }
        throw e;
    }
})();
