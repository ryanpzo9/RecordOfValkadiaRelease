(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/JR_AnalyzeDisplayHp.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: JR_AnalyzeDisplayHp.js', e);
        }
        throw e;
    }
})();
