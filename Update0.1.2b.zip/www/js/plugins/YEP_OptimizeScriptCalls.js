(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/YEP_OptimizeScriptCalls.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: YEP_OptimizeScriptCalls.js', e);
        }
        throw e;
    }
})();
