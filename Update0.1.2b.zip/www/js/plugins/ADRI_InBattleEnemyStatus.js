(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/ADRI_InBattleEnemyStatus.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: ADRI_InBattleEnemyStatus.js', e);
        }
        throw e;
    }
})();
