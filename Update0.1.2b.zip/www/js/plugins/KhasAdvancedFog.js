(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/KhasAdvancedFog.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: KhasAdvancedFog.js', e);
        }
        throw e;
    }
})();
