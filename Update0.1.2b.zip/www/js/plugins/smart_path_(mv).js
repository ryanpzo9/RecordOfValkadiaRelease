(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/smart_path_(mv).bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: smart_path_(mv).js', e);
        }
        throw e;
    }
})();
