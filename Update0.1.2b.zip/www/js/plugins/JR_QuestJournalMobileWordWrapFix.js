(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/JR_QuestJournalMobileWordWrapFix.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: JR_QuestJournalMobileWordWrapFix.js', e);
        }
        throw e;
    }
})();
