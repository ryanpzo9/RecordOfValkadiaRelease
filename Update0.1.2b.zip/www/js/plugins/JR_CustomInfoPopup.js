(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/JR_CustomInfoPopup.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: JR_CustomInfoPopup.js', e);
        }
        throw e;
    }
})();
