(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/VE_BasicModule.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: VE_BasicModule.js', e);
        }
        throw e;
    }
})();
