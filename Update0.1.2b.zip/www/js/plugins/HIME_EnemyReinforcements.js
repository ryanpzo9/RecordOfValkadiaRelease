(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/HIME_EnemyReinforcements.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: HIME_EnemyReinforcements.js', e);
        }
        throw e;
    }
})();
