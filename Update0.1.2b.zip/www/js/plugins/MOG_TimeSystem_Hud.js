(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/MOG_TimeSystem_Hud.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: MOG_TimeSystem_Hud.js', e);
        }
        throw e;
    }
})();
