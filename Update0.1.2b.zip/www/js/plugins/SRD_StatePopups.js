(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/SRD_StatePopups.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: SRD_StatePopups.js', e);
        }
        throw e;
    }
})();
