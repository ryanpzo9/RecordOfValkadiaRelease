(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/JR_AndroidBackButton.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: JR_AndroidBackButton.js', e);
        }
        throw e;
    }
})();
