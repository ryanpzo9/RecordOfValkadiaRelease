(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/changegraphic.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: changegraphic.js', e);
        }
        throw e;
    }
})();
