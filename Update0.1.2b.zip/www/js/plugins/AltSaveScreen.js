(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/AltSaveScreen.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: AltSaveScreen.js', e);
        }
        throw e;
    }
})();
