(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/SRD_CameraCore.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: SRD_CameraCore.js', e);
        }
        throw e;
    }
})();
