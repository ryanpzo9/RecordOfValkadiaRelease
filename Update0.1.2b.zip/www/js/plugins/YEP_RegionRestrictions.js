(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/YEP_RegionRestrictions.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: YEP_RegionRestrictions.js', e);
        }
        throw e;
    }
})();
