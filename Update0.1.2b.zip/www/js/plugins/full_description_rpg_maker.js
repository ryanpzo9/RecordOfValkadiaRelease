(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/full_description_rpg_maker.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: full_description_rpg_maker.js', e);
        }
        throw e;
    }
})();
