(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/YEP_BattleBgmControl.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: YEP_BattleBgmControl.js', e);
        }
        throw e;
    }
})();
