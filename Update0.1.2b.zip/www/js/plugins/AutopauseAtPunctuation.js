(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/AutopauseAtPunctuation.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: AutopauseAtPunctuation.js', e);
        }
        throw e;
    }
})();
