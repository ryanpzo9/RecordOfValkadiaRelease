(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/Chau_SceneStabilizer (5.5.0).bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: Chau_SceneStabilizer (5.5.0).js', e);
        }
        throw e;
    }
})();
