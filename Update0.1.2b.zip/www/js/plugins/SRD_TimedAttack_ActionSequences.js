(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/SRD_TimedAttack_ActionSequences.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: SRD_TimedAttack_ActionSequences.js', e);
        }
        throw e;
    }
})();
