(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/Cae_TimeStopBattlers.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: Cae_TimeStopBattlers.js', e);
        }
        throw e;
    }
})();
