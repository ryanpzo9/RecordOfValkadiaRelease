(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/RandomBattleBGM.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: RandomBattleBGM.js', e);
        }
        throw e;
    }
})();
