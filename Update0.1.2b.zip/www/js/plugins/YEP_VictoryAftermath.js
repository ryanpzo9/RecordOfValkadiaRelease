(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/YEP_VictoryAftermath.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: YEP_VictoryAftermath.js', e);
        }
        throw e;
    }
})();
