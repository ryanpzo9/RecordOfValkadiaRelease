(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/WeaponSkill.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: WeaponSkill.js', e);
        }
        throw e;
    }
})();
