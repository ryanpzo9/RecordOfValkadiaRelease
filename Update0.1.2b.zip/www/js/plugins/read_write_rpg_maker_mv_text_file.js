(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/read_write_rpg_maker_mv_text_file.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: read_write_rpg_maker_mv_text_file.js', e);
        }
        throw e;
    }
})();
