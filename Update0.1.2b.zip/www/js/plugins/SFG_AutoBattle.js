(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/SFG_AutoBattle.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: SFG_AutoBattle.js', e);
        }
        throw e;
    }
})();
