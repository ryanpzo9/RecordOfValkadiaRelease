(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/Ten_characterOverlay.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: Ten_characterOverlay.js', e);
        }
        throw e;
    }
})();
