(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/MSX_InventoryCategories.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: MSX_InventoryCategories.js', e);
        }
        throw e;
    }
})();
