(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/AP_Blocking.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: AP_Blocking.js', e);
        }
        throw e;
    }
})();
