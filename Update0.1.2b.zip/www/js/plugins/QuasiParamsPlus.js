(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/QuasiParamsPlus.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: QuasiParamsPlus.js', e);
        }
        throw e;
    }
})();
