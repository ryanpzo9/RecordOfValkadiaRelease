(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/JR_QuestTracker.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: JR_QuestTracker.js', e);
        }
        throw e;
    }
})();
