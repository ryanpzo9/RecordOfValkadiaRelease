(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/YEP_ExtraEnemyDrops_X_Quantities.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: YEP_ExtraEnemyDrops_X_Quantities.js', e);
        }
        throw e;
    }
})();
