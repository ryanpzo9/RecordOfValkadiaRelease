(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/Olivia_BreakShieldSystem.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: Olivia_BreakShieldSystem.js', e);
        }
        throw e;
    }
})();
