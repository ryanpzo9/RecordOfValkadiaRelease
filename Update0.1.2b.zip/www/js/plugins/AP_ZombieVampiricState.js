(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/AP_ZombieVampiricState.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: AP_ZombieVampiricState.js', e);
        }
        throw e;
    }
})();
