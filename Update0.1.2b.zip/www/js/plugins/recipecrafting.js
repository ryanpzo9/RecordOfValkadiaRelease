(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/recipecrafting.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: recipecrafting.js', e);
        }
        throw e;
    }
})();
