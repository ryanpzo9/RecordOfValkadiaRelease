(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/MPP_SimpleTouch3.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: MPP_SimpleTouch3.js', e);
        }
        throw e;
    }
})();
