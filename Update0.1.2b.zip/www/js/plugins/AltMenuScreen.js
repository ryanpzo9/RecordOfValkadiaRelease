(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/AltMenuScreen.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: AltMenuScreen.js', e);
        }
        throw e;
    }
})();
