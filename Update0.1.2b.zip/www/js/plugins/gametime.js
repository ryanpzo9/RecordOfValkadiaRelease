(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/gametime.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: gametime.js', e);
        }
        throw e;
    }
})();
