(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/HIME_EnemyClasses.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: HIME_EnemyClasses.js', e);
        }
        throw e;
    }
})();
