(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/iavra_event_popup.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: iavra_event_popup.js', e);
        }
        throw e;
    }
})();
