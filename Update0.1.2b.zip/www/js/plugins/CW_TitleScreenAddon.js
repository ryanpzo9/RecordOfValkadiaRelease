(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/CW_TitleScreenAddon.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: CW_TitleScreenAddon.js', e);
        }
        throw e;
    }
})();
