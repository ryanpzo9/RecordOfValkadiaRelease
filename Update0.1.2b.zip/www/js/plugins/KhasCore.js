(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/KhasCore.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: KhasCore.js', e);
        }
        throw e;
    }
})();
