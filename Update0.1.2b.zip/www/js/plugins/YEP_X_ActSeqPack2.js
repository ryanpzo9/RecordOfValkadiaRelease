(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/YEP_X_ActSeqPack2.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: YEP_X_ActSeqPack2.js', e);
        }
        throw e;
    }
})();
