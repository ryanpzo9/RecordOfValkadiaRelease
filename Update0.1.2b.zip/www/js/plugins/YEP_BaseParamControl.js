(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/YEP_BaseParamControl.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: YEP_BaseParamControl.js', e);
        }
        throw e;
    }
})();
