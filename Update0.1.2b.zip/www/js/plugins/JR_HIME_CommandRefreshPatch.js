(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/JR_HIME_CommandRefreshPatch.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: JR_HIME_CommandRefreshPatch.js', e);
        }
        throw e;
    }
})();
