(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/BO_SortingOptions.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: BO_SortingOptions.js', e);
        }
        throw e;
    }
})();
