(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/Nina_AutoTargetSkills.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: Nina_AutoTargetSkills.js', e);
        }
        throw e;
    }
})();
