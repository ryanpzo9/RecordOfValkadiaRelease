(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/YEP_EventMorpher.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: YEP_EventMorpher.js', e);
        }
        throw e;
    }
})();
