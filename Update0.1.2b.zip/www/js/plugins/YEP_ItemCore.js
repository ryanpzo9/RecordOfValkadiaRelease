(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/YEP_ItemCore.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: YEP_ItemCore.js', e);
        }
        throw e;
    }
})();
