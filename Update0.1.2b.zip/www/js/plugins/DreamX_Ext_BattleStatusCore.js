(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/DreamX_Ext_BattleStatusCore.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: DreamX_Ext_BattleStatusCore.js', e);
        }
        throw e;
    }
})();
