(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/JR_SameCategoryPriority.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: JR_SameCategoryPriority.js', e);
        }
        throw e;
    }
})();
