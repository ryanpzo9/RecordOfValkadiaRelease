(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/OrangeSteamCloud.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: OrangeSteamCloud.js', e);
        }
        throw e;
    }
})();
