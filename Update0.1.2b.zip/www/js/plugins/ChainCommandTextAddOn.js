(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/ChainCommandTextAddOn.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: ChainCommandTextAddOn.js', e);
        }
        throw e;
    }
})();
