(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/SRD_SuperToolsEngine.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: SRD_SuperToolsEngine.js', e);
        }
        throw e;
    }
})();
