(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/KhasAdvancedLighting.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: KhasAdvancedLighting.js', e);
        }
        throw e;
    }
})();
