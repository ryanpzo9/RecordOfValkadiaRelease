(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/KODERA_optimization.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: KODERA_optimization.js', e);
        }
        throw e;
    }
})();
