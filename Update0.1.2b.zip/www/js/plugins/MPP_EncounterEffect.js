(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/MPP_EncounterEffect.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: MPP_EncounterEffect.js', e);
        }
        throw e;
    }
})();
