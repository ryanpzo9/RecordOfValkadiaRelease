(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/SOUL_CustomVariables.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: SOUL_CustomVariables.js', e);
        }
        throw e;
    }
})();
