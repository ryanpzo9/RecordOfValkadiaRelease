(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/MOG_Weather_EX.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: MOG_Weather_EX.js', e);
        }
        throw e;
    }
})();
