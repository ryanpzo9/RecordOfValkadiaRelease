(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/OrangeLighting.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: OrangeLighting.js', e);
        }
        throw e;
    }
})();
