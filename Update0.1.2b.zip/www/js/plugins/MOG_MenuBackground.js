(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/MOG_MenuBackground.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: MOG_MenuBackground.js', e);
        }
        throw e;
    }
})();
