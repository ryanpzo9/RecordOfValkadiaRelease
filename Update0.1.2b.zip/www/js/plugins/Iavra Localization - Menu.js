(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/Iavra Localization - Menu.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: Iavra Localization - Menu.js', e);
        }
        throw e;
    }
})();
