(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/SRD_PluginComEvals.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: SRD_PluginComEvals.js', e);
        }
        throw e;
    }
})();
