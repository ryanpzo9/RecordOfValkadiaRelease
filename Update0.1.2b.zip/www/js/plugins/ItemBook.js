(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/ItemBook.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: ItemBook.js', e);
        }
        throw e;
    }
})();
