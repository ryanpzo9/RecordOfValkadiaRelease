(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/Iavra Localization - Core.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: Iavra Localization - Core.js', e);
        }
        throw e;
    }
})();
