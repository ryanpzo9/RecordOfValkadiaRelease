(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/KhasGraphics.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: KhasGraphics.js', e);
        }
        throw e;
    }
})();
