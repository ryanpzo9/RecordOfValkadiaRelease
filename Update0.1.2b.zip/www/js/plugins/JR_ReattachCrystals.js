(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/JR_ReattachCrystals.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: JR_ReattachCrystals.js', e);
        }
        throw e;
    }
})();
