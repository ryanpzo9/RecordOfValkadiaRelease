(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/JR_RecipeCrafting_YEPWordWrapFix.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: JR_RecipeCrafting_YEPWordWrapFix.js', e);
        }
        throw e;
    }
})();
