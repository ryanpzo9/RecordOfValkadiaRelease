(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/JR_CTBTickSpeed.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: JR_CTBTickSpeed.js', e);
        }
        throw e;
    }
})();
