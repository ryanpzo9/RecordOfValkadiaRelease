(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/Jeremy Cannady_NewMenuExp.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: Jeremy Cannady_NewMenuExp.js', e);
        }
        throw e;
    }
})();
