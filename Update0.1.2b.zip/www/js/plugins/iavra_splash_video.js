(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/iavra_splash_video.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: iavra_splash_video.js', e);
        }
        throw e;
    }
})();
