(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/YEP_JobPoints.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: YEP_JobPoints.js', e);
        }
        throw e;
    }
})();
