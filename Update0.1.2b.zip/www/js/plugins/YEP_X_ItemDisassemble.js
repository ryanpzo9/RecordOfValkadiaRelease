(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/YEP_X_ItemDisassemble.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: YEP_X_ItemDisassemble.js', e);
        }
        throw e;
    }
})();
