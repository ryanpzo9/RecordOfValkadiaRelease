(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/MOG_SHud.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: MOG_SHud.js', e);
        }
        throw e;
    }
})();
