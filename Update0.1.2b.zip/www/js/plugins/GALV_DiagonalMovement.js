(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/GALV_DiagonalMovement.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: GALV_DiagonalMovement.js', e);
        }
        throw e;
    }
})();
