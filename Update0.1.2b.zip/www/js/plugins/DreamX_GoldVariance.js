(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/DreamX_GoldVariance.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: DreamX_GoldVariance.js', e);
        }
        throw e;
    }
})();
