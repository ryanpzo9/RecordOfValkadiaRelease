(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/HPColor.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: HPColor.js', e);
        }
        throw e;
    }
})();
