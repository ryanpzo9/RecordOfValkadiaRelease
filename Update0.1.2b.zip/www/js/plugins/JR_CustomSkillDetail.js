(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/JR_CustomSkillDetail.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: JR_CustomSkillDetail.js', e);
        }
        throw e;
    }
})();
