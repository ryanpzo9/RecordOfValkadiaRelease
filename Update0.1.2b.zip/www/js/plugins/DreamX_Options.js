(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/DreamX_Options.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: DreamX_Options.js', e);
        }
        throw e;
    }
})();
