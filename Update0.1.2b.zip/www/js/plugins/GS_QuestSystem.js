(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/GS_QuestSystem.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: GS_QuestSystem.js', e);
        }
        throw e;
    }
})();
