(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/MOG_TitleParticles.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: MOG_TitleParticles.js', e);
        }
        throw e;
    }
})();
