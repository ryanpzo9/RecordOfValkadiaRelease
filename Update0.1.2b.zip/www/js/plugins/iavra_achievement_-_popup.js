(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/iavra_achievement_-_popup.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: iavra_achievement_-_popup.js', e);
        }
        throw e;
    }
})();
