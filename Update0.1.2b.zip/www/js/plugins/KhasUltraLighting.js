(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/KhasUltraLighting.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: KhasUltraLighting.js', e);
        }
        throw e;
    }
})();
