(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/ChainCommand_SwipeInputAddon.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: ChainCommand_SwipeInputAddon.js', e);
        }
        throw e;
    }
})();
