(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/BattlerGraphicExtend.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: BattlerGraphicExtend.js', e);
        }
        throw e;
    }
})();
