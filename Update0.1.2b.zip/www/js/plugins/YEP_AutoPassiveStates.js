(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/YEP_AutoPassiveStates.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: YEP_AutoPassiveStates.js', e);
        }
        throw e;
    }
})();
