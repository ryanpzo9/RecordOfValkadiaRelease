(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/AutoUpdater.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: AutoUpdater.js', e);
        }
        throw e;
    }
})();
