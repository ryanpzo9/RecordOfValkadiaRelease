(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/ARP_InGameManual.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: ARP_InGameManual.js', e);
        }
        throw e;
    }
})();
