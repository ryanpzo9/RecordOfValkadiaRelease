(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/FROG_TriggerDistance.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: FROG_TriggerDistance.js', e);
        }
        throw e;
    }
})();
