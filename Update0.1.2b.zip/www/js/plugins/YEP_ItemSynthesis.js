(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/YEP_ItemSynthesis.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: YEP_ItemSynthesis.js', e);
        }
        throw e;
    }
})();
