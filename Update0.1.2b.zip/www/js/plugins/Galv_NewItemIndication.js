(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/Galv_NewItemIndication.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: Galv_NewItemIndication.js', e);
        }
        throw e;
    }
})();
