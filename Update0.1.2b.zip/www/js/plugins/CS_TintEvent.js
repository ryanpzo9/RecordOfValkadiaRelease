(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/CS_TintEvent.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: CS_TintEvent.js', e);
        }
        throw e;
    }
})();
