(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/HIME_ActorBattleCommands.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: HIME_ActorBattleCommands.js', e);
        }
        throw e;
    }
})();
