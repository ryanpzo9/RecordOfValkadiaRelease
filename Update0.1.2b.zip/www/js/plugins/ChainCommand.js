(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/ChainCommand.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: ChainCommand.js', e);
        }
        throw e;
    }
})();
