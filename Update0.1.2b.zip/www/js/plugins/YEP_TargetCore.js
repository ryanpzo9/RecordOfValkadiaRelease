(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/YEP_TargetCore.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: YEP_TargetCore.js', e);
        }
        throw e;
    }
})();
