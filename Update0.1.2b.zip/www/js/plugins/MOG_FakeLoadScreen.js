(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/MOG_FakeLoadScreen.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: MOG_FakeLoadScreen.js', e);
        }
        throw e;
    }
})();
