(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/YEP_Taunt.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: YEP_Taunt.js', e);
        }
        throw e;
    }
})();
