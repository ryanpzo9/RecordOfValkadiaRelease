(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/HIME_BattleCommandUseSkill.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: HIME_BattleCommandUseSkill.js', e);
        }
        throw e;
    }
})();
