(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/JR_BarrierDisplay_DreamX.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: JR_BarrierDisplay_DreamX.js', e);
        }
        throw e;
    }
})();
