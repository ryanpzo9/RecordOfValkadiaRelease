(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/questsystem.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: questsystem.js', e);
        }
        throw e;
    }
})();
