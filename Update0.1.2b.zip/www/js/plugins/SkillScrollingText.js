(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/SkillScrollingText.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: SkillScrollingText.js', e);
        }
        throw e;
    }
})();
