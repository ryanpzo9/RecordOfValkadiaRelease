(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/MPP_VanishState.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: MPP_VanishState.js', e);
        }
        throw e;
    }
})();
