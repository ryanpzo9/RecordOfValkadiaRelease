(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/MAC_High_Hz_Fixes.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: MAC_High_Hz_Fixes.js', e);
        }
        throw e;
    }
})();
