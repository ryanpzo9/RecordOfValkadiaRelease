(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/TitleCommandPosition.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: TitleCommandPosition.js', e);
        }
        throw e;
    }
})();
