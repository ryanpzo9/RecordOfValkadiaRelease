(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/SilvUndead.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: SilvUndead.js', e);
        }
        throw e;
    }
})();
