(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/YEP_EventSpawner.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: YEP_EventSpawner.js', e);
        }
        throw e;
    }
})();
