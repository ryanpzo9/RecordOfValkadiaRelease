(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/heal_when_level_up.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: heal_when_level_up.js', e);
        }
        throw e;
    }
})();
