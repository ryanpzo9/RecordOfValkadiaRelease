(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/DEX_YEP_ItemDiscard.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: DEX_YEP_ItemDiscard.js', e);
        }
        throw e;
    }
})();
