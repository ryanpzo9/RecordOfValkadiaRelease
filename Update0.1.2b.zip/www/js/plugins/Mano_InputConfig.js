(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/Mano_InputConfig.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: Mano_InputConfig.js', e);
        }
        throw e;
    }
})();
