(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/SRD_TimedAttack_Arrows.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: SRD_TimedAttack_Arrows.js', e);
        }
        throw e;
    }
})();
