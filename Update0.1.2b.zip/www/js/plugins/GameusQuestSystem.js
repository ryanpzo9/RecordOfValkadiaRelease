(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/GameusQuestSystem.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: GameusQuestSystem.js', e);
        }
        throw e;
    }
})();
