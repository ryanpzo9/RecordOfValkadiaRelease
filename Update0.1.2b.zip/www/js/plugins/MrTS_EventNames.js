(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/MrTS_EventNames.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: MrTS_EventNames.js', e);
        }
        throw e;
    }
})();
