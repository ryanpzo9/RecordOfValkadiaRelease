(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/SkillExpendedPlugin.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: SkillExpendedPlugin.js', e);
        }
        throw e;
    }
})();
