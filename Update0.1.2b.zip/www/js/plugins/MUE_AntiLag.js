(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/MUE_AntiLag.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: MUE_AntiLag.js', e);
        }
        throw e;
    }
})();
