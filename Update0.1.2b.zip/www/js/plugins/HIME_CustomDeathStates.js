(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/HIME_CustomDeathStates.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: HIME_CustomDeathStates.js', e);
        }
        throw e;
    }
})();
