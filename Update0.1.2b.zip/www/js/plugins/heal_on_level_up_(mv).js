(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/heal_on_level_up_(mv).bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: heal_on_level_up_(mv).js', e);
        }
        throw e;
    }
})();
