(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/MOG_TitleLayers.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: MOG_TitleLayers.js', e);
        }
        throw e;
    }
})();
