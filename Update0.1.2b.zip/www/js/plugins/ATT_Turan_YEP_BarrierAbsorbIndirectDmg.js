(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/ATT_Turan_YEP_BarrierAbsorbIndirectDmg.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: ATT_Turan_YEP_BarrierAbsorbIndirectDmg.js', e);
        }
        throw e;
    }
})();
