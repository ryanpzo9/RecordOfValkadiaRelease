(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/HIME_GuestFollowers.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: HIME_GuestFollowers.js', e);
        }
        throw e;
    }
})();
