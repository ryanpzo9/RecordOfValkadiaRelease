(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/ozu_File.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: ozu_File.js', e);
        }
        throw e;
    }
})();
