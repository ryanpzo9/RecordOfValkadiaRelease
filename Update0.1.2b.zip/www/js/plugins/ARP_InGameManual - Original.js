(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/ARP_InGameManual - Original.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: ARP_InGameManual - Original.js', e);
        }
        throw e;
    }
})();
