(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/TDDP_PreloadManager.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: TDDP_PreloadManager.js', e);
        }
        throw e;
    }
})();
