(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/JR_Bestiary_AnalyzeExtension.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: JR_Bestiary_AnalyzeExtension.js', e);
        }
        throw e;
    }
})();
