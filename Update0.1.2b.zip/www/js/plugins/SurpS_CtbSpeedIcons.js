(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/SurpS_CtbSpeedIcons.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: SurpS_CtbSpeedIcons.js', e);
        }
        throw e;
    }
})();
