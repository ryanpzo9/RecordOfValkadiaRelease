(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/JR_Universal_Failsafe.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: JR_Universal_Failsafe.js', e);
        }
        throw e;
    }
})();
