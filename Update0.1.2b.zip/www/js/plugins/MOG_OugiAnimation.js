(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/MOG_OugiAnimation.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: MOG_OugiAnimation.js', e);
        }
        throw e;
    }
})();
