(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/MOG_BattleHud.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: MOG_BattleHud.js', e);
        }
        throw e;
    }
})();
