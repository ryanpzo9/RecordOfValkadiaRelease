(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/SOUL_ThomasEdisonMV.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: SOUL_ThomasEdisonMV.js', e);
        }
        throw e;
    }
})();
