(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/ASFrameLock.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: ASFrameLock.js', e);
        }
        throw e;
    }
})();
