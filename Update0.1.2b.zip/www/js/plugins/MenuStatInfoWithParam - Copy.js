(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/MenuStatInfoWithParam - Copy.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: MenuStatInfoWithParam - Copy.js', e);
        }
        throw e;
    }
})();
