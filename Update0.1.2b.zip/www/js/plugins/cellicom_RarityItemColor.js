(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/cellicom_RarityItemColor.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: cellicom_RarityItemColor.js', e);
        }
        throw e;
    }
})();
