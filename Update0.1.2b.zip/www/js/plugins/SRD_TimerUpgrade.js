(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/SRD_TimerUpgrade.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: SRD_TimerUpgrade.js', e);
        }
        throw e;
    }
})();
