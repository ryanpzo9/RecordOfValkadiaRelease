(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/MadeWithMv.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: MadeWithMv.js', e);
        }
        throw e;
    }
})();
