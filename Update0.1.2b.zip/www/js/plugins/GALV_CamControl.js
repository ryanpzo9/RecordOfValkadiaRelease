(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/GALV_CamControl.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: GALV_CamControl.js', e);
        }
        throw e;
    }
})();
