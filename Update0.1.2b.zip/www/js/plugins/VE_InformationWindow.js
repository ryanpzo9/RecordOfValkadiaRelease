(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/VE_InformationWindow.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: VE_InformationWindow.js', e);
        }
        throw e;
    }
})();
