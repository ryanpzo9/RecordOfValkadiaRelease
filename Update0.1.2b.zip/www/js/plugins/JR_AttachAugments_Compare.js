(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/JR_AttachAugments_Compare.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: JR_AttachAugments_Compare.js', e);
        }
        throw e;
    }
})();
