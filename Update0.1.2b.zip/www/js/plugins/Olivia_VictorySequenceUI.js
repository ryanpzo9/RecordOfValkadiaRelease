(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/Olivia_VictorySequenceUI.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: Olivia_VictorySequenceUI.js', e);
        }
        throw e;
    }
})();
