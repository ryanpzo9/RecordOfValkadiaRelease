(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/GALV_LayerGraphics.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: GALV_LayerGraphics.js', e);
        }
        throw e;
    }
})();
