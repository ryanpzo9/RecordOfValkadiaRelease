(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/SRD_MasterVolume.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: SRD_MasterVolume.js', e);
        }
        throw e;
    }
})();
