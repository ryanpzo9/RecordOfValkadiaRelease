(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/YEP_WeaponAnimation.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: YEP_WeaponAnimation.js', e);
        }
        throw e;
    }
})();
