(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/Olivia_WeaknessDisplay.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: Olivia_WeaknessDisplay.js', e);
        }
        throw e;
    }
})();
