(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/SSG_DifficultySetting.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: SSG_DifficultySetting.js', e);
        }
        throw e;
    }
})();
