(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/YEP_SkillLearnSystem.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: YEP_SkillLearnSystem.js', e);
        }
        throw e;
    }
})();
