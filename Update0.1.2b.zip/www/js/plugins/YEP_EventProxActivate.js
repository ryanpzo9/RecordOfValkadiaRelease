(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/YEP_EventProxActivate.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: YEP_EventProxActivate.js', e);
        }
        throw e;
    }
})();
