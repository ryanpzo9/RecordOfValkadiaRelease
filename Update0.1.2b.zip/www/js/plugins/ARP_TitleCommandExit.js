(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/ARP_TitleCommandExit.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: ARP_TitleCommandExit.js', e);
        }
        throw e;
    }
})();
