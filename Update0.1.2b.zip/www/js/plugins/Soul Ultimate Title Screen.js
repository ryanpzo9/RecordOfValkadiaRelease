(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/Soul Ultimate Title Screen.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: Soul Ultimate Title Screen.js', e);
        }
        throw e;
    }
})();
