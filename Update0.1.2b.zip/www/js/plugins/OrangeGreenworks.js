(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/OrangeGreenworks.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: OrangeGreenworks.js', e);
        }
        throw e;
    }
})();
