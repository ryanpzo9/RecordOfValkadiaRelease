(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/Olivia_Hime_Patch.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: Olivia_Hime_Patch.js', e);
        }
        throw e;
    }
})();
