(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/ALOE_VirtualButtons.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: ALOE_VirtualButtons.js', e);
        }
        throw e;
    }
})();
