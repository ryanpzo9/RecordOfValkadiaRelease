(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/NeMV_Tags.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: NeMV_Tags.js', e);
        }
        throw e;
    }
})();
