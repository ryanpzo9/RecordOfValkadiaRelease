(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/MOG_CursorBorder.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: MOG_CursorBorder.js', e);
        }
        throw e;
    }
})();
