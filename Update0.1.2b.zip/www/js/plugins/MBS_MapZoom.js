(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/MBS_MapZoom.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: MBS_MapZoom.js', e);
        }
        throw e;
    }
})();
