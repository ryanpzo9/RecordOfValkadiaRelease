(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/Chau_SceneStabilizer (3.0.2).bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: Chau_SceneStabilizer (3.0.2).js', e);
        }
        throw e;
    }
})();
