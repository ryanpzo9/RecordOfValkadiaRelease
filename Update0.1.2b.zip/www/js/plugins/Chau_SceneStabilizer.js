(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/Chau_SceneStabilizer.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: Chau_SceneStabilizer.js', e);
        }
        throw e;
    }
})();
