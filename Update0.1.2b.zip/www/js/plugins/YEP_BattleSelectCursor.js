(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/YEP_BattleSelectCursor.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: YEP_BattleSelectCursor.js', e);
        }
        throw e;
    }
})();
