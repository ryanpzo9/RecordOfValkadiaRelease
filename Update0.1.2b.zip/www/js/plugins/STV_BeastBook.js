(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/STV_BeastBook.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: STV_BeastBook.js', e);
        }
        throw e;
    }
})();
