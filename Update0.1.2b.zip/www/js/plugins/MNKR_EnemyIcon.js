(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/MNKR_EnemyIcon.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: MNKR_EnemyIcon.js', e);
        }
        throw e;
    }
})();
