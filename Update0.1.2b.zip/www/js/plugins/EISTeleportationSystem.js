(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/EISTeleportationSystem.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: EISTeleportationSystem.js', e);
        }
        throw e;
    }
})();
