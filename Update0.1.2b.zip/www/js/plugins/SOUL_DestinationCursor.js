(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/SOUL_DestinationCursor.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: SOUL_DestinationCursor.js', e);
        }
        throw e;
    }
})();
