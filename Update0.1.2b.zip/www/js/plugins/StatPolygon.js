(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/StatPolygon.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: StatPolygon.js', e);
        }
        throw e;
    }
})();
