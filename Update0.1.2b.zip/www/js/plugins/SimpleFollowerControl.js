(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/SimpleFollowerControl.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: SimpleFollowerControl.js', e);
        }
        throw e;
    }
})();
