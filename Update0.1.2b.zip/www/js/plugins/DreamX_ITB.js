(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/DreamX_ITB.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: DreamX_ITB.js', e);
        }
        throw e;
    }
})();
