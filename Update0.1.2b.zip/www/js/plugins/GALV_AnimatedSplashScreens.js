(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/GALV_AnimatedSplashScreens.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: GALV_AnimatedSplashScreens.js', e);
        }
        throw e;
    }
})();
