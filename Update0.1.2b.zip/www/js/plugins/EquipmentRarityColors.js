(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/EquipmentRarityColors.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: EquipmentRarityColors.js', e);
        }
        throw e;
    }
})();
