(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/JR_SkillLearnLayout.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: JR_SkillLearnLayout.js', e);
        }
        throw e;
    }
})();
