(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/Kaus_Ultimate_Overlay.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: Kaus_Ultimate_Overlay.js', e);
        }
        throw e;
    }
})();
