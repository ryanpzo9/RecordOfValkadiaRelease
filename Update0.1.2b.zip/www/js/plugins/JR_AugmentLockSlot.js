(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/JR_AugmentLockSlot.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: JR_AugmentLockSlot.js', e);
        }
        throw e;
    }
})();
