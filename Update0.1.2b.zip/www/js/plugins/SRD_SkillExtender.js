(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/SRD_SkillExtender.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: SRD_SkillExtender.js', e);
        }
        throw e;
    }
})();
