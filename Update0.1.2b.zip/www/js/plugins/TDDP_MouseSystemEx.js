(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/TDDP_MouseSystemEx.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: TDDP_MouseSystemEx.js', e);
        }
        throw e;
    }
})();
