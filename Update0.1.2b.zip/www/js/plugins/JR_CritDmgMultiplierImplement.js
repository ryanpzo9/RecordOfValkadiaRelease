(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/JR_CritDmgMultiplierImplement.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: JR_CritDmgMultiplierImplement.js', e);
        }
        throw e;
    }
})();
