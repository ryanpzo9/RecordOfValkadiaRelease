(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/ExportMessagesToText.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: ExportMessagesToText.js', e);
        }
        throw e;
    }
})();
