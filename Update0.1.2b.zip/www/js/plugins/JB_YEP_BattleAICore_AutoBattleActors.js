(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/JB_YEP_BattleAICore_AutoBattleActors.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: JB_YEP_BattleAICore_AutoBattleActors.js', e);
        }
        throw e;
    }
})();
