(function() {
    try {
        nw.Window.get().evalNWBin(null, "www/js/plugins/YEP_SkillCore.bin");
    } catch (e) {
        if (typeof console !== 'undefined' && console.error) {
            console.error('JR protected plugin load failed: YEP_SkillCore.js', e);
        }
        throw e;
    }
})();
