//=============================================================================
// JR_QuestTracker.js
//=============================================================================

var Imported = Imported || {};
Imported.JR_QuestTracker = true;

var JR = JR || {};
JR.Tracker = JR.Tracker || {};
JR.Tracker.version = 1.07;

/*:
 * @plugindesc v1.07 Adds a Quest Tracker window and tracking functionality for YEP_QuestJournal.
 * @author JR
 *
 * @param ---Track Settings---
 * @default
 *
 * @param Track Quest Text
 * @parent ---Track Settings---
 * @desc Text for the Track Quest option.
 * @default Track Quest
 *
 * @param Tracked Icon
 * @parent ---Track Settings---
 * @type number
 * @desc Icon to show when the quest is tracked.
 * @default 165
 *
 * @param Untracked Icon
 * @parent ---Track Settings---
 * @type number
 * @desc Icon to show when the quest is untracked.
 * @default 160
 *
 * @param Tracked Quest Color
 * @parent ---Track Settings---
 * @type number
 * @desc Text color ID for tracked quests in the quest journal list.
 * @default 14
 *
 * @param Max Tracked Quests
 * @parent ---Track Settings---
 * @type number
 * @min 1
 * @desc Maximum number of quests that can be tracked at once.
 * @default 3
 *
 * @param Exceed Limit Text
 * @parent ---Track Settings---
 * @desc Text shown when exceeding max tracked quests. %1 is max number.
 * @default \c[4]You can only track up to %1 quests!
 *
 * @param Read Quest Text
 * @parent ---Track Settings---
 * @desc Text for the Read Quest option.
 * @default Read Quest
 *
 * @param Read Quest Icon
 * @parent ---Track Settings---
 * @type number
 * @desc Icon for the Read Quest option.
 * @default 121
 *
 * @param ---Tracker Window---
 * @default
 *
 * @param Custom Background Image
 * @parent ---Tracker Window---
 * @type file
 * @dir img/system/
 * @desc Image to use as the window background. Leave blank to use native window skin.
 * @default 
 *
 * @param Window X
 * @parent ---Tracker Window---
 * @desc X position of the tracker window.
 * @default Graphics.boxWidth - 320
 *
 * @param Window Y
 * @parent ---Tracker Window---
 * @desc Y position of the tracker window.
 * @default Graphics.boxHeight - 240
 *
 * @param Window Width
 * @parent ---Tracker Window---
 * @type number
 * @desc Width of the tracker window.
 * @default 300
 *
 * @param Window Height
 * @parent ---Tracker Window---
 * @type number
 * @desc Height of the tracker window.
 * @default 200
 *
 * @param Text X Padding
 * @parent ---Tracker Window---
 * @type number
 * @min 0
 * @desc Number of pixels to pad text from the left border.
 * @default 8
 *
 * @param Window Opacity
 * @parent ---Tracker Window---
 * @type number
 * @min 0
 * @max 255
 * @desc Opacity of the window frame.
 * @default 255
 *
 * @param Back Opacity
 * @parent ---Tracker Window---
 * @type number
 * @min 0
 * @max 255
 * @desc Opacity of the window background.
 * @default 192
 *
 * @param Text Opacity
 * @parent ---Tracker Window---
 * @type number
 * @min 0
 * @max 255
 * @desc Opacity of the text.
 * @default 255
 *
 * @param Transparent Opacity
 * @parent ---Tracker Window---
 * @type number
 * @min 0
 * @max 255
 * @desc Opacity when player is overlapping the window.
 * @default 100
 *
 * @param Tracker Font Size
 * @parent ---Tracker Window---
 * @type number
 * @min 1
 * @desc Font size for the text inside the tracker window.
 * @default 20
 *
 * @param ---Controls & Format---
 * @default
 *
 * @param Custom Key Codes
 * @parent ---Controls & Format---
 * @desc Map custom keys to keyboard codes. Format: "key:code, key:code". E.g. "u:85, y:89"
 * @default u:85, y:89, n:78, m:77, -:189, +:187, -:109, +:107
 *
 * @param Toggle Key
 * @parent ---Controls & Format---
 * @desc Key to show/hide the tracker window (shift, ctrl, u, y, etc).
 * @default u
 *
 * @param Scroll Up Key
 * @parent ---Controls & Format---
 * @desc Key to scroll up the tracker content.
 * @default +
 *
 * @param Scroll Down Key
 * @parent ---Controls & Format---
 * @desc Key to scroll down the tracker content.
 * @default -
 *
 * @param Toggle Hint Text
 * @parent ---Controls & Format---
 * @desc Text under the tracker. %1 is the toggle key. Use \n for line breaks.
 * @default Press [%1] to Show/Hide
 *
 * @param Hint Font Size
 * @parent ---Controls & Format---
 * @type number
 * @min 1
 * @desc Font size for the hint text under the tracker.
 * @default 14
 *
 * @param Custom Toggle Image
 * @parent ---Controls & Format---
 * @type file
 * @dir img/system/
 * @desc Image to use as the toggle button. Leave blank to use Mouse Toggle Icon.
 * @default 
 *
 * @param Mouse Toggle Icon
 * @parent ---Controls & Format---
 * @type number
 * @desc Icon used for the mouse toggle button if no Custom Toggle Image is set.
 * @default 310
 *
 * @param Button Closed X
 * @parent ---Controls & Format---
 * @desc X position when hidden. Variables 'buttonWidth' and 'buttonHeight' are available.
 * @default Graphics.boxWidth - buttonWidth - 20
 *
 * @param Button Closed Y
 * @parent ---Controls & Format---
 * @desc Y position when hidden. Variables 'buttonWidth' and 'buttonHeight' are available.
 * @default 20
 *
 * @param Step Indent
 * @parent ---Controls & Format---
 * @type number
 * @desc Number of pixels to indent the current step (%3).
 * @default 20
 *
 * @param Quest Spacing
 * @parent ---Controls & Format---
 * @type number
 * @desc Number of pixels to leave as empty space between different quests.
 * @default 12
 *
 * @param Show Item Icons
 * @parent ---Controls & Format---
 * @type boolean
 * @on YES
 * @off NO
 * @desc Show icons in the tracker text? Set to NO to strip \i[x] and \ii[x] icons.
 * @default false
 *
 * @param Word Wrap
 * @parent ---Controls & Format---
 * @type boolean
 * @on YES
 * @off NO
 * @desc Enable word wrap for the tracker window. Requires YEP_MessageCore.
 * @default true
 *
 * @param Line Format 1
 * @parent ---Controls & Format---
 * @desc Format for row 1. %1: Index, %2: Title, %3: Current Step
 * @default \c[6]%1.\c[0] %2
 *
 * @param Line Format 2
 * @parent ---Controls & Format---
 * @desc Format for row 2 (Current Step). %1: Index, %2: Title, %3: Current Step
 * @default %3
 *
 * @param ---Sound---
 * @default
 *
 * @param Toggle SE Name
 * @parent ---Sound---
 * @type file
 * @dir audio/se/
 * @desc Sound effect to play when clicking the mouse toggle button. Leave blank for default 'Ok'.
 * @default
 *
 * @param Toggle SE Volume
 * @parent ---Sound---
 * @type number
 * @min 0
 * @max 100
 * @desc Volume of the toggle SE.
 * @default 90
 *
 * @param Toggle SE Pitch
 * @parent ---Sound---
 * @type number
 * @min 50
 * @max 150
 * @desc Pitch of the toggle SE.
 * @default 100
 *
 * @help
 * ============================================================================
 * Introduction
 * ============================================================================
 *
 * This plugin requires YEP_QuestJournal and YEP_MessageCore.
 *
 * It adds a "Track Quest" option to the Quest Journal's extra commands. 
 * Players can track up to a configurable maximum number of quests. Tracked 
 * quests are displayed in a small window on the map screen, showing the 
 * current step/objective. 
 *
 * If the player walks behind the tracker window, it temporarily becomes 
 * transparent so the player can see their character.
 *
 * Tracked quests are automatically removed from the tracker when completed.
 *
 * ============================================================================
 * Features & Configurations
 * ============================================================================
 *
 * - Tracked Quest Color: Highlights tracked quests in your main Journal list 
 *   with a custom text color code so they are easy to identify.
 *
 * - Custom Graphics: You can replace the default Window Skin and Toggle Icon 
 *   with custom images loaded directly from your 'img/system/' folder.
 *   * Dynamic Positioning: When using a Custom Toggle Image, you can use the
 *     variables 'buttonWidth' and 'buttonHeight' inside the "Button Closed X" 
 *     and "Button Closed Y" parameters to properly calculate screen margins!
 *     Example: Graphics.boxWidth - buttonWidth - 20
 *
 * - Strip Icons: Use the 'Show Item Icons' parameter to automatically strip 
 *   out standard \i[x] and Yanfly's \ii[x] icons from the tracker UI to 
 *   keep your interface clean and prevent awkward line-height stretching.
 *
 * - Scroll Controls: Scroll through your tracked quests using the configured 
 *   Up/Down keys or the mouse scroll wheel when hovering over the window.
 *
 * - Custom Key Mapping: You can easily map new keys (like numpad + and -) 
 *   using the 'Custom Key Codes' parameter format "key:code".
 *
 * - Line Breaks in Hint: You can use \n inside the Toggle Hint Text parameter 
 *   to create line breaks if you need a longer tooltip!
 *
 * - Sound Effects: You can define a custom Sound Effect (SE), including volume 
 *   and pitch, for whenever the tracker is toggled open or closed.
 *
 * - Moghunter Compatibility: Fully compatible with MOG_MenuBackground, 
 *   MOG_MenuParticles, and MOG_MenuCursor seamlessly within Scene_Quest.
 * - Full list custom keys: 
 * a:65, b:66, c:67, d:68, e:69, f:70, g:71, h:72, i:73, j:74, k:75, l:76, m:77, n:78, 
 * o:79, p:80, q:81, r:82, s:83, t:84, u:85, v:86, w:87, x:88, y:89, z:90, 0:48, 1:49, 2:50, 3:51, 
 * 4:52, 5:53, 6:54, 7:55, 8:56, 9:57, num0:96, num1:97, num2:98, num3:99, num4:100, num5:101, num6:102, 
 * num7:103, num8:104, num9:105, backspace:8, tab:9, enter:13, shift:16, ctrl:17, alt:18, escape:27, space:32, 
 * pageup:33, pagedown:34, left:37, up:38, right:39, down:40, insert:45, delete:46, -:189, +:187, -:109, +:107, 
 * ;:186, ,:188, .:190, /:191, `:192, [:219, \:220, ]:221, ':222, f1:112, f2:113, f3:114, f4:115, f5:116, f6:117, 
 * f7:118, f8:119, f9:120, f10:121, f11:122, f12:123
 *
 * ============================================================================
 * Plugin Commands
 * ============================================================================
 *
 * TrackQuest Clear
 * - Untracks all currently tracked quests.
 *
 */

//=============================================================================
// Parameter Variables
//=============================================================================

JR.Parameters = PluginManager.parameters('JR_QuestTracker');
JR.Param = JR.Param || {};

JR.Param.TrackQuestText = String(JR.Parameters['Track Quest Text']);
JR.Param.TrackedIcon = Number(JR.Parameters['Tracked Icon']);
JR.Param.UntrackedIcon = Number(JR.Parameters['Untracked Icon']);
JR.Param.TrackedColor = Number(JR.Parameters['Tracked Quest Color'] || 14);
JR.Param.MaxTracked = Number(JR.Parameters['Max Tracked Quests']);
JR.Param.ExceedText = String(JR.Parameters['Exceed Limit Text']);
JR.Param.ReadQuestText = String(JR.Parameters['Read Quest Text']);
JR.Param.ReadQuestIcon = Number(JR.Parameters['Read Quest Icon']);
JR.Param.CustomBgImage = String(JR.Parameters['Custom Background Image'] || '');
JR.Param.WindowX = String(JR.Parameters['Window X']);
JR.Param.WindowY = String(JR.Parameters['Window Y']);
JR.Param.WindowWidth = String(JR.Parameters['Window Width']);
JR.Param.WindowHeight = String(JR.Parameters['Window Height']);
JR.Param.TextXPadding = Number(JR.Parameters['Text X Padding']);
JR.Param.WindowOpacity = Number(JR.Parameters['Window Opacity']);
JR.Param.BackOpacity = Number(JR.Parameters['Back Opacity']);
JR.Param.TextOpacity = Number(JR.Parameters['Text Opacity']);
JR.Param.TransparentOpacity = Number(JR.Parameters['Transparent Opacity']);
JR.Param.TrackerFontSize = Number(JR.Parameters['Tracker Font Size']);
JR.Param.CustomKeyCodes = String(JR.Parameters['Custom Key Codes']);
JR.Param.ToggleKey = String(JR.Parameters['Toggle Key']);
JR.Param.ScrollUpKey = String(JR.Parameters['Scroll Up Key']);
JR.Param.ScrollDownKey = String(JR.Parameters['Scroll Down Key']);
JR.Param.ToggleHintText = String(JR.Parameters['Toggle Hint Text']);
JR.Param.HintFontSize = Number(JR.Parameters['Hint Font Size']);
JR.Param.CustomToggleImage = String(JR.Parameters['Custom Toggle Image'] || '');
JR.Param.MouseToggleIcon = Number(JR.Parameters['Mouse Toggle Icon']);
JR.Param.ButtonClosedX = String(JR.Parameters['Button Closed X']);
JR.Param.ButtonClosedY = String(JR.Parameters['Button Closed Y']);
JR.Param.StepIndent = Number(JR.Parameters['Step Indent']);
JR.Param.QuestSpacing = Number(JR.Parameters['Quest Spacing']);
JR.Param.ShowItemIcons = eval(String(JR.Parameters['Show Item Icons'] || 'false'));
JR.Param.WordWrap = eval(String(JR.Parameters['Word Wrap']));
JR.Param.LineFormat1 = String(JR.Parameters['Line Format 1']);
JR.Param.LineFormat2 = String(JR.Parameters['Line Format 2']);

// Sound Settings
JR.Param.ToggleSEName = String(JR.Parameters['Toggle SE Name'] || '');
JR.Param.ToggleSEVol = Number(JR.Parameters['Toggle SE Volume'] || 90);
JR.Param.ToggleSEPitch = Number(JR.Parameters['Toggle SE Pitch'] || 100);

// Register Custom Keys
if (JR.Param.CustomKeyCodes) {
    var pairs = JR.Param.CustomKeyCodes.split(',');
    for (var i = 0; i < pairs.length; i++) {
        var pair = pairs[i].split(':');
        if (pair.length === 2) {
            var key = pair[0].trim().toLowerCase();
            var code = parseInt(pair[1].trim());
            if (key && !isNaN(code)) {
                Input.keyMapper[code] = key;
            }
        }
    }
}

//=============================================================================
// Game_System
//=============================================================================

JR.Tracker.Game_System_initialize = Game_System.prototype.initialize;
Game_System.prototype.initialize = function() {
    JR.Tracker.Game_System_initialize.call(this);
    this.initTrackerSettings();
};

Game_System.prototype.initTrackerSettings = function() {
    this._trackedQuests = this._trackedQuests || [];
};

Game_System.prototype.getTrackedQuests = function() {
    if (this._trackedQuests === undefined) this.initTrackerSettings();
    return this._trackedQuests;
};

Game_System.prototype.isQuestTracked = function(questId) {
    if (this._trackedQuests === undefined) this.initTrackerSettings();
    return this._trackedQuests.contains(questId);
};

Game_System.prototype.trackQuest = function(questId) {
    if (this._trackedQuests === undefined) this.initTrackerSettings();
    if (this._trackedQuests.contains(questId)) return;
    this._trackedQuests.push(questId);
    this.requestTrackerRefresh();
};

Game_System.prototype.untrackQuest = function(questId) {
    if (this._trackedQuests === undefined) this.initTrackerSettings();
    var index = this._trackedQuests.indexOf(questId);
    if (index >= 0) {
        this._trackedQuests.splice(index, 1);
        this.requestTrackerRefresh();
    }
};

Game_System.prototype.clearTrackedQuests = function() {
    this._trackedQuests = [];
    this.requestTrackerRefresh();
};

Game_System.prototype.requestTrackerRefresh = function() {
    this._trackerNeedsRefresh = true;
};

// Remove from tracker when completed or failed
JR.Tracker.Game_System_questSetCompleted = Game_System.prototype.questSetCompleted;
Game_System.prototype.questSetCompleted = function(questId) {
    JR.Tracker.Game_System_questSetCompleted.call(this, questId);
    if (this.isQuestTracked(questId)) this.untrackQuest(questId);
};

JR.Tracker.Game_System_questSetFailed = Game_System.prototype.questSetFailed;
Game_System.prototype.questSetFailed = function(questId) {
    JR.Tracker.Game_System_questSetFailed.call(this, questId);
    if (this.isQuestTracked(questId)) this.untrackQuest(questId);
};

// Request refresh when objectives change
var methodsToAlias = [
    'questObjectivesComplete', 'questObjectivesFail', 'questObjectivesNormal',
    'questObjectivesShow', 'questObjectivesHide', 'questChangeDescriptionIndex'
];

methodsToAlias.forEach(function(method) {
    var alias = Game_System.prototype[method];
    Game_System.prototype[method] = function() {
        alias.apply(this, arguments);
        this.requestTrackerRefresh();
    };
});

//=============================================================================
// Game_Variables & Game_Switches 
// Refresh the tracker UI instantly whenever a \v[x] or switch updates
//=============================================================================

JR.Tracker.Game_Variables_setValue = Game_Variables.prototype.setValue;
Game_Variables.prototype.setValue = function(variableId, value) {
    JR.Tracker.Game_Variables_setValue.call(this, variableId, value);
    if ($gameSystem) $gameSystem.requestTrackerRefresh();
};

JR.Tracker.Game_Switches_setValue = Game_Switches.prototype.setValue;
Game_Switches.prototype.setValue = function(switchId, value) {
    JR.Tracker.Game_Switches_setValue.call(this, switchId, value);
    if ($gameSystem) $gameSystem.requestTrackerRefresh();
};

//=============================================================================
// Game_Interpreter
//=============================================================================

JR.Tracker.Game_Interpreter_pluginCommand = Game_Interpreter.prototype.pluginCommand;
Game_Interpreter.prototype.pluginCommand = function(command, args) {
    JR.Tracker.Game_Interpreter_pluginCommand.call(this, command, args);
    if (command === 'TrackQuest') {
        if (args[0] === 'Clear') {
            $gameSystem.clearTrackedQuests();
        }
    }
};

//=============================================================================
// Window_TrackerTooltip (For Exceed Limit)
//=============================================================================

function Window_TrackerTooltip() {
    this.initialize.apply(this, arguments);
}

Window_TrackerTooltip.prototype = Object.create(Window_Base.prototype);
Window_TrackerTooltip.prototype.constructor = Window_TrackerTooltip;

Window_TrackerTooltip.prototype.initialize = function() {
    Window_Base.prototype.initialize.call(this, 0, 0, 1, 1);
    this.openness = 0;
    this.hide();
};

Window_TrackerTooltip.prototype.setText = function(text) {
    this._text = text;
    this.width = this.windowWidth();
    this.height = this.windowHeight();
    this.createContents();
    this.refresh();
    this.x = (Graphics.boxWidth - this.width) / 2;
    this.y = (Graphics.boxHeight - this.height) / 2;
    this.show();
    this.open();
};

Window_TrackerTooltip.prototype.windowWidth = function() {
    this.resetFontSettings();
    var width = this.textWidthEx(this._text) + this.padding * 2 + 20;
    return Math.min(Math.max(width, 100), Graphics.boxWidth);
};

Window_TrackerTooltip.prototype.windowHeight = function() {
    return this.fittingHeight(1);
};

Window_TrackerTooltip.prototype.refresh = function() {
    this.contents.clear();
    this.resetFontSettings();
    var textState = { text: this._text, index: 0 };
    var textHeight = this.calcTextHeight(textState, false);
    var y = Math.max(0, (this.contents.height - textHeight) / 2);
    this.drawTextEx(this._text, this.padding, y);
};

//=============================================================================
// Scene_Quest
//=============================================================================

JR.Tracker.Scene_Quest_isQuestExtraCommand = Scene_Quest.prototype.isQuestExtraCommand;
Scene_Quest.prototype.isQuestExtraCommand = function() {
    return true;
};

JR.Tracker.Scene_Quest_create = Scene_Quest.prototype.create;
Scene_Quest.prototype.create = function() {
    JR.Tracker.Scene_Quest_create.call(this);
    this.createTooltipWindow();
};

Scene_Quest.prototype.createTooltipWindow = function() {
    this._tooltipWindow = new Window_TrackerTooltip();
    this.addWindow(this._tooltipWindow);
};

// Compatible Backgrounds & Particles Integration
JR.Tracker.Scene_Quest_createBackground = Scene_Quest.prototype.createBackground;
Scene_Quest.prototype.createBackground = function() {
    JR.Tracker.Scene_Quest_createBackground.call(this);
    if (Imported.MOG_MenuBackground && this.create_mbackground && !this.skip_mbackground()) {
        this.create_mbackground();
    }
    if (Imported.MOG_MenuParticles && this.create_mparticles && !this.skip_particles()) {
        this.create_mparticles();
    }
};

JR.Tracker.Scene_Quest_update = Scene_Quest.prototype.update;
Scene_Quest.prototype.update = function() {
    JR.Tracker.Scene_Quest_update.call(this);
    
    // Tooltip Handling
    if (this._tooltipCount > 0) {
        this._tooltipCount--;
        if (this._tooltipCount === 0 && this._tooltipWindow) {
            this._tooltipWindow.close();
        }
    }
    
    // MOG Background Compatibility Updates
    if (Imported.MOG_MenuBackground && this._backgroundSpriteNew && this.update_mbackground) {
        this.update_mbackground();
    }
    if (Imported.MOG_MenuParticles && SceneManager._mpart && this.update_particles) {
        this.update_particles();
    }
    
    // MOG Cursor Compatibility Updates (Z-index Fix)
    if (Imported.MOG_MenuCursor && this._sprite_mcursor) {
        var lastChild = this.children[this.children.length - 1];
        if (lastChild !== this._sprite_mcursor && lastChild !== this._tooltipWindow) {
            this.addChild(this._sprite_mcursor);
            if (this._tooltipWindow) this.addChild(this._tooltipWindow); // Keep Tooltip Absolute Top
        }
    }
};

JR.Tracker.Scene_Quest_terminate = Scene_Quest.prototype.terminate;
Scene_Quest.prototype.terminate = function() {
    JR.Tracker.Scene_Quest_terminate.call(this);
    if (Imported.MOG_MenuBackground) SceneManager._mback = false;
    if (Imported.MOG_MenuParticles) SceneManager._mpart = false;
};

Scene_Quest.prototype.showTooltip = function(text) {
    if (!this._tooltipWindow) return;
    this._tooltipWindow.setText(text);
    this._tooltipCount = 90;
};

JR.Tracker.Scene_Quest_createListWindow = Scene_Quest.prototype.createListWindow;
Scene_Quest.prototype.createListWindow = function() {
    JR.Tracker.Scene_Quest_createListWindow.call(this);
    this._listWindow.setHandler('trackQuest', this.onTrackQuest.bind(this));
};

Scene_Quest.prototype.onTrackQuest = function() {
    var questId = this._listWindow.currentExt();
    
    if ($gameSystem._questsCompleted.contains(questId) || $gameSystem._questsFailed.contains(questId)) {
        SoundManager.playBuzzer();
        this._listWindow.activate();
        return;
    }
    
    if ($gameSystem.isQuestTracked(questId)) {
        $gameSystem.untrackQuest(questId);
        SoundManager.playOk();
    } else {
        if ($gameSystem.getTrackedQuests().length >= JR.Param.MaxTracked) {
            SoundManager.playBuzzer();
            var text = JR.Param.ExceedText.replace('%1', JR.Param.MaxTracked);
            this.showTooltip(text);
        } else {
            $gameSystem.trackQuest(questId);
            SoundManager.playOk();
        }
    }
    this._listWindow.refresh();
    this._listWindow.activate();
};

//=============================================================================
// Window_QuestList
//=============================================================================

JR.Tracker.Window_QuestList_addReadQuestCommand = Window_QuestList.prototype.addReadQuestCommand;
Window_QuestList.prototype.addReadQuestCommand = function() {
    var text = '\\i[' + JR.Param.ReadQuestIcon + ']' + JR.Param.ReadQuestText;
    this.addCommand(text, 'readQuest');
};

JR.Tracker.Window_QuestList_makeExtraListA = Window_QuestList.prototype.makeExtraListA;
Window_QuestList.prototype.makeExtraListA = function() {
    var questId = this._forcedExt;
    var tracked = $gameSystem.isQuestTracked(questId);
    var iconId = tracked ? JR.Param.TrackedIcon : JR.Param.UntrackedIcon;
    var text = '\\i[' + iconId + ']' + JR.Param.TrackQuestText;
    this.addCommand(text, 'trackQuest', true, questId);
};

JR.Tracker.Window_QuestList_drawItem = Window_QuestList.prototype.drawItem;
Window_QuestList.prototype.drawItem = function(index) {
    var item = this._list[index];
    var originalName = item ? item.name : '';
    
    // Check if the current item is an actual quest and if it is currently tracked
    var isTracked = item && item.symbol === 'quest' && $gameSystem.isQuestTracked(item.ext);
    
    if (isTracked) {
        // Temporarily inject the color code for the drawing process
        item.name = '\\c[' + JR.Param.TrackedColor + ']' + originalName;
    }
    
    // Call Yanfly's original drawing method
    JR.Tracker.Window_QuestList_drawItem.call(this, index);
    
    if (isTracked) {
        // Revert the name back so the color code doesn't permanently overwrite the quest data
        item.name = originalName;
    }
};

//=============================================================================
// Window_Tracker
//=============================================================================

function Window_Tracker() {
    this.initialize.apply(this, arguments);
}

Window_Tracker.prototype = Object.create(Window_Selectable.prototype);
Window_Tracker.prototype.constructor = Window_Tracker;

Window_Tracker.prototype.initialize = function() {
    var width = eval(JR.Param.WindowWidth);
    var height = eval(JR.Param.WindowHeight);
    var x = eval(JR.Param.WindowX);
    var y = eval(JR.Param.WindowY);
    Window_Selectable.prototype.initialize.call(this, x, y, width, height);
    this.opacity = Number(JR.Param.WindowOpacity);
    this.backOpacity = Number(JR.Param.BackOpacity);
    this.contentsOpacity = Number(JR.Param.TextOpacity);
    this._needsRefresh = true;
    this._expanded = true;
    this._scrollY = 0;
    this._maxScrollY = 0;
    
    if (JR.Param.CustomBgImage !== '') {
        this._customBgSprite = new Sprite();
        var bgBitmap = ImageManager.loadSystem(JR.Param.CustomBgImage);
        this._customBgSprite.bitmap = bgBitmap;
        
        // Wait for the image to load, then scale it to fit the window exactly
        bgBitmap.addLoadListener(function() {
            this._customBgSprite.scale.x = this.width / bgBitmap.width;
            this._customBgSprite.scale.y = this.height / bgBitmap.height;
        }.bind(this));
        
        // Add custom image behind all window content (index 0)
        this.addChildAt(this._customBgSprite, 0); 
    }
    
    this.hide();
};

Window_Tracker.prototype.maxItems = function() {
    return 0;
};

Window_Tracker.prototype.standardFontSize = function() {
    return Number(JR.Param.TrackerFontSize);
};

Window_Tracker.prototype.lineHeight = function() {
    return Math.floor(this.standardFontSize() * 1.2);
};

// Fix MV's NaN height bug when processing wrapped text
Window_Tracker.prototype.calcTextHeight = function(textState, all) {
    return this.lineHeight();
};

Window_Tracker.prototype.isInsideFrame = function() {
    // FIX: Safely fallback to TouchInput.x if _mouseOverX is not available (like before any clicks happen)
    var mx = TouchInput._mouseOverX !== undefined ? TouchInput._mouseOverX : TouchInput.x;
    var my = TouchInput._mouseOverY !== undefined ? TouchInput._mouseOverY : TouchInput.y;
    var x = this.canvasToLocalX(mx);
    var y = this.canvasToLocalY(my);
    return x >= 0 && y >= 0 && x < this.width && y < this.height;
};

Window_Tracker.prototype.contentsHeight = function() {
    var standard = this.height - this.standardPadding() * 2;
    return Math.max(standard, this._allTextHeight || 0);
};

Window_Tracker.prototype.getCurrentObjectiveText = function(questId) {
    var quest = $dataQuests[questId];
    if (!quest) return '';
    
    var visObjs = $gameSystem.getQuestObjectives(questId);
    for (var i = 0; i < visObjs.length; i++) {
        var objId = visObjs[i];
        if (!$gameSystem.isQuestObjectiveCompleted(questId, objId) && 
            !$gameSystem.isQuestObjectiveFailed(questId, objId)) {
            var objText = quest.objectives[objId];
            if (objText) {
                try {
                    return JSON.parse(objText);
                } catch(e) {
                    return String(objText);
                }
            }
        }
    }
    
    var descIndex = $gameSystem.getQuestDescriptionIndex(questId);
    var descText = quest.description[descIndex] || quest.description[1];
    if (descText) {
        try {
            return JSON.parse(descText);
        } catch(e) {
            return String(descText);
        }
    }
    return '';
};

Window_Tracker.prototype.drawTextBlock = function(text, x, y, width) {
    // Explicitly pass width into the textState for YEP_MessageCore
    var textState = { index: 0, x: x, y: y, left: x, width: width }; 
    this.resetFontSettings();
    textState.text = this.convertEscapeCharacters(text);
    
    // Strip out icons if disabled via plugin parameters
    if (!JR.Param.ShowItemIcons) {
        textState.text = textState.text.replace(/\x1bI\[\d+\]/gi, '');
    }

    textState.height = this.lineHeight();
    while (textState.index < textState.text.length) {
        this.processCharacter(textState);
    }
    return textState.y + this.lineHeight();
};

Window_Tracker.prototype.refresh = function() {
    var tracked = $gameSystem.getTrackedQuests();
    
    if (tracked.length === 0) {
        this._allTextHeight = 0;
        this.createContents();
        this.contents.clear();
        this._maxScrollY = 0;
        this.origin.y = 0;
        return;
    }

    // Safety fallback for padding and indent parameters
    var padding = Number(JR.Param.TextXPadding) || 8;
    var indent = Number(JR.Param.StepIndent) || 20;
    var spacing = Number(JR.Param.QuestSpacing) || 12;
    var ww = JR.Param.WordWrap ? "<WordWrap>" : "";
    
    // --- PASS 1: Calculate Total Text Height First ---
    this._allTextHeight = 0; 
    this.createContents(); 
    var width = this.contents.width;
    var calcY = 0;

    // Reset Yanfly's word wrap state before processing text
    this._wordWrap = false; 
    
    // [OPTIMIZATION]: Temporarily disable actual canvas rendering to save CPU!
    var originalDrawText = this.contents.drawText;
    this.contents.drawText = function() {}; 

    for (var i = 0; i < tracked.length; i++) {
        var questId = tracked[i];
        
        // Safety checks for missing or malformed Yanfly Database data
        if (!$dataQuests) continue; 
        var quest = $dataQuests[questId];
        if (!quest || !quest.name) continue;

        var title = String(quest.name).replace(/\\i\[(\d+)\]/gi, '').trim();
        var step = this.getCurrentObjectiveText(questId);

        var text1 = ww + JR.Param.LineFormat1.format(i + 1, title, step);
        var text2 = ww + JR.Param.LineFormat2.format(i + 1, title, step);

        calcY = this.drawTextBlock(text1, padding, calcY, width);
        calcY = this.drawTextBlock(text2, padding + indent, calcY, width - indent);
        calcY += spacing;
    }
    
    // [OPTIMIZATION]: Restore the rendering function for Pass 2
    this.contents.drawText = originalDrawText;

    // --- PASS 2: Recreate Canvas & Draw Properly ---
    this._allTextHeight = calcY; 
    this.createContents();       
    this.contents.clear();
    
    // Force paint opacity to 255 to ensure text isn't drawn transparently
    this.contents.paintOpacity = 255; 
    width = this.contents.width;

    // Reset Yanfly's word wrap state again for the actual drawing pass
    this._wordWrap = false; 
    var y = 0;
    
    for (var i = 0; i < tracked.length; i++) {
        var questId = tracked[i];
        
        if (!$dataQuests) continue;
        var quest = $dataQuests[questId];
        if (!quest || !quest.name) continue;

        var title = String(quest.name).replace(/\\i\[(\d+)\]/gi, '').trim();
        var step = this.getCurrentObjectiveText(questId);

        var text1 = ww + JR.Param.LineFormat1.format(i + 1, title, step);
        var text2 = ww + JR.Param.LineFormat2.format(i + 1, title, step);

        y = this.drawTextBlock(text1, padding, y, width);
        y = this.drawTextBlock(text2, padding + indent, y, width - indent);
        y += spacing;
    }

    var visibleHeight = this.height - this.padding * 2;
    this._maxScrollY = Math.max(0, this.contents.height - visibleHeight);
    
    if (this.origin.y > this._maxScrollY) {
        this.origin.y = this._maxScrollY;
    }
};

Window_Tracker.prototype.update = function() {
    Window_Selectable.prototype.update.call(this);
    this.updateVisibility();
    this.updateOpacity();
    this.updateInput();
};

Window_Tracker.prototype.updateVisibility = function() {
    var hasTracked = $gameSystem.getTrackedQuests().length > 0;
    var sceneValid = !$gameMap.isEventRunning() && !$gameMessage.isBusy() && !$gameParty.inBattle();
    
    if (hasTracked && sceneValid) {
        if (this._needsRefresh || $gameSystem._trackerNeedsRefresh) {
            this.refresh();
            this._needsRefresh = false;
            $gameSystem._trackerNeedsRefresh = false;
        }
        if (this._expanded) {
            this.show();
        } else {
            this.hide();
        }
    } else {
        this.hide();
    }
};

Window_Tracker.prototype.updateOpacity = function() {
    var player = $gamePlayer;
    var screenX = player.screenX();
    var screenY = player.screenY();
    
    // Create an invisible 48x48 bounding box around the player center
    var isOverlapping = !(
        (screenX - 24) > (this.x + this.width) ||
        (screenX + 24) < this.x ||
        (screenY - 48) > (this.y + this.height) ||
        screenY < this.y
    );
        
    if (isOverlapping) {
        if (JR.Param.CustomBgImage !== '' && this._customBgSprite) {
            this.opacity = 0;
            this.backOpacity = 0;
            this._customBgSprite.opacity = Number(JR.Param.TransparentOpacity);
        } else {
            this.opacity = Number(JR.Param.TransparentOpacity);
            this.backOpacity = Math.floor(Number(JR.Param.TransparentOpacity) * 0.75);
        }
        this.contentsOpacity = Number(JR.Param.TransparentOpacity);
    } else {
        if (JR.Param.CustomBgImage !== '' && this._customBgSprite) {
            this.opacity = 0;
            this.backOpacity = 0;
            this._customBgSprite.opacity = Number(JR.Param.WindowOpacity);
        } else {
            this.opacity = Number(JR.Param.WindowOpacity);
            this.backOpacity = Number(JR.Param.BackOpacity);
        }
        this.contentsOpacity = Number(JR.Param.TextOpacity);
    }
};

Window_Tracker.prototype.updateInput = function() {
    if (!this.visible || !this._expanded) return;
    
    var speed = 4;
    if (Input.isPressed(JR.Param.ScrollUpKey)) {
        this.origin.y -= speed;
    } else if (Input.isPressed(JR.Param.ScrollDownKey)) {
        this.origin.y += speed;
    }
    
    if (this.isInsideFrame()) {
        if (TouchInput.wheelY > 0) this.origin.y += TouchInput.wheelY / 2;
        if (TouchInput.wheelY < 0) this.origin.y += TouchInput.wheelY / 2;
    }
    
    this.origin.y = Math.max(0, Math.min(this.origin.y, this._maxScrollY));
};

Window_Tracker.prototype.setExpanded = function(expanded) {
    this._expanded = expanded;
    if (!expanded) {
        this.origin.y = 0;
    }
};

//=============================================================================
// Sprite_TrackerHint
//=============================================================================

function Sprite_TrackerHint() {
    this.initialize.apply(this, arguments);
}

Sprite_TrackerHint.prototype = Object.create(Sprite.prototype);
Sprite_TrackerHint.prototype.constructor = Sprite_TrackerHint;

Sprite_TrackerHint.prototype.initialize = function() {
    Sprite.prototype.initialize.call(this);
    this._expanded = true;
    this.visible = false;
    this.bitmap = new Bitmap(1, 1);
    this.refresh();
};

Sprite_TrackerHint.prototype.refresh = function() {
    var rawText = JR.Param.ToggleHintText.replace('%1', JR.Param.ToggleKey.toUpperCase());
    
    // FIX: Handle all possible ways MV escapes the backslash for 'n' natively and inside Plugin Manager
    var lines = rawText.split(/\\\\n|\\n|\n/gi);
    
    var fontSize = Number(JR.Param.HintFontSize);
    var lineHeight = fontSize + 4;
    var tempBmp = new Bitmap(1, 1);
    tempBmp.fontSize = fontSize;
    
    var width = 0;
    for (var i = 0; i < lines.length; i++) {
        width = Math.max(width, tempBmp.measureTextWidth(lines[i]));
    }
    
    this.bitmap = new Bitmap(width + 8, (lineHeight * lines.length) + 8);
    this.bitmap.fontSize = fontSize;
    this.bitmap.textColor = '#ffffff';
    this.bitmap.outlineColor = 'rgba(0,0,0,0.8)';
    this.bitmap.outlineWidth = 4;
    
    for (var j = 0; j < lines.length; j++) {
        this.bitmap.drawText(lines[j], 4, 4 + (j * lineHeight), this.bitmap.width - 8, lineHeight, 'left');
    }
    
    this.x = eval(JR.Param.WindowX);
    this.y = eval(JR.Param.WindowY) + eval(JR.Param.WindowHeight) + 4;
};

Sprite_TrackerHint.prototype.update = function() {
    Sprite.prototype.update.call(this);
    var hasTracked = $gameSystem.getTrackedQuests().length > 0;
    var sceneValid = !$gameMap.isEventRunning() && !$gameMessage.isBusy() && !$gameParty.inBattle();
    this.visible = hasTracked && sceneValid && this._expanded;
    
    if (this.visible) {
        this.updateOpacity();
    }
};

Sprite_TrackerHint.prototype.updateOpacity = function() {
    var player = $gamePlayer;
    var screenX = player.screenX();
    var screenY = player.screenY();
    var w = this.bitmap ? this.bitmap.width : 0;
    var h = this.bitmap ? this.bitmap.height : 0;
    
    var isOverlapping = !(
        (screenX - 24) > (this.x + w) ||
        (screenX + 24) < this.x ||
        (screenY - 48) > (this.y + h) ||
        screenY < this.y
    );
    
    if (isOverlapping) {
        this.opacity = Number(JR.Param.TransparentOpacity);
    } else {
        this.opacity = 255;
    }
};

Sprite_TrackerHint.prototype.setExpanded = function(expanded) {
    this._expanded = expanded;
};

//=============================================================================
// Sprite_ToggleButton
//=============================================================================

function Sprite_ToggleButton() {
    this.initialize.apply(this, arguments);
}

Sprite_ToggleButton.prototype = Object.create(Sprite_Button.prototype);
Sprite_ToggleButton.prototype.constructor = Sprite_ToggleButton;

Sprite_ToggleButton.prototype.initialize = function() {
    Sprite_Button.prototype.initialize.call(this);
    this._scene = null;
    this._expanded = true;
    
    this._keyHintSprite = new Sprite();
    this.addChild(this._keyHintSprite);
    
    if (JR.Param.CustomToggleImage !== '') {
        this.bitmap = ImageManager.loadSystem(JR.Param.CustomToggleImage);
        this.bitmap.addLoadListener(function() {
            this.refreshKeyHint();
            this.updatePosition();
        }.bind(this));
    } else {
        var w = Window_Base._iconWidth;
        var h = Window_Base._iconHeight;
        this.bitmap = new Bitmap(w, h);
        
        var bitmap = ImageManager.loadSystem('IconSet');
        var iconId = Number(JR.Param.MouseToggleIcon);
        var pw = Window_Base._iconWidth;
        var ph = Window_Base._iconHeight;
        var sx = (iconId % 16) * pw;
        var sy = Math.floor(iconId / 16) * ph;
        this.bitmap.blt(bitmap, sx, sy, pw, ph, 0, 0);
        
        this.refreshKeyHint();
        this.updatePosition();
    }
    
    this.setClickHandler(this.onClick.bind(this));
};

Sprite_ToggleButton.prototype.refreshKeyHint = function() {
    var text = '[' + JR.Param.ToggleKey.toUpperCase() + ']';
    var fontSize = Number(JR.Param.HintFontSize);
    var tempBmp = new Bitmap(1, 1);
    tempBmp.fontSize = fontSize;
    var width = tempBmp.measureTextWidth(text) + 8;
    
    this._keyHintSprite.bitmap = new Bitmap(width, fontSize + 8);
    this._keyHintSprite.bitmap.fontSize = fontSize;
    this._keyHintSprite.bitmap.textColor = '#ffffff';
    this._keyHintSprite.bitmap.outlineColor = 'rgba(0,0,0,0.8)';
    this._keyHintSprite.bitmap.outlineWidth = 4;
    this._keyHintSprite.bitmap.drawText(text, 0, 0, width, fontSize + 8, 'center');
    
    var iconW = this.bitmap && this.bitmap.width > 0 ? this.bitmap.width : Window_Base._iconWidth;
    var iconH = this.bitmap && this.bitmap.height > 0 ? this.bitmap.height : Window_Base._iconHeight;
    
    this._keyHintSprite.x = (iconW - width) / 2;
    this._keyHintSprite.y = iconH + 2;
};

Sprite_ToggleButton.prototype.update = function() {
    Sprite_Button.prototype.update.call(this);
    var sceneValid = !$gameMap.isEventRunning() && !$gameMessage.isBusy() && !$gameParty.inBattle();
    this.visible = $gameSystem.getTrackedQuests().length > 0 && sceneValid;
    
    if (this.visible) {
        var isHovered = this.isButtonTouched();
        var targetScale = isHovered ? 1.1 : 1.0;
        
        // [OPTIMIZATION]: Only update scale if it changes to avoid PIXI dirty flag matrix calculations
        if (this.scale.x !== targetScale) {
            this.scale.x = targetScale;
            this.scale.y = targetScale;
        }
        
        this.updateOpacity();
    }
};

Sprite_ToggleButton.prototype.updateOpacity = function() {
    var player = $gamePlayer;
    var screenX = player.screenX();
    var screenY = player.screenY();
    var w = this.bitmap && this.bitmap.isReady() ? this.bitmap.width : Window_Base._iconWidth;
    var h = this.bitmap && this.bitmap.isReady() ? this.bitmap.height : Window_Base._iconHeight;
    
    if (this._keyHintSprite && this._keyHintSprite.visible && this._keyHintSprite.bitmap) {
        h += this._keyHintSprite.bitmap.height;
    }
    
    var isOverlapping = !(
        (screenX - 24) > (this.x + w) ||
        (screenX + 24) < this.x ||
        (screenY - 48) > (this.y + h) ||
        screenY < this.y
    );
    
    if (isOverlapping) {
        this.opacity = Number(JR.Param.TransparentOpacity);
    } else {
        this.opacity = 255;
    }
};

Sprite_ToggleButton.prototype.isButtonTouched = function() {
    var x = TouchInput.x;
    var y = TouchInput.y;
    return x >= this.x && x <= this.x + this.width && y >= this.y && y <= this.y + this.height;
};

Sprite_ToggleButton.prototype.updatePosition = function() {
    var buttonWidth = this.bitmap && this.bitmap.isReady() ? this.bitmap.width : Window_Base._iconWidth;
    var buttonHeight = this.bitmap && this.bitmap.isReady() ? this.bitmap.height : Window_Base._iconHeight;

    if (this._expanded) {
        var trackerX = eval(JR.Param.WindowX);
        var trackerW = eval(JR.Param.WindowWidth);
        var trackerY = eval(JR.Param.WindowY);
        this.y = trackerY;
        
        if (trackerX < Graphics.boxWidth / 2) {
            this.x = trackerX + trackerW + 4;
        } else {
            this.x = trackerX - buttonWidth - 4;
        }
        this._keyHintSprite.visible = false;
    } else {
        this.x = eval(JR.Param.ButtonClosedX);
        this.y = eval(JR.Param.ButtonClosedY);
        this._keyHintSprite.visible = true;
    }
};

Sprite_ToggleButton.prototype.onClick = function() {
    this._expanded = !this._expanded;
    this.updatePosition();
    if (this._scene) {
        this._scene._trackerWindow.setExpanded(this._expanded);
        this._scene._trackerHint.setExpanded(this._expanded);
        
        if (JR.Param.ToggleSEName !== '') {
            var se = {
                name: JR.Param.ToggleSEName,
                pan: 0,
                pitch: JR.Param.ToggleSEPitch,
                volume: JR.Param.ToggleSEVol
            };
            AudioManager.playSe(se);
        } else {
            SoundManager.playOk();
        }
    }
};

//=============================================================================
// Scene_Map
//=============================================================================

JR.Tracker.Scene_Map_createAllWindows = Scene_Map.prototype.createAllWindows;
Scene_Map.prototype.createAllWindows = function() {
    JR.Tracker.Scene_Map_createAllWindows.call(this);
    this._trackerWindow = new Window_Tracker();
    this._trackerHint = new Sprite_TrackerHint();
    this._toggleButton = new Sprite_ToggleButton();
    this._toggleButton._scene = this;
    
    this.addWindow(this._trackerWindow);
    this.addChild(this._trackerHint);
    this.addChild(this._toggleButton);
};

JR.Tracker.Scene_Map_update = Scene_Map.prototype.update;
Scene_Map.prototype.update = function() {
    JR.Tracker.Scene_Map_update.call(this);
    var hasTracked = $gameSystem.getTrackedQuests().length > 0;
    var sceneValid = !$gameMap.isEventRunning() && !$gameMessage.isBusy() && !$gameParty.inBattle();
    // Allow opening/closing as long as there are tracked quests and scene is valid
    if (Input.isTriggered(JR.Param.ToggleKey) && hasTracked && sceneValid) {
        this._toggleButton.onClick();
    }
};

// Prevent map movement when clicking the toggle button
JR.Tracker.Scene_Map_processMapTouch = Scene_Map.prototype.processMapTouch;
Scene_Map.prototype.processMapTouch = function() {
    if (this._toggleButton && this._toggleButton.visible && this._toggleButton.isButtonTouched()) {
        return;
    }
    JR.Tracker.Scene_Map_processMapTouch.call(this);
};

//=============================================================================
// End of File
//=============================================================================