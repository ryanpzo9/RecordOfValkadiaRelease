/*:
 * @plugindesc v1.35 - Extension for JR_Bestiary. Full Bitmap Caching & Configurable Skill Spacing.
 * @author JR
 *
 * @param --- Popup Settings ---
 * 
 * @param Popup Width
 * @parent --- Popup Settings ---
 * @type number
 * @desc Width of the Analyze popup window.
 * @default 550
 *
 * @param Popup Height
 * @parent --- Popup Settings ---
 * @type number
 * @desc Height of the Analyze popup window.
 * @default 420
 *
 * @param Popup X
 * @parent --- Popup Settings ---
 * @desc X coordinate of the popup. You can use 'center' or formulas like 'center - 10'.
 * @default center
 *
 * @param Popup Y
 * @parent --- Popup Settings ---
 * @desc Y coordinate of the popup. You can use 'center' or formulas like 'center + 20'.
 * @default center
 *
 * @param Target Name Font Size
 * @parent --- Popup Settings ---
 * @type number
 * @desc Font size for the target enemy name in the popup. Default: 28
 * @default 28
 *
 * @param Target Name Color
 * @parent --- Popup Settings ---
 * @type number
 * @desc Text color index for the target's name. Default: 2 (Red)
 * @default 2
 *
 * @param Description Color
 * @parent --- Popup Settings ---
 * @type number
 * @desc Text color index for the description text. Default: 14 (Yellow)
 * @default 14
 * 
 * @param Name BG Image
 * @parent --- Popup Settings ---
 * @type file
 * @dir img/system/
 * @desc Custom background image for the target's name. Leave blank to use default.
 * @default
 *
 * @param Use Default Name Gradient
 * @parent --- Popup Settings ---
 * @type boolean
 * @on YES
 * @off NO
 * @desc Draw a dark gradient behind the name if no custom image is used?
 * @default true
 * 
 * @param Main Desc Font Size
 * @parent --- Popup Settings ---
 * @type number
 * @desc Global font size for the main 'descriptions' field. Default: 28
 * @default 28
 *
 * @param Main Desc Alignment
 * @parent --- Popup Settings ---
 * @type select
 * @option left
 * @option center
 * @option right
 * @desc Alignment for the main 'descriptions'. Note: center/right disables auto-WordWrap.
 * @default left
 *
 * @param Popup Name Spacing
 * @parent --- Popup Settings ---
 * @type number
 * @desc Space (in pixels) between the target name and the description/skills.
 * @default 5
 *
 * @param Popup Skill Spacing
 * @parent --- Popup Settings ---
 * @type number
 * @desc Space (in pixels) between the description block and the skill list.
 * @default 10
 * 
 * @param Bottom Safe Zone
 * @parent --- Popup Settings ---
 * @type number
 * @desc Safe padding (in pixels) added to the bottom of the popup so text doesn't overlap the OK button.
 * @default 40
 * 
 * @param Safe Zone When Not Scroll
 * @parent --- Popup Settings ---
 * @type boolean
 * @on True
 * @off False
 * @desc Apply the Bottom Safe Zone even when the content fits and doesn't naturally scroll?
 * @default true
 * 
 * @param Scroll Indicator Icon
 * @parent --- Popup Settings ---
 * @type number
 * @desc Icon index for the scroll indicator. Leave blank or 0 to use the default system arrow.
 * @default 0
 * 
 * @param Scroll Indicator Scale
 * @parent --- Popup Settings ---
 * @type number
 * @desc The scale percentage of the scroll indicator (100 = default size, 50 = half size).
 * @default 100
 * 
 * @param Scroll Indicator Effect
 * @parent --- Popup Settings ---
 * @type select
 * @option Breathe
 * @option Bounce
 * @option Pulse
 * @option Static
 * @desc The animation effect for the custom scroll indicator.
 * @default Breathe
 *
 * @param Scroll Indicator X
 * @parent --- Popup Settings ---
 * @desc X coordinate of the indicator. You can use 'center' or formulas like 'center - 10'.
 * @default center
 *
 * @param Scroll Indicator Y
 * @parent --- Popup Settings ---
 * @desc Y coordinate of the indicator. You can use 'center' or formulas like 'center + 10'.
 * @default center
 *
 * @param Custom Background Image
 * @parent --- Popup Settings ---
 * @type file
 * @dir img/system/
 * @desc Select the custom background image. Leave blank for default windowskin.
 * @default
 *
 * @param Enable OK Button
 * @parent --- Popup Settings ---
 * @type boolean
 * @on YES
 * @off NO
 * @desc Show the OK button? If false, the button is hidden and disabled.
 * @default true
 *
 * @param Custom OK Button Image
 * @parent --- Popup Settings ---
 * @type file
 * @dir img/system/
 * @desc Select the OK button image. Leave blank to draw default button.
 * @default
 * 
 * @param Button Scale
 * @parent --- Popup Settings ---
 * @type number
 * @desc The scale percentage of the OK button (100 = default size, 50 = half size).
 * @default 100
 *
 * @param Button Fill Color
 * @parent --- Popup Settings ---
 * @desc rgba color code for the default OK button. Default: rgba(0, 200, 0, 0.4)
 * @default rgba(0, 200, 0, 0.4)
 *
 * @param Button Base Font
 * @parent --- Popup Settings ---
 * @type number
 * @desc Font size for the default OK button. Default: 28
 * @default 28
 *
 * @param Button Line Height
 * @parent --- Popup Settings ---
 * @type number
 * @desc Base line height for the OK button. Default: 36
 * @default 36
 *
 * @param Button Text
 * @parent --- Popup Settings ---
 * @desc The text to display on the OK button. Leave blank for no text.
 * @default OK
 *
 * @param Button Text Color
 * @parent --- Popup Settings ---
 * @type number
 * @desc The text color index for the OK button. Default: 0 (White)
 * @default 0
 *
 * @param Button X
 * @parent --- Popup Settings ---
 * @desc Formula or preset for X coordinate. Presets: left, center, right. Variables: w, btnW.
 * @default center
 *
 * @param Button Y
 * @parent --- Popup Settings ---
 * @desc Formula or preset for Y coordinate. Presets: top, center, bottom. Variables: h, btnH.
 * @default h + 10
 *
 * @param Scroll Step
 * @parent --- Popup Settings ---
 * @type number
 * @desc Pixels to scroll per keyboard/wheel/drag tick. Default: 10
 * @default 10
 *
 * @param Close Delay
 * @parent --- Popup Settings ---
 * @type number
 * @desc Wait frames after clicking the OK button before closing. Default: 15
 * @default 15
 *
 * @param Iconset Columns
 * @parent --- Popup Settings ---
 * @type number
 * @desc The number of columns in your IconSet graphic. Default: 16
 * @default 16
 *
 * @param --- Skill Formatting ---
 *
 * @param Skill Name Font Size
 * @parent --- Skill Formatting ---
 * @type number
 * @desc Global font size for the skill name. Default: 28
 * @default 28
 *
 * @param Skill Desc Font Size
 * @parent --- Skill Formatting ---
 * @type number
 * @desc Global font size for the skill description. Default: 28
 * @default 28
 * 
 * @param Skill Vertical Spacing
 * @parent --- Skill Formatting ---
 * @type number
 * @desc Space (in pixels) between each skill item in the list.
 * @default 10
 *
 * @param --- No Data Settings ---
 *
 * @param No Data Text
 * @parent --- No Data Settings ---
 * @desc The text to display when no skill data is found.
 * @default No analytical data found.
 *
 * @param No Data Color
 * @parent --- No Data Settings ---
 * @type number
 * @desc The color index for the no data text. Default: 0
 * @default 0
 *
 * @param No Data Size
 * @parent --- No Data Settings ---
 * @type number
 * @desc The font size for the no data text. Default: 28
 * @default 28
 *
 * @param No Data X
 * @parent --- No Data Settings ---
 * @desc Formula for No Data X coordinate. Variables: w (popup width), textW (text width).
 * @default w / 2 - textW / 2
 *
 * @param No Data Y
 * @parent --- No Data Settings ---
 * @desc Formula for No Data Y coordinate. Variables: h (popup height), textH (text height).
 * @default h / 2 - textH / 2
 *
 * @param --- Bestiary Settings ---
 *
 * @param Abilities Label
 * @parent --- Bestiary Settings ---
 * @desc The label text for the Abilities section in the bestiary.
 * @default Abilities
 *
 * @param Abilities Color
 * @parent --- Bestiary Settings ---
 * @type number
 * @desc The color index for the Abilities label in the bestiary.
 * @default 14
 * 
 * @param Dash Color
 * @parent --- Bestiary Settings ---
 * @type number
 * @desc Text color index for the dash (-) before analyzed abilities. Set 0 for White.
 * @default 0
 *
 * @param Unknown Skill Text
 * @parent --- Bestiary Settings ---
 * @desc The text to display for skills when an enemy has not been analyzed yet.
 * @default ???
 * 
 * @param Stat Column Width Padding
 * @parent --- Bestiary Settings ---
 * @type number
 * @desc Padding subtracted when calculating Bestiary stat columns. Default: 20
 * @default 20
 *
 * @help
 * ============================================================================
 * Required Plugins & Load Order
 * ============================================================================
 * 1. YEP_MessageCore
 * 2. JR_Bestiary
 * 3. JR_Bestiary_AnalyzeExtension
 * 
 * ============================================================================
 * Usage Instructions & JSON Schema
 * ============================================================================
 * 1. Add the notetag <AnalyzeSkill> to any skill in the Database.
 * 2. Place 'AnalyzedSkillData.json' in your project's 'data/' folder.
 * 3. NO <WordWrap> tags are required in the JSON anymore. The plugin natively
 *    word wraps text automatically based on your window size.
 * 4. Add "icon": 123 to your JSON skill blocks to inject an icon.
 * 
 * Ensure your AnalyzedSkillData.json follows this format exactly:
 * [
 *   {
 *     "ID": 1,
 *     "descriptions": "A basic enemy description.",
 *     "skills": [
 *       { "order": 1, "icon": 123, "name": "Fire", "desc": "Deals fire damage" }
 *     ]
 *   }
 * ]
 * 
 * ============================================================================
 * Script Commands
 * ============================================================================
 * You can call these script commands inside Event script commands:
 * 
 * $gameSystem.unlockAllAnalyzeEntries();
 * - Instantly unlocks/reveals the Analyze status (Abilities and Elements) for 
 *   every enemy in the database.
 * 
 * $gameSystem.hideAllAnalyzeEntries();
 * - Resets all analyzed enemy data back to hidden/unrevealed (???).
 * 
 * Button Coordinates & Presets
 * ============================================================================
 * You can mix presets, mathematical formulas, and variables to place the 
 * OK button exactly where you want it inside the plugin parameters.
 * 
 * Variables:
 * - w : The width of the popup window.
 * - h : The height of the popup window.
 * - btnW : The width of the OK button.
 * - btnH : The height of the OK button.
 * 
 * Presets for Button X:
 * - left   : Snaps to the left border (0).
 * - center : Centers horizontally (w / 2 - btnW / 2).
 * - right  : Snaps to the right border (w - btnW).
 * 
 * Presets for Button Y:
 * - top    : Snaps to the top border (0).
 * - center : Centers vertically (h / 2 - btnH / 2).
 * - bottom : Snaps to the bottom border (h - btnH).
 * 
 * Examples:
 * "center"                 -> Centers the button on that axis.
 * "bottom - 10"            -> 10 pixels above the bottom border.
 * "right + btnW / 2"       -> Hangs exactly halfway off the right edge.
 * "h + 10"                 -> 10 pixels below the entire popup (Default).
 * 
 * ============================================================================
 * Changelog
 * ============================================================================
 * v1.35
 * - Added $gameSystem.unlockAllAnalyzeEntries() and $gameSystem.hideAllAnalyzeEntries()
 *   script calls to easily manage analyze progress globally.
 * v1.34
 * - Tied Bestiary Element display to Analyze status instead of location status.
 * v1.33
 * - Fixed boot crash when AnalyzedSkillData.json is missing by using custom
 *   XHR loading. The plugin now gracefully falls back if the file is absent.
 * v1.32
 * - Added 'Main Desc Font Size' and 'Main Desc Alignment' parameters to 
 *   globally control the styling of the main enemy description.
 * v1.31
 * - Added 'Enable OK Button' parameter to allow hiding the OK button entirely.
 * v1.30
 * - Fixed a case-sensitivity parsing bug that broke formula evaluations if  
 *   'btnW' or 'btnH' were used alongside preset anchor keywords.
 * v1.29
 * - Replaced button coordinate keywords with modular 'left', 'right', 'top', 
 *   'bottom', and 'center' anchors that dynamically support math formulas.
 * v1.28
 * - Separated OK and Cancel inputs explicitly to prevent sound overlaps.
 * - Added right-click (TouchInput.isCancelled) logic to close popups.
 * v1.27
 * - Fixed memory leak with dummy bitmaps (now uses 1x1 measurement pass).
 * - Added touch/drag scrolling for both the Popup and the Bestiary.
 * - Added 'tap outside' to close the Popup.
 * - Stabilized JSON loading against sparse arrays.
 * - Extracted previously hardcoded layout variables to Plugin Parameters.
 * - Switched prototype overrides to clean aliasing (requires updated JR_Bestiary).
 * 
 * ============================================================================
 */

var Imported = Imported || {};
Imported.JR_Bestiary_Analyze = true;

(function() {
    var parameters = PluginManager.parameters('JR_Bestiary_AnalyzeExtension');
    
    var popupWidth = Number(parameters['Popup Width'] || 550);
    var popupHeight = Number(parameters['Popup Height'] || 420);
    var popupX = String(parameters['Popup X'] || 'center');
    var popupY = String(parameters['Popup Y'] || 'center');
    
    var nameFontSize = Number(parameters['Target Name Font Size'] || 28);
    var targetNameColor = Number(parameters['Target Name Color'] || 2);
    var descColor = Number(parameters['Description Color'] || 14);
    var popupNameBgImg = String(parameters['Name BG Image'] || '').trim();
    var popupNameGradient = String(parameters['Use Default Name Gradient'] || 'true').toLowerCase() === 'true';
    
    var mainDescFontSize = Number(parameters['Main Desc Font Size'] || 28);
    var mainDescAlign = String(parameters['Main Desc Alignment'] || 'left').toLowerCase();
    
    var popupNameSpacing = Number(parameters['Popup Name Spacing'] || 5);
    var popupSkillSpacing = Number(parameters['Popup Skill Spacing'] || 10);
    var bottomSafeZone = Number(parameters['Bottom Safe Zone'] || 40);
    var safeZoneAlways = String(parameters['Safe Zone When Not Scroll'] || 'true').toLowerCase() === 'true';
    
    var scrollIndicatorIcon = Number(parameters['Scroll Indicator Icon'] || 0);
    var scrollIndicatorScale = Number(parameters['Scroll Indicator Scale'] || 100) / 100;
    var scrollIndicatorEffect = String(parameters['Scroll Indicator Effect'] || 'Breathe').toLowerCase();
    var scrollIndicatorX = String(parameters['Scroll Indicator X'] || 'center');
    var scrollIndicatorY = String(parameters['Scroll Indicator Y'] || 'center');
    
    var skillNameFontSize = Number(parameters['Skill Name Font Size'] || 28);
    var skillDescFontSize = Number(parameters['Skill Desc Font Size'] || 28);
    var skillVerticalSpacing = Number(parameters['Skill Vertical Spacing'] || 10);

    var customBgImg = String(parameters['Custom Background Image'] || '').trim();
    
    var enableOkButton = String(parameters['Enable OK Button'] || 'true').toLowerCase() === 'true';
    var customBtnImg = String(parameters['Custom OK Button Image'] || '').trim();
    var btnScaleParam = Number(parameters['Button Scale'] || 100) / 100;
    var btnFillColor = String(parameters['Button Fill Color'] || 'rgba(0, 200, 0, 0.4)');
    var btnBaseFont = Number(parameters['Button Base Font'] || 28);
    var btnLineHeight = Number(parameters['Button Line Height'] || 36);
    var btnTextStr = parameters['Button Text'] !== undefined ? String(parameters['Button Text']) : 'OK';
    var btnTextColor = Number(parameters['Button Text Color'] || 0);
    var btnXParam = String(parameters['Button X'] || 'center');
    var btnYParam = String(parameters['Button Y'] || 'h + 10');
    
    var scrollStep = Number(parameters['Scroll Step'] || 10);
    var closeDelay = Number(parameters['Close Delay'] || 15);
    var iconsetCols = Number(parameters['Iconset Columns'] || 16);
    var statColWidthPad = Number(parameters['Stat Column Width Padding'] || 20);

    var ndText = String(parameters['No Data Text'] || 'No analytical data found.');
    var ndColor = Number(parameters['No Data Color'] || 0);
    var ndSize = Number(parameters['No Data Size'] || 28);
    var ndXParam = String(parameters['No Data X'] || 'w / 2 - textW / 2');
    var ndYParam = String(parameters['No Data Y'] || 'h / 2 - textH / 2');

    var abilitiesLabel = String(parameters['Abilities Label'] || 'Abilities');
    var abilitiesColor = Number(parameters['Abilities Color'] || 14);
    var dashColor = Number(parameters['Dash Color'] || 0);
    var unknownSkillText = String(parameters['Unknown Skill Text'] || '???');

    var jrParams = PluginManager.parameters('JR_Bestiary');
    var locationLabel = String(jrParams['Location Label'] || 'Location');
    var parametersText = String(jrParams['Parameters Text'] || 'Parameters');
    var dropsLabel = String(jrParams['Drops Label'] || 'Drops');
    var elementLabel = String(jrParams['Element Label'] || 'Element');
    var showElement = (String(jrParams['Show Element'] || 'true').toLowerCase() === 'true');
    var noInformationText = String(jrParams['No Information Text'] || 'NO INFORMATION');
    var statLabels = [
        String(jrParams['Level Label'] || 'Level'),
        String(jrParams['Max HP Label'] || 'Max HP (MHP)'),
        String(jrParams['Max MP Label'] || 'Max MP (MMP)'),
        String(jrParams['Attack Label'] || 'Attack (ATK)'),
        String(jrParams['Defense Label'] || 'Defense (DEF)'),
        String(jrParams['M.Attack Label'] || 'M.Attack (MAT)'),
        String(jrParams['M.Defense Label'] || 'M.Defense (MDF)'),
        String(jrParams['Agility Label'] || 'Agility (AGI)'),
        String(jrParams['Luck Label'] || 'Luck (LUK)')
    ];
    
    var scrollWaitFrames = Number(jrParams['Scroll Wait Time'] || 3) * 60;
    var autoScrollFrames = Number(jrParams['Auto Scroll Time'] || 3) * 60;
    var autoScrollCoolFrames = Number(jrParams['Auto Scroll Cooldown'] || 3) * 60;

    //-----------------------------------------------------------------------------
    // Custom Lightweight Word Wrap Engine
    //-----------------------------------------------------------------------------
    Window_Base.prototype.jrTextWidth = function(text) {
        if (!text) return 0;
        
        var oldContents = this.contents;
        if (!this._jrDummyBitmap) this._jrDummyBitmap = new Bitmap(1, 1);
        this.contents = this._jrDummyBitmap;
        
        var oldDrawText = this.contents.drawText;
        var oldBlt = this.contents.blt;
        var oldFillRect = this.contents.fillRect;
        var oldGradientFillRect = this.contents.gradientFillRect;
        
        this.contents.drawText = function(){};
        this.contents.blt = function(){};
        this.contents.fillRect = function(){};
        this.contents.gradientFillRect = function(){};
        
        var textState = { index: 0, x: 0, y: 0, left: 0, text: this.convertEscapeCharacters(text) };
        this.resetFontSettings();
        
        while (textState.index < textState.text.length) {
            this.processCharacter(textState);
        }
        
        var width = textState.x;
        
        this.contents.drawText = oldDrawText;
        this.contents.blt = oldBlt;
        this.contents.fillRect = oldFillRect;
        this.contents.gradientFillRect = oldGradientFillRect;
        this.contents = oldContents;
        
        return width;
    };

    Window_Base.prototype.jrLightweightWordWrap = function(text, maxWidth) {
        this._wrapCache = this._wrapCache || {};
        var cacheKey = text + '|' + maxWidth;
        if (this._wrapCache[cacheKey]) return this._wrapCache[cacheKey];

        text = text.replace(/<WordWrap>/gi, '');
        text = text.replace(/<br>/gi, '\n'); // Strip <br> tags and convert to actual line breaks
        
        var textState = { index: 0, x: 0, y: 0, left: 0, text: this.convertEscapeCharacters(text) };
        var lastSpaceIndex = -1;
        
        var oldContents = this.contents;
        if (!this._jrDummyBitmap) this._jrDummyBitmap = new Bitmap(1, 1);
        this.contents = this._jrDummyBitmap;
        
        var oldDrawText = this.contents.drawText;
        var oldBlt = this.contents.blt;
        var oldFillRect = this.contents.fillRect;
        var oldGradientFillRect = this.contents.gradientFillRect;
        
        this.contents.drawText = function(){};
        this.contents.blt = function(){};
        this.contents.fillRect = function(){};
        this.contents.gradientFillRect = function(){};
        
        this.resetFontSettings();
        
        while (textState.index < textState.text.length) {
            var currentIndex = textState.index;
            var c = textState.text[textState.index];
            
            if (c === ' ') {
                lastSpaceIndex = currentIndex;
            } else if (c === '\n') {
                lastSpaceIndex = -1;
            }
            
            this.processCharacter(textState);
            
            if (textState.x > maxWidth && lastSpaceIndex !== -1) {
                var pre = textState.text.substring(0, lastSpaceIndex);
                var post = textState.text.substring(lastSpaceIndex + 1);
                textState.text = pre + '\n' + post;
                
                textState.index = lastSpaceIndex; // Point index to the newly created \n
                lastSpaceIndex = -1; 
            }
        }
        
        this.contents.drawText = oldDrawText;
        this.contents.blt = oldBlt;
        this.contents.fillRect = oldFillRect;
        this.contents.gradientFillRect = oldGradientFillRect;
        this.contents = oldContents;
        
        this._wrapCache[cacheKey] = textState.text;
        return textState.text;
    };

    // Measurement hook
    Window_Base.prototype.drawTextExAndGetHeight = function(text, x, y) {
        if (!text) return 0;
        
        var finalY = y;
        var finalH = 0;
        
        var oldProcessCharacter = this.processCharacter;
        this.processCharacter = function(textState) {
            oldProcessCharacter.call(this, textState);
            if (!this._checkWordWrapMode) {
                finalY = textState.y;
                finalH = textState.height;
            }
        };
        
        try {
            this.drawTextEx(text, x, y);
        } finally {
            this.processCharacter = oldProcessCharacter;
        }
        
        return (finalY - y) + finalH;
    };

    //-----------------------------------------------------------------------------
    // DataManager Load & Guaranteed Cache Mapping
    //-----------------------------------------------------------------------------
    var _DataManager_extractSaveContents = DataManager.extractSaveContents;
    DataManager.extractSaveContents = function(contents) {
        _DataManager_extractSaveContents.call(this, contents);
        if (!$gameSystem._analyzedEnemies) $gameSystem._analyzedEnemies = {};
    };

    var _DataManager_setupNewGame = DataManager.setupNewGame;
    DataManager.setupNewGame = function() {
        _DataManager_setupNewGame.call(this);
        $gameSystem._analyzedEnemies = {};
    };

    Game_System.prototype.setEnemyAnalyzed = function(enemyId) {
        if (!this._analyzedEnemies) this._analyzedEnemies = {};
        this._analyzedEnemies[enemyId] = true;
    };

    Game_System.prototype.isEnemyAnalyzed = function(enemyId) {
        return this._analyzedEnemies && this._analyzedEnemies[enemyId] === true;
    };

    Game_System.prototype.unlockAllAnalyzeEntries = function() {
        if (!this._analyzedEnemies) this._analyzedEnemies = {};
        for (var i = 1; i < $dataEnemies.length; i++) {
            if ($dataEnemies[i]) {
                this._analyzedEnemies[i] = true;
            }
        }
    };

    Game_System.prototype.hideAllAnalyzeEntries = function() {
        this._analyzedEnemies = {};
    };

    var _analyzeMap = null;
    window.$dataAnalyzeSkill = [];
    (function loadAnalyzeData() {
        var xhr = new XMLHttpRequest();
        var url = 'data/AnalyzedSkillData.json';
        xhr.open('GET', url);
        xhr.overrideMimeType('application/json');
        xhr.onload = function() {
            if (xhr.status < 400) {
                try {
                    window.$dataAnalyzeSkill = JSON.parse(xhr.responseText);
                    _analyzeMap = null; // Rebuild map on next access
                } catch (e) {
                    console.warn('JR_Bestiary_AnalyzeExtension: Invalid JSON in AnalyzedSkillData.json', e);
                }
            } else {
                console.warn('JR_Bestiary_AnalyzeExtension: AnalyzedSkillData.json not found. Safely ignoring.');
            }
        };
        xhr.onerror = function() {
            console.warn('JR_Bestiary_AnalyzeExtension: Could not load AnalyzedSkillData.json. Safely ignoring.');
        };
        xhr.send();
    })();

    function getAnalyzeData(enemyId) {
        if (!window.$dataAnalyzeSkill || window.$dataAnalyzeSkill.length === 0) return null;
        if (!_analyzeMap) {
            _analyzeMap = {};
            for (var i = 0; i < window.$dataAnalyzeSkill.length; i++) {
                var e = window.$dataAnalyzeSkill[i];
                if (e && e.ID !== undefined) _analyzeMap[String(e.ID)] = e;
            }
        }
        return _analyzeMap[String(enemyId)] || null;
    }

    //-----------------------------------------------------------------------------
    // Sprite_AnalyzeButton (External OK Button)
    //-----------------------------------------------------------------------------
    function Sprite_AnalyzeButton() {
        this.initialize.apply(this, arguments);
    }

    Sprite_AnalyzeButton.prototype = Object.create(Sprite.prototype);
    Sprite_AnalyzeButton.prototype.constructor = Sprite_AnalyzeButton;

    Sprite_AnalyzeButton.prototype.initialize = function(popupWindow) {
        Sprite.prototype.initialize.call(this);
        this._popupWindow = popupWindow;
        this.visible = false;
        this._closingTimer = 0;
        this._isBeingPressed = false;
        this._pressOffset = 0;
        this.createBitmap();
    };

    Sprite_AnalyzeButton.prototype.createBitmap = function() {
        var scaledLh = Math.round(btnLineHeight * btnScaleParam);
        var scaledFontSize = Math.round(btnBaseFont * btnScaleParam);
        var btnW = 0, btnH = 0;

        if (customBtnImg) {
            var bmp = ImageManager.loadSystem(customBtnImg);
            if (!bmp.isReady()) {
                bmp.addLoadListener(this.createBitmap.bind(this));
                return;
            }
            btnW = Math.round(bmp.width * btnScaleParam);
            btnH = Math.round(bmp.height * btnScaleParam);
            this.bitmap = new Bitmap(btnW, btnH);
            this.bitmap.blt(bmp, 0, 0, bmp.width, bmp.height, 0, 0, btnW, btnH);
        } else {
            var tempBmp = new Bitmap(1, 1);
            tempBmp.fontSize = scaledFontSize;
            var textPadding = btnTextStr !== "" ? Math.round(40 * btnScaleParam) : Math.round(10 * btnScaleParam);
            btnW = tempBmp.measureTextWidth(btnTextStr) + textPadding;
            btnH = scaledLh;
            this.bitmap = new Bitmap(btnW, btnH);
            this.bitmap.fillRect(0, 0, btnW, btnH, btnFillColor);
        }

        if (btnTextStr !== "") {
            this.bitmap.fontSize = scaledFontSize;
            this.bitmap.textColor = this._popupWindow.textColor(btnTextColor);
            var textY = (btnH - scaledLh) / 2;
            this.bitmap.drawText(btnTextStr, 0, textY, btnW, scaledLh, 'center');
        }

        var w = this._popupWindow.width;
        var h = this._popupWindow.height;
        
        // --- Parse X Presets (Case-Insensitive) ---
        var parsedX = btnXParam.trim();
        parsedX = parsedX.replace(/\bleft\b/gi, '(0)');
        parsedX = parsedX.replace(/\bcenter\b/gi, '(w / 2 - btnW / 2)');
        parsedX = parsedX.replace(/\bright\b/gi, '(w - btnW)');
        parsedX = parsedX.replace(/\bbtnw\b/gi, 'btnW');
        
        // --- Parse Y Presets (Case-Insensitive) ---
        var parsedY = btnYParam.trim();
        parsedY = parsedY.replace(/\btop\b/gi, '(0)');
        parsedY = parsedY.replace(/\bcenter\b/gi, '(h / 2 - btnH / 2)');
        parsedY = parsedY.replace(/\bbottom\b/gi, '(h - btnH)');
        parsedY = parsedY.replace(/\bbtnh\b/gi, 'btnH');
        
        // --- Evaluate Final Position ---
        try { this.x = this._popupWindow.x + eval(parsedX); } catch(e) { this.x = this._popupWindow.x + w / 2 - btnW / 2; }
        try { this.y = this._popupWindow.y + eval(parsedY); } catch(e) { this.y = this._popupWindow.y + h + 10; }
    };

    Sprite_AnalyzeButton.prototype.update = function() {
        Sprite.prototype.update.call(this);
        if (!this.visible) return;

        if (this._closingTimer > 0) {
            this._closingTimer--;
            if (this._closingTimer <= 0) {
                this._popupWindow.closePopup(true);
            }
            return;
        }

        if (TouchInput.isTriggered() && this.isButtonTouched()) {
            this._isBeingPressed = true;
            this.opacity = 200; 
        }

        if (this._isBeingPressed) {
            if (TouchInput.isReleased()) {
                this._isBeingPressed = false;
                if (this.isButtonTouched()) {
                    this.triggerClick();
                } else {
                    this.opacity = 255; 
                }
            } else if (!TouchInput.isPressed()) {
                this._isBeingPressed = false;
                this.opacity = 255;
            }
        }
    };

    Sprite_AnalyzeButton.prototype.isButtonTouched = function() {
        var tx = TouchInput.x;
        var ty = TouchInput.y;
        var actualW = this.width * this.scale.x;
        var actualH = this.height * this.scale.y;
        return tx >= this.x && tx <= this.x + actualW && ty >= this.y && ty <= this.y + actualH;
    };

    Sprite_AnalyzeButton.prototype.triggerClick = function() {
        if (this._closingTimer > 0) return;
        SoundManager.playOk();
        this._pressOffset = 2;
        this.y += this._pressOffset; 
        this.opacity = 150; 
        this._closingTimer = closeDelay; 
    };

    //-----------------------------------------------------------------------------
    // Window_AnalyzePopup
    //-----------------------------------------------------------------------------
    function Window_AnalyzePopup() {
        this.initialize.apply(this, arguments);
    }

    Window_AnalyzePopup.prototype = Object.create(Window_Base.prototype);
    Window_AnalyzePopup.prototype.constructor = Window_AnalyzePopup;

    Window_AnalyzePopup.prototype.initialize = function() {
        var centerX = (Graphics.boxWidth - popupWidth) / 2;
        var centerY = (Graphics.boxHeight - popupHeight) / 2;
        
        var finalX = centerX;
        try { finalX = eval(popupX.toLowerCase().replace(/center/g, centerX)); } catch (e) { finalX = Number(popupX) || centerX; }
        
        var finalY = centerY;
        try { finalY = eval(popupY.toLowerCase().replace(/center/g, centerY)); } catch (e) { finalY = Number(popupY) || centerY; }

        Window_Base.prototype.initialize.call(this, finalX, finalY, popupWidth, popupHeight);
        
        if (customBgImg) {
            this.opacity = 0; 
            this._customBgSprite = new Sprite();
            var bgBitmap = ImageManager.loadSystem(customBgImg);
            this._customBgSprite.bitmap = bgBitmap;
            this.addChildToBack(this._customBgSprite);
        }
        
        if (popupNameBgImg) {
            ImageManager.loadSystem(popupNameBgImg);
        }

        ImageManager.loadSystem('IconSet');
        
        this._enemyId = null;
        this._analyzeScrollY = 0;
        this._contentHeight = popupHeight;
        
        if (scrollIndicatorIcon > 0) {
            this._customArrowSprite = new Sprite();
            this.addChild(this._customArrowSprite);
            this._customArrowSprite.bitmap = new Bitmap(Window_Base._iconWidth, Window_Base._iconHeight);
            
            var iconset = ImageManager.loadSystem('IconSet');
            var pw = Window_Base._iconWidth;
            var ph = Window_Base._iconHeight;
            var sx = scrollIndicatorIcon % iconsetCols * pw;
            var sy = Math.floor(scrollIndicatorIcon / iconsetCols) * ph;
            
            var that = this;
            iconset.addLoadListener(function() {
                that._customArrowSprite.bitmap.blt(iconset, sx, sy, pw, ph, 0, 0);
            });
            
            this._customArrowSprite.scale.x = scrollIndicatorScale;
            this._customArrowSprite.scale.y = scrollIndicatorScale;
            
            var w = this.width;
            var h = this.height;
            var scaledPw = pw * scrollIndicatorScale;
            var scaledPh = ph * scrollIndicatorScale;
            
            var indCenterX = w / 2 - scaledPw / 2;
            var indCenterY = h - scaledPh - 6;

            var finalIndX = indCenterX;
            try { finalIndX = eval(scrollIndicatorX.toLowerCase().replace(/center/g, indCenterX)); } catch (e) { finalIndX = Number(scrollIndicatorX) || indCenterX; }

            var finalIndY = indCenterY;
            try { finalIndY = eval(scrollIndicatorY.toLowerCase().replace(/center/g, indCenterY)); } catch (e) { finalIndY = Number(scrollIndicatorY) || indCenterY; }
            
            this._customArrowSprite.x = finalIndX;
            this._customArrowBaseY = finalIndY; 
            this._customArrowSprite.y = this._customArrowBaseY;
            this._customArrowSprite.visible = false;
            this._customArrowTimer = 0;
        }

        this.hide();
        this.deactivate();
    };

    Window_AnalyzePopup.prototype.setButtonSprite = function(sprite) {
        this._btnSprite = sprite;
    };

    Window_AnalyzePopup.prototype.setup = function(enemyId) {
        this._enemyId = enemyId;
        this._analyzeScrollY = 0;
        this.origin.y = 0;
        if (this._btnSprite) {
            if (this._btnSprite._pressOffset) {
                this._btnSprite.y -= this._btnSprite._pressOffset;
                this._btnSprite._pressOffset = 0;
            }
            this._btnSprite.opacity = 255;
            this._btnSprite.visible = true;
        }
        this.refresh();
        this.show();
        this.activate();
    };

    Window_AnalyzePopup.prototype.refresh = function() {
        if (!this._enemyId) {
            if (this.contents) this.contents.clear();
            return;
        }

        if (!this._dummyBitmap) this._dummyBitmap = new Bitmap(1, 1);
        
        var oldContents = this.contents;
        this.contents = this._dummyBitmap;

        var oldDrawText = this.contents.drawText;
        var oldBlt = this.contents.blt;
        var oldFillRect = this.contents.fillRect;
        var oldGradientFillRect = this.contents.gradientFillRect;
        
        this.contents.drawText = function(){};
        this.contents.blt = function(){};
        this.contents.fillRect = function(){};
        this.contents.gradientFillRect = function(){};
        
        try {
            this._isMockPass = true;
            this.drawPopupContent(); 
        } finally {
            this.contents.drawText = oldDrawText;
            this.contents.blt = oldBlt;
            this.contents.fillRect = oldFillRect;
            this.contents.gradientFillRect = oldGradientFillRect;
            this.contents = oldContents;
            this._isMockPass = false;
        }
        
        var minH = this.height - this.standardPadding() * 2;
        var finalHeight = Math.max(minH, this._contentHeight);
        
        if (!this._realBitmap || this._realBitmap.height < finalHeight || this._realBitmap.width !== this.contentsWidth()) {
            this._realBitmap = new Bitmap(this.contentsWidth(), finalHeight);
        } else {
            this._realBitmap.clear();
        }
        
        this.contents = this._realBitmap;
        this.drawPopupContent();
    };

    Window_AnalyzePopup.prototype.drawPopupContent = function() {
        this.contents.clear();
        if (!this._enemyId) return;

        var w = this.contentsWidth();
        var lh = this.lineHeight();
        var enemy = $dataEnemies[this._enemyId];
        var data = getAnalyzeData(this._enemyId);
        
        var y = 10;

        if (popupNameBgImg) {
            var nBmp = ImageManager.loadSystem(popupNameBgImg);
            if (nBmp.isReady()) {
                var nx = (w - nBmp.width) / 2;
                var ny = y + (nameFontSize - nBmp.height) / 2 + 5; 
                this.contents.blt(nBmp, 0, 0, nBmp.width, nBmp.height, nx, ny);
            }
        } else if (popupNameGradient) {
            var gy = y + 2;
            var gh = nameFontSize + 6;
            this.contents.gradientFillRect(0, gy, w / 2, gh, 'rgba(0,0,0,0)', 'rgba(0,0,0,0.6)');
            this.contents.gradientFillRect(w / 2, gy, w / 2, gh, 'rgba(0,0,0,0.6)', 'rgba(0,0,0,0)');
        }

        var nameText = '\\FS[' + nameFontSize + ']\\C[' + targetNameColor + ']' + (enemy ? enemy.name : '') + '\\C[0]';
        var nameWidth = this.jrTextWidth(nameText);
        this.drawTextEx(nameText, (w - nameWidth) / 2, y);
        this.resetFontSettings();
        y += nameFontSize + popupNameSpacing;

        if (data && (data.descriptions || (data.skills && data.skills.length > 0))) {
            if (data.descriptions && data.descriptions.trim() !== '') {
                var descRaw = data.descriptions.trim();
                
                if (mainDescAlign === 'center' || mainDescAlign === 'right') {
                    var lines = descRaw.split(/<br>|\n/gi);
                    for (var l = 0; l < lines.length; l++) {
                        var lineRaw = lines[l].replace(/<WordWrap>/gi, ''); 
                        var lineText = '\\FS[' + mainDescFontSize + ']\\C[' + descColor + ']' + lineRaw + '\\C[0]';
                        var tw = this.jrTextWidth(lineText);
                        var tx = 10;
                        
                        if (mainDescAlign === 'center') tx = (w - tw) / 2;
                        if (mainDescAlign === 'right') tx = w - tw - 10;
                        
                        var lineH = this.drawTextExAndGetHeight(lineText, tx, y);
                        y += (lineH > 0 ? lineH : lh);
                    }
                    y += popupSkillSpacing;
                } else {
                    var descText = '\\FS[' + mainDescFontSize + ']\\C[' + descColor + ']' + descRaw + '\\C[0]';
                    descText = this.jrLightweightWordWrap(descText, w - 20);
                    var lineH = this.drawTextExAndGetHeight(descText, 10, y);
                    y += lineH + popupSkillSpacing; 
                }
            } else {
                y += popupSkillSpacing; 
            }

            if (data.skills && data.skills.length > 0) {
                var skills = data.skills.slice().sort(function(a, b) { return (a.order || 0) - (b.order || 0); });
                for (var i = 0; i < skills.length; i++) {
                    var skill = skills[i];
                    var iconCode = (skill.icon && skill.icon > 0) ? '\\I[' + skill.icon + ']' : '';
                    var skillText = iconCode + '\\FS[' + skillNameFontSize + ']\\C[' + descColor + ']' + skill.name + ':\\FS[' + skillDescFontSize + ']\\C[0] ' + skill.desc;
                    skillText = this.jrLightweightWordWrap(skillText, w - 20);
                    var skillLineH = this.drawTextExAndGetHeight(skillText, 10, y);
                    y += skillLineH + skillVerticalSpacing;
                }
            }
        } else {
            var h = this.contentsHeight(); 
            this.contents.fontSize = ndSize;
            var textW = this.textWidth(ndText);
            var textH = ndSize;
            var ndX = 0, ndY = 0;
            
            try { ndX = eval(ndXParam); } catch (e) { ndX = (w - textW) / 2; }
            try { ndY = eval(ndYParam); } catch (e) { ndY = (h - textH) / 2; }

            this.changeTextColor(this.textColor(ndColor));
            this.drawText(ndText, ndX, ndY, textW, 'left');
            this.resetTextColor();
            this.resetFontSettings();
            
            y += lh;
        }

        var minH = this.height - this.standardPadding() * 2;
        if (safeZoneAlways) {
            this._contentHeight = y + bottomSafeZone;
        } else {
            if (y > minH) {
                this._contentHeight = y + bottomSafeZone;
            } else {
                this._contentHeight = y;
            }
        }
    };

    Window_AnalyzePopup.prototype.update = function() {
        Window_Base.prototype.update.call(this);
        
        if (this._customBgSprite && this._customBgSprite.bitmap && this._customBgSprite.bitmap.isReady()) {
            this._customBgSprite.scale.x = this.width / this._customBgSprite.bitmap.width;
            this._customBgSprite.scale.y = this.height / this._customBgSprite.bitmap.height;
        }

        if (this.active) {
            this.updateInput();
            this.updateScroll();
        }
    };

    Window_AnalyzePopup.prototype.isTouchedInsideFrame = function() {
        var tx = TouchInput.x;
        var ty = TouchInput.y;
        return tx >= this.x && tx <= this.x + this.width && ty >= this.y && ty <= this.y + this.height;
    };

    Window_AnalyzePopup.prototype.updateInput = function() {
        if (Input.isTriggered('cancel') || TouchInput.isCancelled()) {
            SoundManager.playCancel();
            this.closePopup();
        } else if (Input.isTriggered('ok')) {
            if (this._btnSprite && this._btnSprite.visible) {
                this._btnSprite.triggerClick();
            } else {
                SoundManager.playOk();
                this.closePopup();
            }
        } else if (TouchInput.isTriggered() && !this.isTouchedInsideFrame()) {
            SoundManager.playCancel();
            this.closePopup();
        }
    };

    Window_AnalyzePopup.prototype.updateScroll = function() {
        var maxScroll = Math.max(0, this._contentHeight - this.contentsHeight());
        
        if (scrollIndicatorIcon > 0) {
            var showArrow = (maxScroll > 0 && this._analyzeScrollY < maxScroll);
            this._customArrowSprite.visible = showArrow;
            if (showArrow) {
                this._customArrowTimer++;
                var t = this._customArrowTimer;
                
                if (scrollIndicatorEffect === 'bounce') {
                    this._customArrowSprite.y = this._customArrowBaseY + Math.sin(t * 0.1) * 3;
                    this._customArrowSprite.opacity = 255;
                } else if (scrollIndicatorEffect === 'pulse') {
                    this._customArrowSprite.y = this._customArrowBaseY + Math.sin(t * 0.1) * 3;
                    this._customArrowSprite.opacity = 191 + Math.sin(t * 0.05) * 64;
                } else if (scrollIndicatorEffect === 'static') {
                    this._customArrowSprite.y = this._customArrowBaseY;
                    this._customArrowSprite.opacity = 255;
                } else { 
                    this._customArrowSprite.y = this._customArrowBaseY;
                    this._customArrowSprite.opacity = 191 + Math.sin(t * 0.05) * 64;
                }
            }
        } else {
            this.downArrowVisible = (maxScroll > 0 && this._analyzeScrollY < maxScroll);
        }

        if (maxScroll > 0) {
            if (Input.isPressed('down')) {
                this._analyzeScrollY = Math.min(maxScroll, this._analyzeScrollY + scrollStep);
                this.origin.y = this._analyzeScrollY; 
            } else if (Input.isPressed('up')) {
                this._analyzeScrollY = Math.max(0, this._analyzeScrollY - scrollStep);
                this.origin.y = this._analyzeScrollY; 
            } else if (TouchInput.wheelY !== 0) {
                this._analyzeScrollY = Math.max(0, Math.min(maxScroll, this._analyzeScrollY + TouchInput.wheelY));
                this.origin.y = this._analyzeScrollY; 
            }
            if (TouchInput.isPressed() && this.isTouchedInsideFrame()) {
                if (this._lastTouchY === undefined) this._lastTouchY = TouchInput.y;
                var dy = this._lastTouchY - TouchInput.y;
                this._analyzeScrollY = Math.max(0, Math.min(maxScroll, this._analyzeScrollY + dy));
                this.origin.y = this._analyzeScrollY;
                this._lastTouchY = TouchInput.y;
            } else {
                this._lastTouchY = undefined;
            }
        }
    };

    Window_AnalyzePopup.prototype.closePopup = function(skipSound) {
        if (!skipSound) SoundManager.playCancel(); 
        this.deactivate();
        this.hide();
        if (this._btnSprite) this._btnSprite.visible = false;
        this._enemyId = null;
    };

    //-----------------------------------------------------------------------------
    // Scene_Battle Integration
    //-----------------------------------------------------------------------------
    var _Scene_Battle_createAllWindows = Scene_Battle.prototype.createAllWindows;
    Scene_Battle.prototype.createAllWindows = function() {
        _Scene_Battle_createAllWindows.call(this);
        
        this._analyzeWindow = new Window_AnalyzePopup();
        this.addChild(this._analyzeWindow);
        
        if (enableOkButton) {
            this._analyzeBtnSprite = new Sprite_AnalyzeButton(this._analyzeWindow);
            this.addChild(this._analyzeBtnSprite);
            this._analyzeWindow.setButtonSprite(this._analyzeBtnSprite);
        }
    };

    var _Scene_Battle_update = Scene_Battle.prototype.update;
    Scene_Battle.prototype.update = function() {
        if (this._analyzeWindow && this._analyzeWindow.active) {
            this._analyzePopupActive = true;
            $gameScreen.update(); 
            Scene_Base.prototype.update.call(this); 
            return; 
        }
        this._analyzePopupActive = false;
        _Scene_Battle_update.call(this);
    };

    var _BattleManager_invokeAction = BattleManager.invokeAction;
    BattleManager.invokeAction = function(subject, target) {
        _BattleManager_invokeAction.call(this, subject, target);
        if (this._action && this._action.item()) {
            var item = this._action.item();
            if (item.note && item.note.match(/<AnalyzeSkill>/i) && target.isEnemy()) {
                $gameSystem.setEnemyAnalyzed(target.enemyId());
                if (SceneManager._scene instanceof Scene_Battle) {
                    SceneManager._scene._analyzeWindow.setup(target.enemyId());
                }
            }
        }
    };

    //-----------------------------------------------------------------------------
    // Clean Extension of Window_BestiaryStatus using Globals from JR_Bestiary v2.26
    //-----------------------------------------------------------------------------
    if (window.Window_BestiaryStatus) {

        var _Window_BestiaryStatus_initialize = Window_BestiaryStatus.prototype.initialize;
        Window_BestiaryStatus.prototype.initialize = function(x, y, width, height) {
            _Window_BestiaryStatus_initialize.call(this, x, y, width, height);

            if (scrollIndicatorIcon > 0) {
                this._customArrowSprite = new Sprite();
                this.addChild(this._customArrowSprite);
                this._customArrowSprite.bitmap = new Bitmap(Window_Base._iconWidth, Window_Base._iconHeight);
                
                var iconset = ImageManager.loadSystem('IconSet');
                var pw = Window_Base._iconWidth;
                var ph = Window_Base._iconHeight;
                var sx = scrollIndicatorIcon % iconsetCols * pw;
                var sy = Math.floor(scrollIndicatorIcon / iconsetCols) * ph;
                
                var that = this;
                iconset.addLoadListener(function() {
                    that._customArrowSprite.bitmap.blt(iconset, sx, sy, pw, ph, 0, 0);
                });
                
                this._customArrowSprite.scale.x = scrollIndicatorScale;
                this._customArrowSprite.scale.y = scrollIndicatorScale;
                
                var w = this.width;
                var h = this.height;
                var scaledPw = pw * scrollIndicatorScale;
                var scaledPh = ph * scrollIndicatorScale;
                
                var indCenterX = w / 2 - scaledPw / 2;
                var indCenterY = h - scaledPh - 6;

                var finalIndX = indCenterX;
                try { finalIndX = eval(scrollIndicatorX.toLowerCase().replace(/center/g, indCenterX)); } catch (e) { finalIndX = Number(scrollIndicatorX) || indCenterX; }

                var finalIndY = indCenterY;
                try { finalIndY = eval(scrollIndicatorY.toLowerCase().replace(/center/g, indCenterY)); } catch (e) { finalIndY = Number(scrollIndicatorY) || indCenterY; }
                
                this._customArrowSprite.x = finalIndX;
                this._customArrowBaseY = finalIndY; 
                this._customArrowSprite.y = this._customArrowBaseY;
                this._customArrowSprite.visible = false;
                this._customArrowTimer = 0;
            }
        };

        var _Window_BestiaryStatus_refresh = Window_BestiaryStatus.prototype.refresh;
        Window_BestiaryStatus.prototype.refresh = function() {
            if (this._scrollY === 0) this.origin.y = 0;
            
            if (this._enemy) {
                var enemyId = this._enemy.id;
                this._enemyBitmapCache = this._enemyBitmapCache || {};
                this._contentHeightCache = this._contentHeightCache || {};

                // 1. INSTANT CACHE LOAD: Zero CPU parsing.
                if (this._enemyBitmapCache[enemyId] && this._enemyBitmapCache[enemyId].isReady()) {
                    this.contents = this._enemyBitmapCache[enemyId];
                    this._dynamicContentHeight = this._contentHeightCache[enemyId];
                    return;
                }

                // 2. MOCK PASS
                if (!this._dummyBitmap) this._dummyBitmap = new Bitmap(1, 1);
                var oldContents = this.contents;
                
                this.contents = this._dummyBitmap;
                var oldDrawText = this.contents.drawText;
                var oldBlt = this.contents.blt;
                var oldFillRect = this.contents.fillRect;
                var oldGradientFillRect = this.contents.gradientFillRect;
                
                this.contents.drawText = function(){};
                this.contents.blt = function(){};
                this.contents.fillRect = function(){};
                this.contents.gradientFillRect = function(){};
                
                try {
                    this._isMockPass = true;
                    this.drawContent(true); 
                } finally {
                    this.contents.drawText = oldDrawText;
                    this.contents.blt = oldBlt;
                    this.contents.fillRect = oldFillRect;
                    this.contents.gradientFillRect = oldGradientFillRect;
                    this.contents = oldContents;
                    this._isMockPass = false;
                }
                
                // 3. RENDER PASS
                var minH = this.height - this.standardPadding() * 2;
                var finalHeight = Math.max(minH, this._dynamicContentHeight || minH);
                
                // CREATE NEW BITMAP INSTEAD OF REUSING ONE TO PRESERVE THE CACHE
                var realBmp = new Bitmap(this.contentsWidth(), finalHeight);
                this.contents = realBmp;
                this.drawContent(false);

                // 4. SAVE TO CACHE
                this._enemyBitmapCache[enemyId] = realBmp;
                this._contentHeightCache[enemyId] = this._dynamicContentHeight;

            } else {
                if (!this._realBitmap) this._realBitmap = new Bitmap(this.contentsWidth(), this.contentsHeight());
                else this._realBitmap.clear();
                this.contents = this._realBitmap;
                this.drawContent(false);
            }
        };

        // Prevent native engine from forcibly resetting scroll coordinates
        Window_BestiaryStatus.prototype.processCursorMove = function() {};
        Window_BestiaryStatus.prototype.processWheel = function() {};
        Window_BestiaryStatus.prototype.ensureCursorVisible = function() {};

        Window_BestiaryStatus.prototype.update = function() {
            Window_Selectable.prototype.update.call(this);

            if (this._wasActive && !this.active) {
                this._autoScroll = true; 
                this._scrollY = 0; 
                this._scrollTimer = 0;
                this._scrollPhase = 0; 
                this.origin.y = 0;
            }
            this._wasActive = this.active; 

            var maxScroll = this.maxScrollY();

            if (scrollIndicatorIcon > 0 && this._customArrowSprite) {
                var showArrow = (maxScroll > 0 && this._scrollY < maxScroll);
                this._customArrowSprite.visible = showArrow;
                if (showArrow) {
                    this._customArrowTimer++;
                    var t = this._customArrowTimer;
                    
                    if (scrollIndicatorEffect === 'bounce') {
                        this._customArrowSprite.y = this._customArrowBaseY + Math.sin(t * 0.1) * 3;
                        this._customArrowSprite.opacity = 255;
                    } else if (scrollIndicatorEffect === 'pulse') {
                        this._customArrowSprite.y = this._customArrowBaseY + Math.sin(t * 0.1) * 3;
                        this._customArrowSprite.opacity = 191 + Math.sin(t * 0.05) * 64;
                    } else if (scrollIndicatorEffect === 'static') {
                        this._customArrowSprite.y = this._customArrowBaseY;
                        this._customArrowSprite.opacity = 255;
                    } else { 
                        this._customArrowSprite.y = this._customArrowBaseY;
                        this._customArrowSprite.opacity = 191 + Math.sin(t * 0.05) * 64;
                    }
                }
            } else {
                this.downArrowVisible = (maxScroll > 0 && this._scrollY < maxScroll);
            }

            if (!this.active && this._autoScroll) {
                if (maxScroll > 0) {
                    this._scrollTimer++;
                    if (this._scrollPhase === 0) {
                        if (this._scrollTimer >= scrollWaitFrames) {
                            this._scrollPhase = 1; 
                            this._scrollTimer = 0;
                        }
                    } else if (this._scrollPhase === 1) {
                        var progress = this._scrollTimer / autoScrollFrames;
                        this._scrollY = Math.min(maxScroll, progress * maxScroll);
                        this.origin.y = this._scrollY; 
                        if (this._scrollTimer >= autoScrollFrames) {
                            this._scrollPhase = 2; 
                            this._scrollTimer = 0;
                        }
                    } else if (this._scrollPhase === 2) {
                        if (this._scrollTimer >= autoScrollCoolFrames) {
                            this._scrollPhase = 3; 
                            this._scrollTimer = 0;
                        }
                    } else if (this._scrollPhase === 3) {
                        var progress = this._scrollTimer / autoScrollFrames;
                        this._scrollY = Math.max(0, maxScroll * (1 - progress));
                        this.origin.y = this._scrollY; 
                        if (this._scrollTimer >= autoScrollFrames) {
                            this._scrollPhase = 0; 
                            this._scrollTimer = 0;
                        }
                    }
                }
            }

            if (this.active) {
                this._autoScroll = false; 
                if (Input.isPressed('down') && this._scrollY < maxScroll) {
                    this._scrollY = Math.min(maxScroll, this._scrollY + scrollStep);
                    this.origin.y = this._scrollY; 
                } else if (Input.isPressed('up') && this._scrollY > 0) {
                    this._scrollY = Math.max(0, this._scrollY - scrollStep);
                    this.origin.y = this._scrollY; 
                } else if (TouchInput.wheelY !== 0) {
                    this._scrollY = Math.max(0, Math.min(maxScroll, this._scrollY + TouchInput.wheelY));
                    this.origin.y = this._scrollY; 
                }

                if (TouchInput.isPressed() && this.isTouchedInsideFrame()) {
                    if (this._lastTouchY === undefined) this._lastTouchY = TouchInput.y;
                    var dy = this._lastTouchY - TouchInput.y;
                    this._scrollY = Math.max(0, Math.min(maxScroll, this._scrollY + dy));
                    this.origin.y = this._scrollY;
                    this._lastTouchY = TouchInput.y;
                } else {
                    this._lastTouchY = undefined;
                }
            }
        };

        Window_BestiaryStatus.prototype.isTouchedInsideFrame = function() {
            var tx = TouchInput.x;
            var ty = TouchInput.y;
            return tx >= this.x && tx <= this.x + this.width && ty >= this.y && ty <= this.y + this.height;
        };

        Window_BestiaryStatus.prototype.maxScrollY = function() {
            var minH = this.height - this.standardPadding() * 2;
            return Math.max(0, (this._dynamicContentHeight || 0) - minH);
        };

        Window_BestiaryStatus.prototype.drawContent = function(isMock) {
            this.contents.clear();
            if (!this._enemy) return;

            var enemyData = Bestiary.getEnemyData(this._enemy);
            var x = this.standardPadding();
            var y = 0; 
            var lineHeight = this.lineHeight();
            var centerX = (this.contentsWidth()) / 2;
            var statColumnWidth = (this.contentsWidth() - this.standardPadding() * statColWidthPad) / 3;
            var locationKnown = $gameSystem._bestiaryEncountered && $gameSystem._bestiaryEncountered[this._enemy.id];

            if (locationKnown) {
                var gameEnemy = new Game_Enemy(this._enemy.id, 0, 0);
                if (gameEnemy.hasSVBattler()) {
                    var filename = gameEnemy.svBattlerName();
                    var bitmap = ImageManager.loadSvActor(filename, 0);
                    if (bitmap.isReady()) {
                        var frameWidth = bitmap.width / 9;
                        var frameHeight = bitmap.height / 6;
                        this.contents.blt(bitmap, 0, 0, frameWidth, frameHeight, centerX - frameWidth / 2, y, frameWidth, frameHeight);
                        y += frameHeight + lineHeight;
                    } else if (!isMock) {
                        var self = this;
                        var currentEnemyId = this._enemy.id;
                        bitmap.addLoadListener(function() { 
                            if (self._enemyBitmapCache) {
                                self._enemyBitmapCache[currentEnemyId] = null; // invalidate cache
                            }
                            if (self._enemy && self._enemy.id === currentEnemyId) {
                                self.refresh(); 
                            }
                        });
                        this.drawText('Loading...', centerX - this.textWidth('Loading...') / 2, y, this.contentsWidth(), 'center');
                        y += lineHeight * 2;
                    } else {
                        y += lineHeight * 2; 
                    }
                } else {
                    this.drawText(noInformationText, 0, y, this.contentsWidth(), 'center');
                    y += lineHeight * 2;
                }
            } else {
                this.drawText(noInformationText, 0, y, this.contentsWidth(), 'center');
                y += lineHeight * 2;
            }

            this.changeTextColor(this.textColor(29));
            this.drawText(locationLabel + ": " + (locationKnown ? enemyData.location : "???"), 0, y, this.contentsWidth(), 'center');
            y += lineHeight;
            this.changeTextColor(this.normalColor());

            if (showElement) {
                var isAnalyzed = $gameSystem.isEnemyAnalyzed(this._enemy.id);
                if (isAnalyzed) {
                    var elementText = elementLabel + ': ' + (enemyData.elements.length > 0 ? enemyData.elements.join(', ') : '—');
                    this.changeTextColor(this.textColor(6)); 
                    this.drawText(elementText, 0, y, this.contentsWidth(), 'center');
                } else {
                    this.changeTextColor(this.textColor(6));
                    this.drawText(elementLabel + ': ???', 0, y, this.contentsWidth(), 'center');
                }
                y += lineHeight * 2;
                this.changeTextColor(this.normalColor());
            }

            this.changeTextColor(this.systemColor());
            this.drawText(parametersText, 0, y, this.contentsWidth(), 'center');
            this.changeTextColor(this.normalColor());
            y += lineHeight;

            if (locationKnown) {
                var levelRange = this._params[0] || { min: 1, max: 1 };
                this.changeTextColor(this.textColor(20));
                this.drawText(statLabels[0] + ': ' + (levelRange.min === levelRange.max ? levelRange.min : levelRange.min + ' - ' + levelRange.max), 0, y, this.contentsWidth(), 'center');
                y += lineHeight;
                this.changeTextColor(this.normalColor());

                for (var i = 1; i < statLabels.length; i++) {
                    var p = this._params[i] || { min: 0, max: 0 };
                    var val = p.min === p.max ? p.min.toString() : p.min + ' - ' + p.max;
                    var rx = centerX - statColumnWidth;
                    this.changeTextColor(this.systemColor());
                    this.drawText(statLabels[i], rx, y, statColumnWidth, 'left');
                    this.changeTextColor(this.normalColor());
                    this.drawText(val, rx + statColumnWidth, y, statColumnWidth, 'right');
                    y += lineHeight;
                }
            } else {
                this.changeTextColor(this.textColor(20));
                this.drawText(statLabels[0] + ': ??? - ???', 0, y, this.contentsWidth(), 'center');
                y += lineHeight;
                this.changeTextColor(this.normalColor());
                for (var i = 1; i < statLabels.length; i++) {
                    var rx = centerX - statColumnWidth;
                    this.changeTextColor(this.systemColor());
                    this.drawText(statLabels[i], rx, y, statColumnWidth, 'left');
                    this.changeTextColor(this.normalColor());
                    this.drawText('??? - ???', rx + statColumnWidth, y, statColumnWidth, 'right');
                    y += lineHeight;
                }
            }

            // ===============================================
            // Injection: Abilities Section (Name & Desc)
            // ===============================================
            y += lineHeight;
            this.changeTextColor(this.textColor(abilitiesColor));
            this.drawText(abilitiesLabel + ':', x, y, this.contentsWidth(), 'left');
            this.changeTextColor(this.normalColor());
            y += lineHeight;

            var analyzedData = getAnalyzeData(this._enemy.id);
            if ($gameSystem.isEnemyAnalyzed(this._enemy.id) && analyzedData && analyzedData.skills) {
                var sortedSkills = analyzedData.skills.slice().sort(function(a, b) { return (a.order || 0) - (b.order || 0); });
                var maxW = this.contentsWidth() - (x + 20) - 10;
                
                for (var s = 0; s < sortedSkills.length; s++) {
                    var skillObj = sortedSkills[s];
                    var iconCode = (skillObj.icon && skillObj.icon > 0) ? '\\I[' + skillObj.icon + ']' : '';
                    var skillLineText = "\\FS[" + skillNameFontSize + "]\\C[" + dashColor + "]- " + iconCode + "\\C[" + descColor + "]" + skillObj.name + ": \\FS[" + skillDescFontSize + "]\\C[0] " + skillObj.desc;
                    
                    skillLineText = this.jrLightweightWordWrap(skillLineText, maxW);
                    var skillLineH = this.drawTextExAndGetHeight(skillLineText, x + 20, y);
                    y += skillLineH + skillVerticalSpacing;
                }
            } else {
                if (analyzedData && analyzedData.skills) {
                    for (var s = 0; s < analyzedData.skills.length; s++) {
                        this.drawText(unknownSkillText, x, y, this.contentsWidth(), 'left');
                        y += lineHeight;
                    }
                } else {
                    this.drawText(unknownSkillText, x, y, this.contentsWidth(), 'left');
                    y += lineHeight;
                }
            }

            // ===============================================
            // Original Drops Section 
            // ===============================================
            this.resetFontSettings(); 
            y += lineHeight;
            this.changeTextColor(this.textColor(14)); 
            this.drawText(dropsLabel + ":", x, y, this.contentsWidth(), 'left');
            this.changeTextColor(this.normalColor()); 
            y += lineHeight;

            if (locationKnown) {
                var dropMap = {};
                enemyData.drops.forEach(function(drop) {
                    var item = null;
                    if (drop.type === 'Item') item = $dataItems[drop.id];
                    else if (drop.type === 'Weapon') item = $dataWeapons[drop.id];
                    else if (drop.type === 'Armor') item = $dataArmors[drop.id];
                    if (item) {
                        var key = item.name + ':' + drop.chance + '%';
                        dropMap[key] = dropMap[key] || { count: 0, item: item };
                        dropMap[key].count += 1;
                    }
                });

                var dropKeys = Object.keys(dropMap);
                var dropCount = dropKeys.length;
                var halfCount = Math.ceil(dropCount / 2); 
                var columnWidth = (this.contentsWidth() - 20) / 2; 
                var columnGap = 20;

                for (var i = 0; i < halfCount; i++) {
                    var yPos = y + (i * lineHeight);

                    if (i < dropKeys.length) {
                        var key = dropKeys[i];
                        var data = dropMap[key];
                        var parts = key.split(':');
                        var name = parts[0];
                        var chance = parts[1];
                        var count = data.count;
                        var item = data.item;

                        this.drawIcon(item.iconIndex, x, yPos);
                        if (Imported.cellicom_RarityItemColor && typeof item.meta.rarity !== "undefined") {
                            var rarity = parseInt(item.meta.rarity);
                            if (rarity < cellicom.rarityColors.length) {
                                this.changeTextColor(this.textColor(cellicom.rarityColors[rarity]));
                            } else {
                                this.resetTextColor();
                            }
                        } else {
                            this.resetTextColor();
                        }

                        this.drawText(name + ': x' + count + ' (' + chance + ')', x + Window_Base._iconWidth + 4, yPos, columnWidth - Window_Base._iconWidth - 4, 'left');
                        this.resetTextColor();
                    }

                    var rightIndex = i + halfCount;
                    if (rightIndex < dropKeys.length) {
                        var key = dropKeys[rightIndex];
                        var data = dropMap[key];
                        var parts = key.split(':');
                        var name = parts[0];
                        var chance = parts[1];
                        var count = data.count;
                        var item = data.item;

                        this.drawIcon(item.iconIndex, x + columnWidth + columnGap, yPos);
                        if (Imported.cellicom_RarityItemColor && typeof item.meta.rarity !== "undefined") {
                            var rarity = parseInt(item.meta.rarity);
                            if (rarity < cellicom.rarityColors.length) {
                                this.changeTextColor(this.textColor(cellicom.rarityColors[rarity]));
                            } else {
                                this.resetTextColor();
                            }
                        } else {
                            this.resetTextColor();
                        }

                        this.drawText(name + ': x' + count + ' (' + chance + ')', x + columnWidth + columnGap + Window_Base._iconWidth + 4, yPos, columnWidth - Window_Base._iconWidth - 4, 'left');
                        this.resetTextColor();
                    }
                }
                y += halfCount * lineHeight;
            } else {
                this.drawText('???', x, y, this.contentsWidth(), 'left');
                y += lineHeight;
            }

            this._dynamicContentHeight = y;
        };
    }
})();