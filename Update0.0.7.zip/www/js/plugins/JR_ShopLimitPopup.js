//=============================================================================
// JR_ShopLimitPopup.js
//=============================================================================

var Imported = Imported || {};
Imported.JR_ShopLimitPopup = true;

var JR = JR || {};
JR.SLP = JR.SLP || {};

//=============================================================================
 /*:
 * @plugindesc v1.07 Shows an auto-scaling, auto-closing message box when reaching inventory limits.
 * @author JR
 *
 * @param ---Settings---
 * @default
 *
 * @param Weapon Full Text
 * @parent ---Settings---
 * @desc Text displayed when your weapon inventory is full.
 * @default Weapon Inventory Full!
 *
 * @param Armor Full Text
 * @parent ---Settings---
 * @desc Text displayed when your armor inventory is full.
 * @default Armor Inventory Full!
 *
 * @param Item Full Text
 * @parent ---Settings---
 * @desc Text displayed when your item inventory is full.
 * @default Item Inventory Full!
 *
 * @param Popup Duration
 * @parent ---Settings---
 * @type number
 * @min 30
 * @desc How many frames the popup will stay fully visible if not closed. (60 = 1 sec)
 * @default 120
 *
 * @help
 * ============================================================================
 * Introduction
 * ============================================================================
 *
 * This plugin requires YEP_ItemCore and YEP_ShopMenuCore.
 * Make sure this plugin is located under both in the plugin list.
 *
 * When using independent items, reaching the maximum capacity (e.g., 100/100 
 * weapons) grays out the item in the shop. Pressing "OK" plays a buzzer. 
 * This extension maintains the buzzer and triggers an auto-scaling
 * message box perfectly centered on the screen.
 * 
 * The box suspends shop input and will automatically disappear after the 
 * configured duration, OR instantly if the player presses OK/Cancel/Clicks.
 */
//=============================================================================

if (Imported.YEP_ItemCore && Imported.YEP_ShopMenuCore) {

//=============================================================================
// Parameter Variables
//=============================================================================

JR.Parameters = PluginManager.parameters('JR_ShopLimitPopup');
JR.Param = JR.Param || {};

JR.Param.SLPWeaponText = String(JR.Parameters['Weapon Full Text']);
JR.Param.SLPArmorText = String(JR.Parameters['Armor Full Text']);
JR.Param.SLPItemText = String(JR.Parameters['Item Full Text']);
JR.Param.SLPDuration = Number(JR.Parameters['Popup Duration']);

//=============================================================================
// Window_ShopLimitMessage
//=============================================================================

function Window_ShopLimitMessage() {
    this.initialize.apply(this, arguments);
}

Window_ShopLimitMessage.prototype = Object.create(Window_Base.prototype);
Window_ShopLimitMessage.prototype.constructor = Window_ShopLimitMessage;

Window_ShopLimitMessage.prototype.initialize = function() {
    Window_Base.prototype.initialize.call(this, 0, 0, 400, this.windowHeight());
    this._timer = 0;
    this.hide();
    this.deactivate();
};

Window_ShopLimitMessage.prototype.windowHeight = function() {
    return this.fittingHeight(1); 
};

Window_ShopLimitMessage.prototype.update = function() {
    Window_Base.prototype.update.call(this);
    if (this.active) {
        this._timer--;
        
        // Prevent the exact same "OK" press that triggered the window from closing it instantly.
        // Requires 15 frames (0.25s) to pass before accepting input to close.
        var inputDelayPassed = (JR.Param.SLPDuration - this._timer) > 15;
        var isInputTriggered = Input.isTriggered('ok') || Input.isTriggered('cancel') || TouchInput.isTriggered();
        
        // Auto-close on timer end, OR if the player presses a button after the delay
        if (this._timer <= 0 || (inputDelayPassed && isInputTriggered)) {
            this.closePopup();
        }
    }
};

Window_ShopLimitMessage.prototype.closePopup = function() {
    this.deactivate();
    this.hide();
    
    // Return control back to the shop buy window
    if (SceneManager._scene._buyWindow) {
        SceneManager._scene._buyWindow.activate();
    }
};

Window_ShopLimitMessage.prototype.showPopup = function(text) {
    this.resetFontSettings();
    
    // 1. Auto-Scale the width based on text length + standard window padding
    var textWidth = this.textWidth(text);
    this.width = textWidth + (this.standardPadding() * 2) + 20;
    this.height = this.windowHeight();
    
    // 2. Center on the screen
    this.x = (Graphics.boxWidth - this.width) / 2;
    this.y = (Graphics.boxHeight - this.height) / 2;
    
    // 3. Re-create the contents bitmap to match the new dynamic size
    this.createContents();
    
    // 4. Draw the text perfectly centered vertically and horizontally
    this.resetFontSettings();
    var textY = (this.contentsHeight() - this.lineHeight()) / 2;
    this.drawText(text, 0, textY, this.contentsWidth(), 'center');
    
    // 5. Reset the timer, show, and activate
    this._timer = JR.Param.SLPDuration;
    this.show();
    this.activate();
};

//=============================================================================
// Scene_Shop
//=============================================================================

JR.SLP.Scene_Shop_create = Scene_Shop.prototype.create;
Scene_Shop.prototype.create = function() {
    JR.SLP.Scene_Shop_create.call(this);
    this.createLimitMessagePopup();
};

Scene_Shop.prototype.createLimitMessagePopup = function() {
    this._limitMessageWindow = new Window_ShopLimitMessage();
    this.addWindow(this._limitMessageWindow); 
};

//=============================================================================
// Window_ShopBuy
//=============================================================================

JR.SLP.Window_ShopBuy_processOk = Window_ShopBuy.prototype.processOk;
Window_ShopBuy.prototype.processOk = function() {
    JR.SLP.Window_ShopBuy_processOk.call(this);
    
    if (!this.isCurrentItemEnabled()) {
        this.checkLimitPopup();
    }
};

Window_ShopBuy.prototype.checkLimitPopup = function() {
    var item = this.item();
    if (!item) return;

    if (DataManager.isIndependent(item)) {
        var typeMax = $gameParty.getIndependentItemTypeMax(item);
        var typeCur = $gameParty.getIndependentItemTypeCur(item);
        
        if (typeCur >= typeMax) {
            var text = "";
            if (DataManager.isWeapon(item)) {
                text = JR.Param.SLPWeaponText;
            } else if (DataManager.isArmor(item)) {
                text = JR.Param.SLPArmorText;
            } else if (DataManager.isItem(item)) {
                text = JR.Param.SLPItemText;
            }
            
            if (SceneManager._scene._limitMessageWindow) {
                // Suspend the Buy Window and trigger the popup
                this.deactivate();
                SceneManager._scene._limitMessageWindow.showPopup(text);
            }
        }
    }
};

} // Imported.YEP_ItemCore && Imported.YEP_ShopMenuCore