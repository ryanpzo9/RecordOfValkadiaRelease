//=============================================================================
// Vlue_MOG_Compat.js
//=============================================================================
/*:
 * @plugindesc Compatibility patch for Recipe Crafting MV and Moghunter plugins.
 * @author JR
 * @help
 * Place this plugin BELOW Recipe Crafting MV and all Moghunter plugins 
 * in your Plugin Manager to enable backgrounds and particles in the 
 * crafting menus.
 */

(function() {
    // Ensure the Crafting scene exists before applying the patch
    if (typeof Scene_Crafting === 'undefined') return;

    // -----------------------------------------------------------------------
    // Hook into the Update Loop
    // -----------------------------------------------------------------------
    var _Scene_Crafting_update = Scene_Crafting.prototype.update;
    Scene_Crafting.prototype.update = function() {
        // Run Vlue's default update first
        _Scene_Crafting_update.call(this);
        
        // Manually trigger Moghunter's background animations
        if (Imported.MOG_MenuBackground && this._backgroundSpriteNew) {
            Scene_MenuBase.prototype.update_mbackground.call(this);
        }
        
        // Manually trigger Moghunter's particle animations
        if (Imported.MOG_MenuParticles && SceneManager._mpart) {
            Scene_MenuBase.prototype.update_particles.call(this);
        }
    };

    // Note: Vlue's secondary class, Scene_CraftingSpecific, inherits directly 
    // from Scene_Crafting without overriding the update function. 
    // Therefore, patching Scene_Crafting automatically fixes both menus!
})();