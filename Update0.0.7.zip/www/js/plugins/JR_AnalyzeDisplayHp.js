//=============================================================================
// JR_AnalyzeDisplayHp.js
//=============================================================================
/*:
 * @plugindesc Extension for YEP_X_VisualHpGauge. Reveals HP values when a specific skill is used.
 * @author JR
 *
 * @param Reveal Same In Battle
 * @type boolean
 * @on YES
 * @off NO
 * @desc If true, analyzing an enemy reveals the HP for all enemies of the same ID in the current battle.
 * @default true
 * 
 * @param Same Enemy ID Analyzed
 * @type boolean
 * @on YES
 * @off NO
 * @desc If true, analyzing an enemy once will automatically reveal the HP of all enemies with that same ID in FUTURE battles.
 * @default true
 *
 * @help
 * ============================================================================
 * Introduction & Instructions
 * ============================================================================
 * 
 * This plugin requires YEP_X_VisualHpGauge.js. Place this plugin UNDER 
 * YEP_X_VisualHpGauge in the Plugin Manager.
 * 
 * To use this plugin, you must set "Show Value" in the VisualHpGauge 
 * plugin parameters to false.
 * 
 * Skill Notetag:
 *   <AnalyzeSkill>
 *   Place this inside the notebox of your Analyze skill. When this skill 
 *   successfully hits a target, their HP value will be revealed on their 
 *   visual HP gauge for the remainder of the battle.
 * 
 * ============================================================================
 */

(function() {

    // Dependency Guard
    if (!Imported.YEP_X_VisualHpGauge) {
        console.error("JR_AnalyzeDisplayHp requires YEP_X_VisualHpGauge to be installed and active.");
        return;
    }

    //=============================================================================
    // Parameters (With Failsafes for Filename Mismatches)
    //=============================================================================
    
    var parameters = PluginManager.parameters('JR_AnalyzeDisplayHp');
    
    // Default to true if the parameter cannot be found
    var paramRevealInBattle = true;
    var paramRememberEnemy = true;
    
    if (parameters['Reveal Same In Battle'] !== undefined) {
        paramRevealInBattle = String(parameters['Reveal Same In Battle']).toLowerCase() === 'true';
    }
    if (parameters['Same Enemy ID Analyzed'] !== undefined) {
        paramRememberEnemy = String(parameters['Same Enemy ID Analyzed']).toLowerCase() === 'true';
    }

    //=============================================================================
    // Game_System (Across Battles Memory)
    //=============================================================================

    var _Game_System_initialize = Game_System.prototype.initialize;
    Game_System.prototype.initialize = function() {
        _Game_System_initialize.call(this);
        this._analyzedEnemyIds = [];
    };

    Game_System.prototype.addAnalyzedEnemy = function(enemyId) {
        if (this._analyzedEnemyIds === undefined) this._analyzedEnemyIds = [];
        if (!this._analyzedEnemyIds.contains(enemyId)) {
            this._analyzedEnemyIds.push(enemyId);
        }
    };

    Game_System.prototype.isEnemyAnalyzed = function(enemyId) {
        if (this._analyzedEnemyIds === undefined) return false;
        return this._analyzedEnemyIds.contains(enemyId);
    };

    //=============================================================================
    // Game_Troop (Current Battle Memory)
    //=============================================================================

    var _Game_Troop_setup = Game_Troop.prototype.setup;
    Game_Troop.prototype.setup = function(troopId) {
        _Game_Troop_setup.call(this, troopId);
        this._analyzedEnemyIds = [];
    };

    Game_Troop.prototype.addAnalyzedEnemy = function(enemyId) {
        if (this._analyzedEnemyIds === undefined) this._analyzedEnemyIds = [];
        if (!this._analyzedEnemyIds.contains(enemyId)) {
            this._analyzedEnemyIds.push(enemyId);
        }
    };

    Game_Troop.prototype.isEnemyAnalyzed = function(enemyId) {
        if (this._analyzedEnemyIds === undefined) return false;
        return this._analyzedEnemyIds.contains(enemyId);
    };

    //=============================================================================
    // Game_BattlerBase & Game_Battler
    //=============================================================================
    
    Game_BattlerBase.prototype.setHpValueAnalyzed = function(value) {
        this._hpValueAnalyzed = value;
    };

    Game_BattlerBase.prototype.isHpValueAnalyzed = function() {
        return !!this._hpValueAnalyzed;
    };

    var _Game_Battler_onBattleStart = Game_Battler.prototype.onBattleStart;
    Game_Battler.prototype.onBattleStart = function() {
        _Game_Battler_onBattleStart.apply(this, arguments);
        this.setHpValueAnalyzed(false);
    };

    //=============================================================================
    // Game_Enemy
    //=============================================================================

    Game_Enemy.prototype.isHpValueAnalyzed = function() {
        if (this._hpValueAnalyzed) return true;
        if (paramRevealInBattle && $gameParty.inBattle() && $gameTroop.isEnemyAnalyzed(this.enemyId())) return true;
        if (paramRememberEnemy && $gameSystem.isEnemyAnalyzed(this.enemyId())) return true;
        
        return false;
    };

    //=============================================================================
    // Game_Action
    //=============================================================================
    
    var _Game_Action_apply = Game_Action.prototype.apply;
    Game_Action.prototype.apply = function(target) {
        _Game_Action_apply.apply(this, arguments);
        
        if (this.item() && this.item().meta.AnalyzeSkill && this.isForOpponent()) {
            if (target.result().isHit()) {
                target.setHpValueAnalyzed(true);
                
                if (target.isEnemy()) {
                    if (paramRevealInBattle && $gameParty.inBattle()) {
                        $gameTroop.addAnalyzedEnemy(target.enemyId());
                    }
                    if (paramRememberEnemy) {
                        $gameSystem.addAnalyzedEnemy(target.enemyId());
                    }
                }
            }
        }
    };

    //=============================================================================
    // Window_VisualHPGauge
    //=============================================================================
    
    var _Window_VisualHPGauge_setBattler = Window_VisualHPGauge.prototype.setBattler;
    Window_VisualHPGauge.prototype.setBattler = function(battler) {
        _Window_VisualHPGauge_setBattler.apply(this, arguments);
        this._revealedValueDisplayed = battler ? battler.isHpValueAnalyzed() : false;
    };

    var _Window_VisualHPGauge_update = Window_VisualHPGauge.prototype.update;
    Window_VisualHPGauge.prototype.update = function() {
        _Window_VisualHPGauge_update.apply(this, arguments);
        if (this._battler && this._battler.isHpValueAnalyzed() && !this._revealedValueDisplayed) {
            this._revealedValueDisplayed = true;
            
            if (typeof this.refresh === 'function') {
                this.refresh();
            } else {
                this._requestRefresh = true; 
            }
        }
    };

    function wrapDrawMethod(methodName) {
        if (!Window_VisualHPGauge.prototype[methodName]) return;
        
        var originalMethod = Window_VisualHPGauge.prototype[methodName];
        Window_VisualHPGauge.prototype[methodName] = function(actor) {
            var originalShowValue = Yanfly.Param.VHGShowValue;
            
            try {
                if (actor && actor.isHpValueAnalyzed()) {
                    Yanfly.Param.VHGShowValue = true;
                }
                originalMethod.apply(this, arguments);
            } finally {
                Yanfly.Param.VHGShowValue = originalShowValue;
            }
        };
    }

    wrapDrawMethod('drawActorHp');
    wrapDrawMethod('drawEnemyHp');

})();