//=============================================================================
// AutoUpdater.js
//=============================================================================

/*:
 * @plugindesc Checks for a new game build before the title screen, downloads
 * and applies it, then restarts. Shows a version tag on the title screen.
 * @author JR (Updated with In-Zip File Deletion)
 *
 * @param Update Server URL
 * @desc URL to a JSON manifest: {"version":"1.1.0","url":"https://.../update.zip", "hash":"..."}
 * @default https://raw.githubusercontent.com/USER/REPO/main/version.json
 *
 * @param Content Folder Name
 * @desc Name of your project's content folder (default MV/MZ uses "www"). Change if yours is renamed.
 * @default www
 *
 * @param Exclude Paths
 * @desc Comma-separated path prefixes (inside the zip) to never overwrite. Protects save data.
 * @default save/
 *
 * @param Connection Timeout
 * @desc Milliseconds to wait for the manifest before assuming "no internet".
 * @default 8000
 *
 * @param Prompt Text
 * @desc Text shown when an update is found. %1 is replaced with the new version number.
 * @default Update version %1 is available! Would you like to download and install it now?
 *
 * @param Version Text Format
 * @desc %1 is replaced with the version number.
 * @default Version %1
 *
 * @param Version Text X
 * @desc X position on title screen. Leave blank for auto (bottom-right).
 * @default
 *
 * @param Version Text Y
 * @desc Y position on title screen. Leave blank for auto (bottom-right).
 * @default
 *
 * @param Version Text Font Size
 * @default 16
 *
 * @param Version Text Color
 * @default #ffffff
 *
 * @help
 * ============================================================================
 * SETUP
 * ============================================================================
 * 1. Host a version.json somewhere reachable:
 * { 
 *   "version": "1.1.0", 
 *   "url": "https://.../update.zip", 
 *   "hash": "SHA256_STRING"
 * }
 * 
 * 2. To delete files during an update, place a file named "df.json" inside 
 * your update.zip root folder with this format:
 * {
 *   "df": [
 *       "img/system/picture1.rpgmvp",
 *       "img/chaincommands"
 *   ]
 * }
 *
 * 3. Set "Update Server URL" above to that manifest's raw URL.
 * 4. In your project's www folder, run: npm install adm-zip
 * 5. Build/export your game as usual. 
 * ============================================================================
 */

//-----------------------------------------------------------------------------
// AutoUpdater — core logic (Node/NW.js side)
//-----------------------------------------------------------------------------

var AutoUpdater = {};

AutoUpdater.params = PluginManager.parameters('AutoUpdater');
AutoUpdater.manifestUrl = String(AutoUpdater.params['Update Server URL'] || '');
AutoUpdater.versionFile = 'config.bin';
AutoUpdater.excludePaths = String(AutoUpdater.params['Exclude Paths'] || 'save/')
    .split(',').map(function(s) { return s.trim(); }).filter(function(s) { return s; });
AutoUpdater.timeoutMs = Number(AutoUpdater.params['Connection Timeout'] || 8000);
AutoUpdater.contentFolderName = String(AutoUpdater.params['Content Folder Name'] || 'www');
AutoUpdater.promptText = String(AutoUpdater.params['Prompt Text'] || 'Update version %1 is available! Would you like to download and install it now?');

AutoUpdater.getBaseDir = function() {
    var path = require('path');
    var scriptDir = path.dirname(process.mainModule.filename);
    var parts = scriptDir.split(path.sep);
    var idx = parts.lastIndexOf(AutoUpdater.contentFolderName);
    if (idx !== -1) {
        var base = parts.slice(0, idx).join(path.sep);
        return base || path.sep;
    }
    return path.join(scriptDir, '..');
};

AutoUpdater.getVersionFilePath = function() {
    var path = require('path');
    return path.join(AutoUpdater.getBaseDir(), AutoUpdater.versionFile);
};

AutoUpdater.readLocalVersion = function() {
    var fs = require('fs');
    try {
        var raw = fs.readFileSync(AutoUpdater.getVersionFilePath(), 'utf8');
        if (raw.trim().indexOf('{') === 0) {
            return JSON.parse(raw).version || '0.0.0';
        }
        var decoded = Buffer.from(raw, 'base64').toString('utf8');
        var data = JSON.parse(decoded);
        return data.version || '0.0.0';
    } catch (e) {
        return '0.0.0'; 
    }
};

AutoUpdater.writeLocalVersion = function(version) {
    var fs = require('fs');
    var jsonString = JSON.stringify({ version: version });
    var encoded = Buffer.from(jsonString, 'utf8').toString('base64');
    fs.writeFileSync(AutoUpdater.getVersionFilePath(), encoded);
};

AutoUpdater.isNewer = function(remote, local) {
    var r = String(remote).split('.').map(Number);
    var l = String(local).split('.').map(Number);
    var len = Math.max(r.length, l.length);
    for (var i = 0; i < len; i++) {
        var rv = r[i] || 0, lv = l[i] || 0;
        if (rv > lv) return true;
        if (rv < lv) return false;
    }
    return false;
};

AutoUpdater.httpGet = function(url, callback, redirectCount) {
    redirectCount = redirectCount || 0;
    if (redirectCount > 5) { callback(new Error('Too many redirects')); return; }
    var lib = url.indexOf('https') === 0 ? require('https') : require('http');
    var req = lib.get(url, function(res) {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
            res.resume();
            AutoUpdater.httpGet(res.headers.location, callback, redirectCount + 1);
            return;
        }
        if (res.statusCode !== 200) {
            res.resume();
            callback(new Error('HTTP ' + res.statusCode));
            return;
        }
        var chunks = [];
        res.on('data', function(c) { chunks.push(c); });
        res.on('end', function() { callback(null, Buffer.concat(chunks).toString('utf8')); });
    });
    req.setTimeout(AutoUpdater.timeoutMs, function() {
        req.abort();
        callback(new Error('Timeout'));
    });
    req.on('error', function(err) { callback(err); });
};

AutoUpdater.fetchManifest = function(callback) {
    AutoUpdater.httpGet(AutoUpdater.manifestUrl, function(err, body) {
        if (err) { callback(err); return; }
        try {
            callback(null, JSON.parse(body));
        } catch (e) {
            callback(e);
        }
    });
};

AutoUpdater.downloadFile = function(url, dest, onProgress, callback, redirectCount) {
    redirectCount = redirectCount || 0;
    if (redirectCount > 5) { callback(new Error('Too many redirects')); return; }
    var fs = require('fs');
    var lib = url.indexOf('https') === 0 ? require('https') : require('http');
    var req = lib.get(url, function(res) {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
            res.resume();
            AutoUpdater.downloadFile(res.headers.location, dest, onProgress, callback, redirectCount + 1);
            return;
        }
        if (res.statusCode !== 200) {
            res.resume();
            callback(new Error('HTTP ' + res.statusCode));
            return;
        }
        var total = parseInt(res.headers['content-length'] || '0', 10);
        var received = 0;
        var file = fs.createWriteStream(dest);
        res.on('data', function(chunk) {
            received += chunk.length;
            if (total) onProgress(Math.floor((received / total) * 100));
        });
        res.pipe(file);
        file.on('finish', function() { file.close(function() { callback(null); }); });
        file.on('error', function(err) { callback(err); });
    });
    req.setTimeout(AutoUpdater.timeoutMs * 4, function() {
        req.abort();
        callback(new Error('Download timeout'));
    });
    req.on('error', function(err) { callback(err); });
};

AutoUpdater.calculateFileHash = function(filePath, callback) {
    var fs = require('fs');
    var crypto = require('crypto');
    var hash = crypto.createHash('sha256');
    var stream = fs.createReadStream(filePath);
    
    stream.on('data', function(data) {
        hash.update(data);
    });
    
    stream.on('end', function() {
        callback(null, hash.digest('hex'));
    });
    
    stream.on('error', function(err) {
        callback(err);
    });
};

AutoUpdater.processDeletions = function(deleteList) {
    if (!deleteList || !Array.isArray(deleteList)) return;
    
    var fs = require('fs');
    var path = require('path');
    var contentDir = path.join(AutoUpdater.getBaseDir(), AutoUpdater.contentFolderName);

    var deleteRecursiveSync = function(targetPath) {
        if (!fs.existsSync(targetPath)) return;
        
        var stats = fs.lstatSync(targetPath);
        if (stats.isDirectory()) {
            var files = fs.readdirSync(targetPath);
            files.forEach(function(file) {
                deleteRecursiveSync(path.join(targetPath, file));
            });
            fs.rmdirSync(targetPath);
        } else {
            fs.unlinkSync(targetPath);
        }
    };

    deleteList.forEach(function(itemPath) {
        if (itemPath.indexOf('..') !== -1) {
            return;
        }

        var isExcluded = AutoUpdater.excludePaths.some(function(ex) {
            return ex && itemPath.indexOf(ex.replace(/\\/g, '/')) === 0;
        });
        if (isExcluded) {
            return;
        }

        var fullPath = path.join(contentDir, itemPath);
        try {
            if (fs.existsSync(fullPath)) {
                deleteRecursiveSync(fullPath);
                console.log('AutoUpdater deleted:', fullPath);
            }
        } catch (e) {
            console.error('AutoUpdater failed to delete:', fullPath, e);
        }
    });
};

AutoUpdater.extractZip = function(zipPath, destDir, excludeList) {
    var AdmZip = require('adm-zip');
    var path = require('path');
    var fs = require('fs');
    var zip = new AdmZip(zipPath);

    // --- UPDATED: Read df.json and look for the "df" array ---
    var dfEntry = zip.getEntry('df.json');
    if (dfEntry) {
        try {
            var dfContent = dfEntry.getData().toString('utf8');
            var dfData = JSON.parse(dfContent);
            if (dfData && dfData.df) {
                console.log('AutoUpdater: Found df.json in archive. Running cleanup...');
                AutoUpdater.processDeletions(dfData.df);
            }
        } catch (e) {
            console.error('AutoUpdater: Failed to parse df.json from archive', e);
        }
    }

    zip.getEntries().forEach(function(entry) {
        var entryName = entry.entryName.replace(/\\/g, '/');
        
        if (entryName === 'df.json') return;

        var excluded = excludeList.some(function(ex) {
            return ex && entryName.indexOf(ex.replace(/\\/g, '/')) === 0;
        });
        if (excluded || entry.isDirectory) return;
        var outPath = path.join(destDir, entryName);
        var outDir = path.dirname(outPath);
        
        try {
            fs.mkdirSync(outDir, { recursive: true });
        } catch (e) {
            if (e.code !== 'EEXIST') throw e;
        }
        
        fs.writeFileSync(outPath, entry.getData());
    });
};

AutoUpdater.restartGame = function() {
    var path = require('path');
    var child_process = require('child_process');
    var gui = require('nw.gui');
    var exePath = process.execPath;
    var args = process.argv.slice(1);
    try {
        child_process.spawn(exePath, args, {
            detached: true, stdio: 'ignore', cwd: path.dirname(exePath)
        }).unref();
    } catch (e) {
        console.error('AutoUpdater restart failed:', e);
    }
    gui.App.quit();
};

AutoUpdater.run = function(onStatus, onDone, onUpdated) {
    var fs = require('fs');
    var path = require('path');

    if (!AutoUpdater.manifestUrl) { onDone(); return; }

    onStatus('Checking for updates...');
    AutoUpdater.fetchManifest(function(err, manifest) {
        if (err || !manifest || !manifest.version || !manifest.url) {
            onDone();
            return;
        }

        var localVersion = AutoUpdater.readLocalVersion();
        if (!AutoUpdater.isNewer(manifest.version, localVersion)) {
            onDone();
            return;
        }

        var promptMessage = AutoUpdater.promptText.replace('%1', manifest.version);
        var wantsUpdate = window.confirm(promptMessage);
        
        if (!wantsUpdate) {
            onDone();
            return;
        }

        onStatus('New version ' + manifest.version + ' found. Downloading... 0%');
        var tmpZip = path.join(require('os').tmpdir(), 'game_update_' + Date.now() + '.zip');

        AutoUpdater.downloadFile(manifest.url, tmpZip, function(pct) {
            onStatus('Downloading update... ' + pct + '%');
        }, function(err) {
            if (err) {
                console.error('AutoUpdater download failed:', err);
                onStatus('Update download failed. Continuing...');
                setTimeout(onDone, 1200);
                return;
            }
            
            if (!manifest.hash) {
                console.error('AutoUpdater: Manifest missing hash. Aborting update.');
                onStatus('Update verification failed (no hash). Continuing...');
                fs.unlink(tmpZip, function() {});
                setTimeout(onDone, 1200);
                return;
            }

            onStatus('Verifying update integrity...');
            AutoUpdater.calculateFileHash(tmpZip, function(hashErr, calculatedHash) {
                if (hashErr || calculatedHash !== manifest.hash) {
                    console.error('AutoUpdater hash mismatch! Expected:', manifest.hash, 'Got:', calculatedHash);
                    onStatus('Update verification failed! Continuing...');
                    fs.unlink(tmpZip, function() {}); 
                    setTimeout(onDone, 1200);
                    return;
                }

                onStatus('Applying update...');
                try {
                    AutoUpdater.extractZip(tmpZip, AutoUpdater.getBaseDir(), AutoUpdater.excludePaths);
                    AutoUpdater.writeLocalVersion(manifest.version);
                    fs.unlink(tmpZip, function() {});
                    onStatus('Update applied. Restarting...');
                    setTimeout(onUpdated, 800);
                } catch (e) {
                    console.error('AutoUpdater extract failed:', e);
                    onStatus('Failed to apply update. Continuing...');
                    setTimeout(onDone, 1200);
                }
            });
        });
    });
};

//-----------------------------------------------------------------------------
// Scene_UpdateCheck — runs before Scene_Boot
//-----------------------------------------------------------------------------

function Scene_UpdateCheck() {
    this.initialize.apply(this, arguments);
}

Scene_UpdateCheck.prototype = Object.create(Stage.prototype);
Scene_UpdateCheck.prototype.constructor = Scene_UpdateCheck;

Scene_UpdateCheck.prototype.initialize = function() {
    if (Stage.prototype.initialize) {
        Stage.prototype.initialize.call(this); // MV fallback
    } else {
        PIXI.Container.call(this); // MZ fallback
    }
    this._statusText = '';
    this._finished = false;
};

Scene_UpdateCheck.prototype.create = function() {
    var backSprite = new Sprite(new Bitmap(Graphics.width, Graphics.height));
    backSprite.bitmap.fillAll('#000000');
    this.addChild(backSprite);

    this._statusSprite = new Sprite(new Bitmap(Graphics.width, 60));
    this._statusSprite.y = Graphics.height - 100;
    this.addChild(this._statusSprite);
};

Scene_UpdateCheck.prototype.update = function() {
    for (var i = 0; i < this.children.length; i++) {
        if (this.children[i] && this.children[i].update) {
            this.children[i].update();
        }
    }
};

Scene_UpdateCheck.prototype.isReady = function() { return true; };
Scene_UpdateCheck.prototype.isBusy = function() { return false; };
Scene_UpdateCheck.prototype.stop = function() {};
Scene_UpdateCheck.prototype.terminate = function() {};
Scene_UpdateCheck.prototype.attachReservation = function() {};
Scene_UpdateCheck.prototype.detachReservation = function() {};
Scene_UpdateCheck.prototype.initCustomWindowPositions = function() {};

Scene_UpdateCheck.prototype.setStatus = function(text) {
    this._statusText = text;
    var bmp = this._statusSprite.bitmap;
    bmp.clear();
    bmp.fontSize = 22;
    bmp.textColor = '#ffffff';
    bmp.drawText(text, 0, 0, bmp.width, bmp.height, 'center');
};

Scene_UpdateCheck.prototype.start = function() {
    var self = this;

    if (!Utils.isNwjs() || Utils.isOptionValid('test')) {
        this.proceed();
        return;
    }

    AutoUpdater.run(
        function(status) { self.setStatus(status); },
        function() { self.proceed(); },
        function() { AutoUpdater.restartGame(); }
    );
};

Scene_UpdateCheck.prototype.proceed = function() {
    if (this._finished) return;
    this._finished = true;
    SceneManager.goto(Scene_Boot);
};

var _AutoUpdater_SceneManager_run = SceneManager.run;
SceneManager.run = function(sceneClass) {
    _AutoUpdater_SceneManager_run.call(this, Scene_UpdateCheck);
};

//-----------------------------------------------------------------------------
// Scene_Title — version tag
//-----------------------------------------------------------------------------

var _AutoUpdater_Scene_Title_createForeground = Scene_Title.prototype.createForeground;
Scene_Title.prototype.createForeground = function() {
    _AutoUpdater_Scene_Title_createForeground.call(this);
    this.createVersionText();
};

Scene_Title.prototype.createVersionText = function() {
    var version = Utils.isNwjs() ? AutoUpdater.readLocalVersion() : '?';
    var format = String(AutoUpdater.params['Version Text Format'] || 'Version %1');
    var text = format.replace('%1', version);

    var w = 300, h = 40;
    var sprite = new Sprite(new Bitmap(w, h));
    sprite.bitmap.fontSize = Number(AutoUpdater.params['Version Text Font Size'] || 16);
    sprite.bitmap.textColor = String(AutoUpdater.params['Version Text Color'] || '#ffffff');
    sprite.bitmap.drawText(text, 0, 0, w, h, 'right');

    var xParam = AutoUpdater.params['Version Text X'];
    var yParam = AutoUpdater.params['Version Text Y'];
    sprite.x = (xParam === '' || xParam === undefined) ? Graphics.width - w - 10 : Number(xParam);
    sprite.y = (yParam === '' || yParam === undefined) ? Graphics.height - h - 10 : Number(yParam);

    this.addChild(sprite);
};