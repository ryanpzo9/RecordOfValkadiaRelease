//=============================================================================
// ARP_MOG_Compat.js
//=============================================================================
/*:
 * @plugindesc v2.0 - Compatibility patch for ARP_InGameManual and Moghunter menu plugins.
 * @author JR
 * @help
 * Replace the previous patch with this one.
 * Place this plugin BELOW ARP_InGameManual.js and all Moghunter plugins.
 */

(function() {
    // We must intercept SceneManager.push because ARP_InGameManual 
    // hides its Scene_GameManual class inside a private function (IIFE),
    // making it impossible to patch normally.
    
    var _SceneManager_push = SceneManager.push;
    SceneManager.push = function(sceneClass) {
        // We identify Scene_GameManual by checking for a method unique to it
        if (sceneClass && sceneClass.prototype && sceneClass.prototype.createEntryListWindow) {
            if (!sceneClass._mogPatched) {
                sceneClass._mogPatched = true;
                applyArpMogPatch(sceneClass);
            }
        }
        _SceneManager_push.call(this, sceneClass);
    };

    function applyArpMogPatch(sceneClass) {
        // 1. Hook into Scene Creation
        var _Scene_GameManual_createBackground = sceneClass.prototype.createBackground;
        sceneClass.prototype.createBackground = function() {
            // Run ARP's default background creation first
            _Scene_GameManual_createBackground.call(this);
            
            // Inject MOG Menu Background
            if (Imported.MOG_MenuBackground) {
                SceneManager._mback = false;
                if (!Scene_MenuBase.prototype.skip_mbackground.call(this)) {
                    Scene_MenuBase.prototype.create_mbackground.call(this);
                }
            }
            
            // Inject MOG Menu Particles
            if (Imported.MOG_MenuParticles) {
                SceneManager._mpart = false;
                if (!Scene_MenuBase.prototype.skip_particles.call(this)) {
                    Scene_MenuBase.prototype.create_mparticles.call(this);
                }
            }
        };

        // 2. Hook into the Update Loop
        var _Scene_GameManual_update = sceneClass.prototype.update;
        sceneClass.prototype.update = function() {
            _Scene_GameManual_update.call(this);
            
            // Update MOG visuals if they exist
            if (Imported.MOG_MenuBackground && this._backgroundSpriteNew) {
                Scene_MenuBase.prototype.update_mbackground.call(this);
            }
            if (Imported.MOG_MenuParticles && SceneManager._mpart) {
                Scene_MenuBase.prototype.update_particles.call(this);
            }
        };

        // 3. Hook into Scene Termination (Cleanup)
        var _Scene_GameManual_terminate = sceneClass.prototype.terminate;
        sceneClass.prototype.terminate = function() {
            if (_Scene_GameManual_terminate) {
                _Scene_GameManual_terminate.call(this);
            } else {
                Scene_Base.prototype.terminate.call(this);
            }
            
            // Disable background and particles when leaving the scene
            if (Imported.MOG_MenuBackground) SceneManager._mback = false;
            if (Imported.MOG_MenuParticles) SceneManager._mpart = false;
        };

        // 4. Port Moghunter Helper Methods
        var mogHelpers = [
            'set_background_img', 
            'refreshBackgroundName', 
            'refreshBackgroundBitmap', 
            'set_particle_img', 
            'need_reset_particles', 
            'reset_particles',
            'skip_mbackground',
            'skip_particles'
        ];
        
        mogHelpers.forEach(function(methodName) {
            if (Scene_MenuBase.prototype[methodName]) {
                sceneClass.prototype[methodName] = Scene_MenuBase.prototype[methodName];
            }
        });
    }
})();