//=============================================================================
// JR_TimeSystem_CompactHud.js
//=============================================================================

/*:
 * @plugindesc Replaces MOG's Time HUD with a compact, collapsible window displaying detailed time information.
 * @author JR
 *
 * @param --- Layout & Position ---
 *
 * @param Window X
 * @parent --- Layout & Position ---
 * @desc X coordinate of the HUD window. 
 * Presets allowed: w (screen width), hudw (hud width).
 * @default w - hudw
 * @type text
 *
 * @param Window Y
 * @parent --- Layout & Position ---
 * @desc Y coordinate of the HUD window. 
 * Presets allowed: h (screen height), hudh (hud height).
 * @default 0
 * @type text
 *
 * @param Icon Active X
 * @parent --- Layout & Position ---
 * @desc X coordinate of the icon when HUD is ACTIVE. 
 * Presets: w, h, hudw, hudh, iconw, iconh, hudx, hudy.
 * @default hudx - iconw
 * @type text
 *
 * @param Icon Active Y
 * @parent --- Layout & Position ---
 * @desc Y coordinate of the icon when HUD is ACTIVE. 
 * Presets: w, h, hudw, hudh, iconw, iconh, hudx, hudy.
 * @default hudy + 10
 * @type text
 *
 * @param Icon Collapsed X
 * @parent --- Layout & Position ---
 * @desc X coordinate of the icon when HUD is COLLAPSED. 
 * Presets: w, h, hudw, hudh, iconw, iconh.
 * @default w - iconw
 * @type text
 *
 * @param Icon Collapsed Y
 * @parent --- Layout & Position ---
 * @desc Y coordinate of the icon when HUD is COLLAPSED. 
 * Presets: w, h, hudw, hudh, iconw, iconh.
 * @default 0
 * @type text
 *
 * @param Text Alignment
 * @parent --- Layout & Position ---
 * @desc Alignment of the text and icon block inside the HUD.
 * @default left
 * @type select
 * @option left
 * @option center
 * @option right
 *
 * @param Icon Spacing
 * @parent --- Layout & Position ---
 * @desc Space in pixels between the icon and the text in the row.
 * @default 8
 * @type number
 *
 * @param --- General ---
 * 
 * @param Custom Background Image
 * @parent --- General ---
 * @desc Image name in img/system to replace the default window skin. Leave blank to use standard window skin.
 * @default
 * @require 1
 * @dir img/system/
 * @type file
 *
 * @param Expanded Opacity
 * @parent --- General ---
 * @desc Base opacity of the text/icons when the HUD is EXPANDED (0 to 255).
 * @default 255
 * @type number
 * @min 0
 * @max 255
 *
 * @param Collapsed Opacity
 * @parent --- General ---
 * @desc Base opacity of the text/icons when the HUD is COLLAPSED (0 to 255).
 * @default 255
 * @type number
 * @min 0
 * @max 255
 *
 * @param Fade Opacity
 * @parent --- General ---
 * @desc The opacity of the HUD when the player overlaps with it (0 to 255).
 * @default 120
 * @type number
 * @min 0
 * @max 255
 * 
 * @param --- Rows & Format ---
 *
 * @param Use 24-Hour Format
 * @parent --- Rows & Format ---
 * @desc true to use 24-hour (HH:MM), false to use 12-hour (HH:MM AM/PM).
 * @default true
 * @type boolean
 *
 * @param Row 1 Icon
 * @parent --- Rows & Format ---
 * @desc Icon index for the "Hour : Minute" row.
 * @default 74
 * @type number
 *
 * @param Row 2 Icon
 * @parent --- Rows & Format ---
 * @desc Icon index for the "Day of the week, Month/Day/Year" row.
 * @default 73
 * @type number
 *
 * @param Season Icons
 * @parent --- Rows & Format ---
 * @desc Comma-separated icon IDs for seasons (e.g., 64,65,66,67). Leave blank to display text (e.g., "Season: Autumn").
 * @default
 * @type string
 *
 * @param Season Text
 * @parent --- Rows & Format ---
 * @desc The text displayed before the season name. Leave blank to only show the icon + name.
 * @default Season:
 * @type text
 *
 * @param --- Gold Row ---
 * 
 * @param Gold Icon
 * @parent --- Gold Row ---
 * @desc Icon index for the Gold row (Standard MV Gold icon is 314). Set to 0 to hide icon.
 * @default 314
 * @type number
 *
 * @param Gold Text
 * @parent --- Gold Row ---
 * @desc The text displayed before the gold value. Leave completely blank to only show icon + value.
 * @default Gold:
 * @type text
 *
 * @param --- Collapsed Time ---
 *
 * @param Show Collapsed Time
 * @parent --- Collapsed Time ---
 * @desc Show the HH:MM time beside the icon when HUD is collapsed?
 * @default true
 * @type boolean
 *
 * @param Collapsed Time Side
 * @parent --- Collapsed Time ---
 * @desc Side to display the time when collapsed (left or right).
 * @default left
 * @type select
 * @option left
 * @option right
 *
 * @param Collapsed Time Spacing
 * @parent --- Collapsed Time ---
 * @desc Distance between the icon and the collapsed time text.
 * @default 8
 * @type number
 *
 * @param Collapsed Gold Spacing
 * @parent --- Collapsed Time ---
 * @desc Space in pixels between the Time row and the Gold row.
 * @default 0
 * @type number
 * @min -32
 * @max 64
 *
 * @param --- Controls ---
 *
 * @param Custom Key Codes
 * @parent --- Controls ---
 * @desc Map custom keys to keyboard codes. Format: "key:code, key:code". E.g. "t:84, u:85, y:89"
 * @default t:84, u:85, y:89, n:78, m:77, -:189, +:187, -:109, +:107
 *
 * @param Toggle Key
 * @parent --- Controls ---
 * @desc The keyboard key to toggle the HUD (must match a mapped Custom Key Code).
 * @default t
 *
 * @param Window Icon (Day)
 * @parent --- Controls ---
 * @desc Icon index for the toggle button during the day (06:00 to 17:59).
 * @default 83
 * @type number
 *
 * @param Window Icon (Night)
 * @parent --- Controls ---
 * @desc Icon index for the toggle button during the night (18:00 to 05:59).
 * @default 84
 * @type number
 *
 * @param Custom Image (Day)
 * @parent --- Controls ---
 * @desc Image in img/system to use for the button during the day. Leaves blank to use icon.
 * @default
 * @require 1
 * @dir img/system/
 * @type file
 *
 * @param Custom Image (Night)
 * @parent --- Controls ---
 * @desc Image in img/system to use for the button during the night. Leaves blank to use icon.
 * @default
 * @require 1
 * @dir img/system/
 * @type file
 *
 * @param Icon Scale
 * @parent --- Controls ---
 * @desc Scale multiplier for the toggle button (1.0 is default size).
 * @default 1.0
 * @type number
 * @decimals 1
 *
 * @param --- Sound ---
 * @default
 *
 * @param Toggle SE Name
 * @parent --- Sound ---
 * @type file
 * @dir audio/se/
 * @desc Sound effect to play when clicking the toggle button. Leave blank for default cursor sound.
 * @default
 *
 * @param Toggle SE Volume
 * @parent --- Sound ---
 * @type number
 * @min 0
 * @max 100
 * @desc Volume of the toggle SE.
 * @default 90
 *
 * @param Toggle SE Pitch
 * @parent --- Sound ---
 * @type number
 * @min 50
 * @max 150
 * @desc Pitch of the toggle SE.
 * @default 100
 *
 * @help
 * ============================================================================
 * Compact Time HUD for MOG_TimeSystem
 * ============================================================================
 * This plugin replaces MOG_TimeSystem_Hud.js. It requires MOG_TimeSystem.js
 * to be installed and active above it in the plugin manager.
 * 
 * Features:
 * - Automatically disables MOG's default map HUD.
 * - Dynamic Auto-Scaling: The window automatically sizes itself to fit the text!
 * - Displays Time, Full Date, Season, and Party Gold (4 rows).
 * - Gold amounts are automatically formatted with commas (e.g. 99,999,999).
 * - Day/Night dynamic icons for the Toggle Button (Swaps at 06:00 and 18:00).
 * - Displays floating time & gold text when the HUD is collapsed.
 * - Configurable Base Opacity for Expanded and Collapsed states.
 * - Aligns the icon AND text block together (Left, Center, Right).
 * - Auto-fades when the player walks under the HUD or the collapsed icon/text.
 * - Auto-hides during events and in battle.
 * - Click/Tap the floating toggle icon, or press the designated Hotkey, 
 *   to collapse or expand the time window.
 * - Optimized Memoization Caching for coordinate expressions.
 */

(function() {
    if (!Imported.MOG_TimeSystem) {
        console.error("JR_TimeSystem_CompactHud requires MOG_TimeSystem to be installed!");
        return;
    }

    var parameters = PluginManager.parameters('JR_TimeSystem_CompactHud');
    
    // Layout Settings
    var _textAlign = String(parameters['Text Alignment'] || 'left');
    var _iconSpacing = Number(parameters['Icon Spacing'] || 8);
    
    // Offset and Coordinates
    var _iconActXParam = String(parameters['Icon Active X'] || 'hudx - iconw');
    var _iconActYParam = String(parameters['Icon Active Y'] || 'hudy + 10');
    var _iconColXParam = String(parameters['Icon Collapsed X'] || 'w - iconw');
    var _iconColYParam = String(parameters['Icon Collapsed Y'] || '0');

    // General Settings
    var _bgImage = String(parameters['Custom Background Image'] || '');
    var _expandedOpacity = Number(parameters['Expanded Opacity'] || 255);
    var _collapsedOpacity = Number(parameters['Collapsed Opacity'] || 255);
    var _fadeOpacity = Number(parameters['Fade Opacity'] || 120);
    
    // Row & Format Settings
    var _use24Hour = String(parameters['Use 24-Hour Format'] || 'true') === 'true';
    var _iconR1 = Number(parameters['Row 1 Icon'] || 74);
    var _iconR2 = Number(parameters['Row 2 Icon'] || 73);
    var _seasonIcons = String(parameters['Season Icons'] || '').split(',').filter(function(i) { return i.trim() !== ''; });
    
    var _seasonTextParam = parameters['Season Text'];
    var _seasonText = _seasonTextParam !== undefined ? String(_seasonTextParam) : 'Season:';
    
    // Gold Settings
    var _iconGold = Number(parameters['Gold Icon'] || 314);
    var _goldText = String(parameters['Gold Text'] || '');

    // Collapsed Time Settings
    var _showColTime = String(parameters['Show Collapsed Time'] || 'true') === 'true';
    var _colTimeSide = String(parameters['Collapsed Time Side'] || 'left');
    var _colTimeSpacing = Number(parameters['Collapsed Time Spacing'] || 8);
    var _colGoldSpacing = Number(parameters['Collapsed Gold Spacing'] || 0);

    // Controls Settings
    var _customKeyCodes = String(parameters['Custom Key Codes'] || '');
    var _toggleKeyStr = String(parameters['Toggle Key'] || 't').toLowerCase();
    var _toggleKeyChar = _toggleKeyStr.toUpperCase();
    
    var _toggleIconDayId = Number(parameters['Window Icon (Day)'] || 83);
    var _toggleIconNightId = Number(parameters['Window Icon (Night)'] || 84);
    var _customImgDay = String(parameters['Custom Image (Day)'] || '');
    var _customImgNight = String(parameters['Custom Image (Night)'] || '');
    var _iconScale = Number(parameters['Icon Scale'] || 1.0);

    // Sound Settings
    var _toggleSeName = String(parameters['Toggle SE Name'] || '');
    var _toggleSeVol = Number(parameters['Toggle SE Volume'] || 90);
    var _toggleSePitch = Number(parameters['Toggle SE Pitch'] || 100);

    // Register Custom Keys
    if (_customKeyCodes) {
        var pairs = _customKeyCodes.split(',');
        for (var i = 0; i < pairs.length; i++) {
            var pair = pairs[i].split(':');
            if (pair.length === 2) {
                var key = pair[0].trim().toLowerCase();
                var code = parseInt(pair[1].trim());
                if (key && !isNaN(code)) {
                    Input.keyMapper[code] = key;
                }
            }
        }
    }

    // Helper Function to format numbers with commas
    function formatNumberWithCommas(number) {
        return String(number).replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }
	
	// Helper Function to ignore dummy/comment-only events
    function isRealEventRunning() {
        var isRunning = $gameMap.isEventRunning();
        
        if (isRunning && $gameMap._interpreter && $gameMap._interpreter._list) {
            var commandList = $gameMap._interpreter._list;
            var onlyComments = true;
            
            for (var i = 0; i < commandList.length; i++) {
                var code = commandList[i].code;
                if (code !== 0 && code !== 108 && code !== 408) {
                    onlyComments = false;
                    break;
                }
            }
            
            if (onlyComments) isRunning = false;
        }
        
        return isRunning;
    }

    //=============================================================================
    // Smart Coordinate Caching (Memoization)
    // Prevents running eval() 60 times a second per coordinate.
    //=============================================================================
    var _evalCache = {};
    
    function getCachedCoord(expr, w, h, hudw, hudh, iconw, iconh, hudx, hudy) {
        var key = expr + '|' + w + '|' + h + '|' + hudw + '|' + hudh + '|' + iconw + '|' + iconh + '|' + hudx + '|' + hudy;
        
        // If exact layout exists in memory, return instantly (zero overhead)
        if (_evalCache[key] !== undefined) {
            return _evalCache[key];
        }
        
        // If not found, safely calculate once and store
        try {
            var result = eval(expr);
            _evalCache[key] = result;
            return result;
        } catch (e) {
            console.error("JR_TimeSystem_CompactHud Eval Error in: " + expr, e);
            return 0;
        }
    }

    //=============================================================================
    // Scene_Map Integration
    //=============================================================================
    
    // OVERRIDE: Suppress MOG_TimeSystem's original map HUD from rendering.
    var _Scene_Map_createTimeStatus = Scene_Map.prototype.createTimeStatus;
    Scene_Map.prototype.createTimeStatus = function() {
        // Intentionally blank to suppress MOG's default HUD.
    };

    var _Scene_Map_createDisplayObjects = Scene_Map.prototype.createDisplayObjects;
    Scene_Map.prototype.createDisplayObjects = function() {
        _Scene_Map_createDisplayObjects.call(this);
        this.createCompactTimeHud();
    };

    Scene_Map.prototype.createCompactTimeHud = function() {
        this._compactTimeWindow = new Window_CompactTimeHud();
        this._compactTimeToggle = new Sprite_TimeHudToggle(this._compactTimeWindow);
        this._compactTimeWindow.setToggleSprite(this._compactTimeToggle);
        
        this.addChild(this._compactTimeWindow);
        this.addChild(this._compactTimeToggle);
    };

    // Global Key Listener
    var _Scene_Map_update = Scene_Map.prototype.update;
    Scene_Map.prototype.update = function() {
        _Scene_Map_update.call(this);
        var sceneValid = !isRealEventRunning() && !$gameMessage.isBusy();
        if (Input.isTriggered(_toggleKeyStr) && sceneValid) {
            if (this._compactTimeToggle && this._compactTimeToggle.visible) {
                this._compactTimeToggle.onClick();
            }
        }
    };

    // Prevent Map click movement when interacting with the toggle button
    var _Scene_Map_processMapTouch = Scene_Map.prototype.processMapTouch;
    Scene_Map.prototype.processMapTouch = function() {
        if (this._compactTimeToggle && this._compactTimeToggle.visible && this._compactTimeToggle.isButtonTouched()) {
            return;
        }
        _Scene_Map_processMapTouch.call(this);
    };

    //=============================================================================
    // Sprite_TimeHudToggle (The interactive button inherited from Sprite_Button)
    //=============================================================================
    function Sprite_TimeHudToggle() {
        this.initialize.apply(this, arguments);
    }

    Sprite_TimeHudToggle.prototype = Object.create(Sprite_Button.prototype);
    Sprite_TimeHudToggle.prototype.constructor = Sprite_TimeHudToggle;

    Sprite_TimeHudToggle.prototype.initialize = function(timeWindow) {
        Sprite_Button.prototype.initialize.call(this);
        this._timeWindow = timeWindow;
        this.scale.set(_iconScale, _iconScale);
        
        // Cooldown timer to prevent double-triggering
        this._clickCooldown = 0; 
        
        // Track day/night state to swap icon dynamically
        this._isDay = this.isDayTime();
        
        // Setup Collapsed Time & Gold Text Sprite
        this._timeTextSprite = new Sprite(new Bitmap(300, 128)); 
        this.addChild(this._timeTextSprite);

        // Dedicated sprite for the Hint Key text
        this._keyHintSprite = new Sprite();
        this.addChild(this._keyHintSprite);

        this.createBitmap();
        this.setClickHandler(this.onClick.bind(this));
    };

    Sprite_TimeHudToggle.prototype.isDayTime = function() {
        var h = $gameSystem.hour();
        return h >= 6 && h < 18;
    };

    Sprite_TimeHudToggle.prototype.createBitmap = function() {
        if (_customImgDay) {
            this._customBmpDay = ImageManager.loadSystem(_customImgDay);
            this._customBmpDay.addLoadListener(this.redraw.bind(this));
        }
        if (_customImgNight) {
            this._customBmpNight = ImageManager.loadSystem(_customImgNight);
            this._customBmpNight.addLoadListener(this.redraw.bind(this));
        }
        this.redraw();
    };

    Sprite_TimeHudToggle.prototype.redraw = function() {
        var isDay = this.isDayTime();
        var img = isDay ? this._customBmpDay : this._customBmpNight;
        var customName = isDay ? _customImgDay : _customImgNight;
        var iconId = isDay ? _toggleIconDayId : _toggleIconNightId;

        if (customName && img && img.isReady()) {
            this.bitmap = new Bitmap(img.width, img.height);
            this.bitmap.blt(img, 0, 0, img.width, img.height, 0, 0);
        } else {
            this.bitmap = new Bitmap(Window_Base._iconWidth, Window_Base._iconHeight);
            var iconSet = ImageManager.loadSystem('IconSet');
            var pw = Window_Base._iconWidth;
            var ph = Window_Base._iconHeight;
            var sx = (iconId % 16) * pw;
            var sy = Math.floor(iconId / 16) * ph;
            this.bitmap.blt(iconSet, sx, sy, pw, ph, 0, 0);
        }
        
        this.refreshKeyHint();
    };

    Sprite_TimeHudToggle.prototype.refreshKeyHint = function() {
        if (!this._keyHintSprite) return;
        var text = "[" + _toggleKeyChar + "]";
        var fontSize = 18;
        
        var tempBmp = new Bitmap(1, 1);
        tempBmp.fontSize = fontSize;
        var width = tempBmp.measureTextWidth(text) + 8;
        
        this._keyHintSprite.bitmap = new Bitmap(width, fontSize + 8);
        this._keyHintSprite.bitmap.fontSize = fontSize;
        this._keyHintSprite.bitmap.textColor = "#ffffff";
        this._keyHintSprite.bitmap.outlineColor = 'rgba(0,0,0,0.8)';
        this._keyHintSprite.bitmap.outlineWidth = 3;
        this._keyHintSprite.bitmap.drawText(text, 0, 0, width, fontSize + 8, 'center');
        
        var btnW = this.bitmap ? this.bitmap.width : Window_Base._iconWidth;
        var btnH = this.bitmap ? this.bitmap.height : Window_Base._iconHeight;
        
        this._keyHintSprite.x = (btnW - width) / 2;
        this._keyHintSprite.y = btnH; 
    };

    Sprite_TimeHudToggle.prototype.refreshTimeText = function() {
        var bmp = this._timeTextSprite.bitmap;
        bmp.clear();
        
        if (!this._timeWindow._isCollapsed || !_showColTime) return;

        // --- Prepare Time Data ---
        var hrStr, ampmStr = "";
        if (_use24Hour) {
            hrStr = $gameSystem.hour().padZero(2);
        } else {
            hrStr = $gameSystem.hour_pm().padZero(2);
            ampmStr = $gameSystem.hour() >= 12 ? " PM" : " AM";
        }
        var min = $gameSystem.minute().padZero(2);
        var timeText = hrStr + " : " + min + ampmStr;

        // --- Prepare Gold Data ---
        var goldVal = $gameParty.gold();
        var formattedGold = formatNumberWithCommas(goldVal);
        var prefix = _goldText.trim();
        var goldDisplay = prefix ? prefix + " " + formattedGold : formattedGold;
        
        bmp.fontSize = 20;
        bmp.textColor = "#ffffff";
        bmp.outlineColor = "rgba(0,0,0,0.8)";
        bmp.outlineWidth = 3;
        
        var align = _colTimeSide === 'left' ? 'right' : 'left';
        var bmpW = bmp.width;
        
        var timeY = 0;
        var goldY = 32 + _colGoldSpacing; 
        
        // 1) Draw Time on top line
        bmp.drawText(timeText, 0, timeY, bmpW, 32, align);
        
        // 2) Draw Gold on bottom line
        var useIcon = _iconGold > 0;
        var textW = bmp.measureTextWidth(goldDisplay);
        var iconW = useIcon ? Window_Base._iconWidth : 0;
        var gap = (useIcon && goldDisplay) ? _iconSpacing : 0;
        var totalW = iconW + gap + textW;
        
        var startX = 0;
        if (align === 'center') {
            startX = (bmpW - totalW) / 2;
        } else if (align === 'right') {
            startX = bmpW - totalW;
        }

        if (useIcon) {
            var iconSet = ImageManager.loadSystem('IconSet');
            var pw = Window_Base._iconWidth;
            var ph = Window_Base._iconHeight;
            var sx = (_iconGold % 16) * pw;
            var sy = Math.floor(_iconGold / 16) * ph;
            bmp.blt(iconSet, sx, sy, pw, ph, startX, goldY);
            bmp.drawText(goldDisplay, startX + iconW + gap, goldY, textW, 32, 'left');
        } else {
            bmp.drawText(goldDisplay, startX, goldY, textW, 32, 'left');
        }
    };

    Sprite_TimeHudToggle.prototype.onClick = function() {
        if (this._clickCooldown > 0) return; 
        this._clickCooldown = 15; 
        
        if (_toggleSeName !== '') {
            var se = {
                name: _toggleSeName,
                pan: 0,
                pitch: _toggleSePitch,
                volume: _toggleSeVol
            };
            AudioManager.playSe(se);
        } else {
            SoundManager.playCursor();
        }
        
        this._timeWindow.toggleCollapse();
    };

    Sprite_TimeHudToggle.prototype.isButtonTouched = function() {
        var x = TouchInput.x;
        var y = TouchInput.y;
        var hitW = this.bitmap ? this.bitmap.width * this.scale.x : 32 * this.scale.x;
        var hitH = this.bitmap ? this.bitmap.height * this.scale.y : 32 * this.scale.y;
        
        if (this._keyHintSprite && this._keyHintSprite.bitmap) {
            hitH += this._keyHintSprite.bitmap.height * this.scale.y;
        }
        
        return x >= this.x && x <= this.x + hitW && y >= this.y && y <= this.y + hitH;
    };

    Sprite_TimeHudToggle.prototype.update = function() {
        Sprite_Button.prototype.update.call(this);
        
        if (this._clickCooldown > 0) {
            this._clickCooldown--;
        }
        
        var currentDayState = this.isDayTime();
        if (this._isDay !== currentDayState) {
            this._isDay = currentDayState;
            this.redraw();
        }
        
        this.updatePosition();
        this.updateVisibility();
        this.updateHover();
        this.updateOpacity();
    };

    Sprite_TimeHudToggle.prototype.updateHover = function() {
        if (!this.visible) return;
        var isHovered = this.isButtonTouched();
        var targetScale = isHovered ? (_iconScale * 1.1) : _iconScale;
        
        if (this.scale.x !== targetScale) {
            this.scale.set(targetScale, targetScale);
        }
    };

    Sprite_TimeHudToggle.prototype.updatePosition = function() {
        var btnW = this.bitmap ? this.bitmap.width : Window_Base._iconWidth;
        var btnH = this.bitmap ? this.bitmap.height : Window_Base._iconHeight;
        
        var w = Graphics.boxWidth;
        var h = Graphics.boxHeight;
        var iconw = btnW * this.scale.x;
        var iconh = btnH * this.scale.y;
        var hudw = this._timeWindow.width; 
        var hudh = this._timeWindow.height; 
        var hudx = this._timeWindow.x;
        var hudy = this._timeWindow.y;

        if (this._timeWindow._isCollapsed) {
            this.x = getCachedCoord(_iconColXParam, w, h, hudw, hudh, iconw, iconh, hudx, hudy);
            this.y = getCachedCoord(_iconColYParam, w, h, hudw, hudh, iconw, iconh, hudx, hudy);
        } else {
            this.x = getCachedCoord(_iconActXParam, w, h, hudw, hudh, iconw, iconh, hudx, hudy);
            this.y = getCachedCoord(_iconActYParam, w, h, hudw, hudh, iconw, iconh, hudx, hudy);
        }

        if (_colTimeSide === 'left') {
            this._timeTextSprite.x = -this._timeTextSprite.bitmap.width - _colTimeSpacing;
        } else {
            this._timeTextSprite.x = btnW + _colTimeSpacing;
        }
        
        var totalTextH = 32 + 32 + _colGoldSpacing; 
        this._timeTextSprite.y = (btnH - totalTextH) / 2;
    };

    Sprite_TimeHudToggle.prototype.updateVisibility = function() {
        if (isRealEventRunning() || $gameMessage.isBusy()) {
            this.visible = false;
        } else {
            this.visible = true;
        }
    };

    Sprite_TimeHudToggle.prototype.updateOpacity = function() {
        this.opacity = this._timeWindow.contentsOpacity;
    };

    //=============================================================================
    // Window_CompactTimeHud
    //=============================================================================
    function Window_CompactTimeHud() {
        this.initialize.apply(this, arguments);
    }

    Window_CompactTimeHud.prototype = Object.create(Window_Base.prototype);
    Window_CompactTimeHud.prototype.constructor = Window_CompactTimeHud;

    Window_CompactTimeHud.prototype.initialize = function() {
		Window_Base.prototype.initialize.call(this, 0, 0, 100, 100);
		
		if ($gameSystem._timeHudCollapsed === undefined) {
			$gameSystem._timeHudCollapsed = false;
		}
		this._isCollapsed = $gameSystem._timeHudCollapsed;
		this._expandedDirty = false;
		
		// Expanded tracking variables
		this._lastTimeTick = -1; // Minute
		this._lastHour = -1;
		this._lastDay = -1;
		this._lastMonth = -1;
		this._lastYear = -1;
		this._lastSeason = -1;
		this._lastGold = -1;
		
		this._targetOpacity = this._isCollapsed ? _collapsedOpacity : _expandedOpacity;
		this._customBg = null;
		this._toggleSprite = null;
		
		if (_bgImage !== "") {
			this._customBg = new Sprite(ImageManager.loadSystem(_bgImage));
			this.addChildToBack(this._customBg);
			this.opacity = 0; 
			
			this._customBg.bitmap.addLoadListener(function() {
				this.updateCustomBgScale();
			}.bind(this));
		}
		
		this.refresh(); 
		this.contentsOpacity = this._targetOpacity; 
	};
    
    Window_CompactTimeHud.prototype.setToggleSprite = function(sprite) {
        this._toggleSprite = sprite;
        this._toggleSprite.refreshTimeText();
    };

    Window_CompactTimeHud.prototype.toggleCollapse = function() {
		this._isCollapsed = !this._isCollapsed;
		$gameSystem._timeHudCollapsed = this._isCollapsed; 
		
		if (!this._isCollapsed && this._expandedDirty) {
			this.refresh();
			this._expandedDirty = false;
		}
	
		if (this._toggleSprite) {
			this._toggleSprite.refreshTimeText();
		}
	};

    Window_CompactTimeHud.prototype.update = function() {
		Window_Base.prototype.update.call(this);
		this.updatePosition(); 
		this.updateVisibility();
		this.updateFading();
		
		var currentTick = $gameSystem.minute();
		var currentHour = $gameSystem.hour();
		var currentDay = $gameSystem.day();
		var currentMonth = $gameSystem.month();
		var currentYear = $gameSystem.year();
		var currentSeason = $gameSystem.season();
		var currentGold = $gameParty.gold();
		
		// Check if ANY time metric or gold has changed
		if (this._lastTimeTick !== currentTick || 
			this._lastHour !== currentHour ||
			this._lastDay !== currentDay || 
			this._lastMonth !== currentMonth ||
			this._lastYear !== currentYear ||
			this._lastSeason !== currentSeason ||
			this._lastGold !== currentGold) {
			
			this._lastTimeTick = currentTick;
			this._lastHour = currentHour;
			this._lastDay = currentDay;
			this._lastMonth = currentMonth;
			this._lastYear = currentYear;
			this._lastSeason = currentSeason;
			this._lastGold = currentGold;
			
			if (this._isCollapsed) {
				this._expandedDirty = true;
				if (this._toggleSprite) {
					this._toggleSprite.refreshTimeText();
				}
			} else {
				this.refresh();
				this._expandedDirty = false;
			}
		}
	};
    
    Window_CompactTimeHud.prototype.updatePosition = function() {
        var w = Graphics.boxWidth;
        var h = Graphics.boxHeight;
        var hudw = this.width;
        var hudh = this.height;
        
        var iconw = 32 * _iconScale;
        var iconh = 32 * _iconScale;
        if (this._toggleSprite && this._toggleSprite.bitmap && this._toggleSprite.bitmap.isReady()) {
            iconw = this._toggleSprite.bitmap.width * _iconScale;
            iconh = this._toggleSprite.bitmap.height * _iconScale;
        }
        
        var xParam = String(parameters['Window X'] || 'w - hudw');
        var yParam = String(parameters['Window Y'] || '0');
        
        var finalX = getCachedCoord(xParam, w, h, hudw, hudh, iconw, iconh, 0, 0);
        var finalY = getCachedCoord(yParam, w, h, hudw, hudh, iconw, iconh, 0, 0);
        
        if (this.x !== finalX || this.y !== finalY) {
            this.x = finalX;
            this.y = finalY;
        }
    };

    Window_CompactTimeHud.prototype.updateVisibility = function() {
        if (isRealEventRunning() || $gameMessage.isBusy()) {
            this.visible = false;
        } else {
            this.visible = !this._isCollapsed;
        }
    };

    Window_CompactTimeHud.prototype.updateFading = function() {
		// Optimization: Skip all math if the HUD is hidden by an event or message
		if (isRealEventRunning() || $gameMessage.isBusy()) {
			return;
		}
	
		var px = $gamePlayer.screenX();
		var py = $gamePlayer.screenY() - 24; 
	
		var startX = this.x; 
		var startY = this.y;
		var endX = this.x + this.width;
		var endY = this.y + this.height;
		
		if (this._toggleSprite) {
			var iconw = this._toggleSprite.bitmap ? this._toggleSprite.bitmap.width * _iconScale : 32 * _iconScale;
			var iconh = this._toggleSprite.bitmap ? this._toggleSprite.bitmap.height * _iconScale : 32 * _iconScale;
			var hintH = this._toggleSprite._keyHintSprite && this._toggleSprite._keyHintSprite.bitmap ? this._toggleSprite._keyHintSprite.bitmap.height * _iconScale : 26 * _iconScale;
			var totalIconH = iconh + hintH;
	
			var textH = 64 + _colGoldSpacing; 
	
			startX = Math.min(startX, this._toggleSprite.x);
			startY = Math.min(startY, this._toggleSprite.y, this._toggleSprite.y + (iconh - textH) / 2);
			endX = Math.max(endX, this._toggleSprite.x + iconw);
			endY = Math.max(endY, this._toggleSprite.y + totalIconH, this._toggleSprite.y + (iconh + textH) / 2);
			
			if (this._isCollapsed && _showColTime) {
				if (_colTimeSide === 'left') {
					startX = Math.min(startX, this._toggleSprite.x - ((this._toggleSprite._timeTextSprite.bitmap.width + _colTimeSpacing) * _iconScale));
				} else {
					endX = Math.max(endX, this._toggleSprite.x + iconw + ((this._toggleSprite._timeTextSprite.bitmap.width + _colTimeSpacing) * _iconScale));
				}
			}
		}
		
		if (this._isCollapsed && this._toggleSprite) {
			var iconw = this._toggleSprite.bitmap ? this._toggleSprite.bitmap.width * _iconScale : 32 * _iconScale;
			var iconh = this._toggleSprite.bitmap ? this._toggleSprite.bitmap.height * _iconScale : 32 * _iconScale;
			var hintH = this._toggleSprite._keyHintSprite && this._toggleSprite._keyHintSprite.bitmap ? this._toggleSprite._keyHintSprite.bitmap.height * _iconScale : 26 * _iconScale;
			var totalIconH = iconh + hintH;
	
			startX = this._toggleSprite.x;
			startY = this._toggleSprite.y;
			endX = this._toggleSprite.x + iconw;
			endY = this._toggleSprite.y + totalIconH;
	
			if (_showColTime) {
				if (_colTimeSide === 'left') {
					startX -= ((this._toggleSprite._timeTextSprite.bitmap.width + _colTimeSpacing) * _iconScale);
				} else {
					endX += ((this._toggleSprite._timeTextSprite.bitmap.width + _colTimeSpacing) * _iconScale);
				}
				var textH = 64 + _colGoldSpacing;
				startY = Math.min(startY, this._toggleSprite.y + (iconh - textH) / 2);
				endY = Math.max(endY, this._toggleSprite.y + (iconh + textH) / 2);
			}
		}
	
		var isOverlapping = (px >= startX && px <= endX && py >= startY && py <= endY);
	
		var baseOpacity = this._isCollapsed ? _collapsedOpacity : _expandedOpacity;
		this._targetOpacity = isOverlapping ? _fadeOpacity : baseOpacity;
	
		if (this.contentsOpacity !== this._targetOpacity) {
			if (this.contentsOpacity < this._targetOpacity) {
				this.contentsOpacity = Math.min(this.contentsOpacity + 15, this._targetOpacity);
			} else {
				this.contentsOpacity = Math.max(this.contentsOpacity - 15, this._targetOpacity);
			}
			if (!this._customBg) {
				this.opacity = this.contentsOpacity; 
			} else {
				this._customBg.opacity = this.contentsOpacity;
			}
		}
	};

    Window_CompactTimeHud.prototype.measureRowWidth = function(iconId, text) {
        var w = this.textWidth(text);
        if (iconId > 0) w += Window_Base._iconWidth + _iconSpacing;
        return w;
    };
    
    Window_CompactTimeHud.prototype.calculateRequiredWidth = function() {
        var oldFontSize = this.contents.fontSize;
        this.contents.fontSize = 20; 

        var maxW = 0;
        
        var hrStr, ampmStr = "";
        if (_use24Hour) {
            hrStr = $gameSystem.hour().padZero(2);
        } else {
            hrStr = $gameSystem.hour_pm().padZero(2);
            ampmStr = $gameSystem.hour() >= 12 ? " PM" : " AM";
        }
        var min = $gameSystem.minute().padZero(2);
        var timeText = hrStr + " : " + min + ampmStr;
        maxW = Math.max(maxW, this.measureRowWidth(_iconR1, timeText));

        var dw = $gameSystem.day_week_name();
        var mo = $gameSystem.month().padZero(2);
        var da = $gameSystem.day().padZero(2);
        var yr = $gameSystem.year();
        var dateText = dw + ", " + mo + "/" + da + "/" + yr;
        maxW = Math.max(maxW, this.measureRowWidth(_iconR2, dateText));

        var seasonIdx = $gameSystem.season() - 1; 
        var seasonName = $gameSystem.season_name();
        var sPrefix = _seasonText.trim();
        var seasonDisplay = sPrefix ? sPrefix + " " + seasonName : seasonName;

        if (_seasonIcons.length > 0 && _seasonIcons[seasonIdx] !== undefined) {
            maxW = Math.max(maxW, this.measureRowWidth(Number(_seasonIcons[seasonIdx]), seasonDisplay));
        } else {
            maxW = Math.max(maxW, this.measureRowWidth(0, seasonDisplay));
        }

        var goldVal = $gameParty.gold();
        var formattedGold = formatNumberWithCommas(goldVal);
        var prefix = _goldText.trim();
        var goldDisplay = prefix ? prefix + " " + formattedGold : formattedGold;
        maxW = Math.max(maxW, this.measureRowWidth(_iconGold, goldDisplay));

        this.contents.fontSize = oldFontSize;
        return maxW + (this.padding * 2) + 24; 
    };
    
    Window_CompactTimeHud.prototype.updateCustomBgScale = function() {
        if (this._customBg && this._customBg.bitmap && this._customBg.bitmap.isReady()) {
            this._customBg.scale.x = this.width / this._customBg.bitmap.width;
            this._customBg.scale.y = this.height / this._customBg.bitmap.height;
        }
    };

    Window_CompactTimeHud.prototype.refresh = function() {
        var newW = this.calculateRequiredWidth();
        var newH = this.fittingHeight(4); 
        
        if (this.width !== newW || this.height !== newH) {
            this.width = newW;
            this.height = newH;
            this.createContents(); 
            this.updateCustomBgScale();
            this.updatePosition(); 
        }
        
        this.contents.clear();
        this.contents.fontSize = 20;
        var lh = this.lineHeight();
        
        var hrStr, ampmStr = "";
        if (_use24Hour) {
            hrStr = $gameSystem.hour().padZero(2);
        } else {
            hrStr = $gameSystem.hour_pm().padZero(2);
            ampmStr = $gameSystem.hour() >= 12 ? " PM" : " AM";
        }
        var min = $gameSystem.minute().padZero(2);
        var timeText = hrStr + " : " + min + ampmStr;
        this.drawGroupedRow(_iconR1, timeText, 0, _textAlign, _iconSpacing);

        var dw = $gameSystem.day_week_name();
        var mo = $gameSystem.month().padZero(2);
        var da = $gameSystem.day().padZero(2);
        var yr = $gameSystem.year();
        var dateText = dw + ", " + mo + "/" + da + "/" + yr;
        this.drawGroupedRow(_iconR2, dateText, lh, _textAlign, _iconSpacing);

        var seasonIdx = $gameSystem.season() - 1; 
        var seasonName = $gameSystem.season_name();
        var sPrefix = _seasonText.trim();
        var seasonDisplay = sPrefix ? sPrefix + " " + seasonName : seasonName;
        
        if (_seasonIcons.length > 0 && _seasonIcons[seasonIdx] !== undefined) {
            var sIconId = Number(_seasonIcons[seasonIdx]);
            this.drawGroupedRow(sIconId, seasonDisplay, lh * 2, _textAlign, _iconSpacing);
        } else {
            this.drawGroupedRow(0, seasonDisplay, lh * 2, _textAlign, _iconSpacing);
        }

        var goldVal = $gameParty.gold();
        var formattedGold = formatNumberWithCommas(goldVal);
        var prefix = _goldText.trim();
        var goldDisplay = prefix ? prefix + " " + formattedGold : formattedGold;
        
        this.drawGroupedRow(_iconGold, goldDisplay, lh * 3, _textAlign, _iconSpacing);
    };

    Window_CompactTimeHud.prototype.drawGroupedRow = function(iconId, text, y, align, gap) {
        var textW = this.textWidth(text);
        var iconW = (iconId > 0) ? Window_Base._iconWidth : 0;
        var totalW = iconW;
        if (iconW > 0 && textW > 0) totalW += gap;
        totalW += textW;
        
        var startX = 0;
        if (align === 'center') {
            startX = (this.contentsWidth() - totalW) / 2;
        } else if (align === 'right') {
            startX = this.contentsWidth() - totalW;
        }

        if (iconId > 0) {
            this.drawIcon(iconId, startX, y);
            this.drawText(text, startX + iconW + gap, y, textW, 'left');
        } else {
            this.drawText(text, startX, y, textW, 'left');
        }
    };
})();