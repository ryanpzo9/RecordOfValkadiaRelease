//=============================================================================
// JR_MessageAutoConversation.js
//=============================================================================

var Imported = Imported || {};
Imported.JR_MessageAutoConversation = true;

var JR = JR || {};
JR.MAC = JR.MAC || {};
JR.MAC.version = 1.42;

//=============================================================================
/*:
 * @plugindesc v1.42 Adds an "Auto Conversation" option to auto-advance messages with icon-based status display and toggle.
 * Requires YEP_MessageCore.js.
 * @author James Ryan
 *
 * @param Auto Conversation Label
 * @desc The text displayed for the Auto Conversation option in the Options menu.
 * @default Auto Conversation
 *
 * @param Auto Delay
 * @desc Delay in frames between auto-advancing messages (60 frames = 1 second).
 * @type number
 * @min 1
 * @default 60
 *
 * @param Play Enabled Button
 * @desc Image for the Play button when auto-conversation is enabled. Type 'None' or leave empty to use Icon mode.
 * @type combo
 * @option None
 * @default None
 *
 * @param Play Disabled Button
 * @desc Image for the Play button when auto-conversation is disabled. Type 'None' or leave empty to use Icon mode.
 * @type combo
 * @option None
 * @default None
 * 
 * @param Play Button Icon
 * @desc Icon index to use if Play Button image is set to None.
 * @type number
 * @default 73
 * 
 * @param Play Icon Scale
 * @desc Scale of the Play icon (percentage) if using Icon Mode. 100 = default size.
 * @type number
 * @min 1
 * @default 100
 * 
 * @param Play Icon Rotation
 * @desc Rotation of the Play icon (in degrees) if using Icon Mode. 0 = default.
 * @type number
 * @default 0
 * 
 * @param Play Button Text
 * @desc Text displayed below the Play icon to show the hotkey.
 * @default Alt
 *
 * @param Play Button Width
 * @desc Width of the Play button (in pixels). Resizes the image to this width (Ignored in Icon mode).
 * @type number
 * @min 1
 * @default 32
 *
 * @param Play Button Height
 * @desc Height of the Play button (in pixels). Resizes the image to this height (Ignored in Icon mode).
 * @type number
 * @min 1
 * @default 32
 *
 * @param Play Button X Offset
 * @desc X offset of the Play button relative to the name box's right edge (positive = right, negative = left).
 * @type number
 * @min -9999
 * @default 10
 *
 * @param Play Button Y Offset
 * @desc Y offset of the Play button relative to the name box's top (positive = down, negative = up).
 * @type number
 * @min -9999
 * @default 0
 *
 * @param Fast-Forward Enabled Button
 * @desc Image for the Fast-Forward button when Shift is held. Type 'None' or leave empty to use Icon mode.
 * @type combo
 * @option None
 * @default None
 *
 * @param Fast-Forward Disabled Button
 * @desc Image for the Fast-Forward button when Shift is not held. Type 'None' or leave empty to use Icon mode.
 * @type combo
 * @option None
 * @default None
 * 
 * @param Fast-Forward Button Icon
 * @desc Icon index to use if Fast-Forward Button image is set to None.
 * @type number
 * @default 140
 * 
 * @param Fast-Forward Icon Scale
 * @desc Scale of the Fast-Forward icon (percentage) if using Icon Mode. 100 = default size.
 * @type number
 * @min 1
 * @default 100
 * 
 * @param Fast-Forward Icon Rotation
 * @desc Rotation of the Fast-Forward icon (in degrees) if using Icon Mode. 0 = default.
 * @type number
 * @default 0
 * 
 * @param Fast-Forward Button Text
 * @desc Text displayed below the Fast-Forward icon to show the hotkey.
 * @default Shift
 *
 * @param Fast-Forward Button Width
 * @desc Width of the Fast-Forward button (in pixels). Resizes the image to this width (Ignored in Icon mode).
 * @type number
 * @min 1
 * @default 32
 *
 * @param Fast-Forward Button Height
 * @desc Height of the Fast-Forward button (in pixels). Resizes the image to this height (Ignored in Icon mode).
 * @type number
 * @min 1
 * @default 32
 *
 * @param Fast-Forward Button X Offset
 * @desc X offset of the Fast-Forward button relative to the Play button's right edge (positive = right, negative = left).
 * @type number
 * @min -9999
 * @default 5
 *
 * @param Fast-Forward Button Y Offset
 * @desc Y offset of the Fast-Forward button relative to the Play button's top (positive = down, negative = up).
 * @type number
 * @min -9999
 * @default 0
 * 
 * @param Button Text Size
 * @desc Font size for the text displayed below the icons (Only applies in Icon mode).
 * @type number
 * @min 1
 * @default 16
 *
 * @param Message Box Above X Offset
 * @desc X offset of the Play button when placed above the message box (no namebox, message box at bottom).
 * @type number
 * @min -9999
 * @default 10
 *
 * @param Message Box Above Y Offset
 * @desc Y offset of the Play button when placed above the message box (no namebox, message box at bottom).
 * @type number
 * @min -9999
 * @default -10
 *
 * @param Message Box Below X Offset
 * @desc X offset of the Play button when placed below the message box (no namebox, message box not at bottom).
 * @type number
 * @min -9999
 * @default 10
 *
 * @param Message Box Below Y Offset
 * @desc Y offset of the Play button when placed below the message box (no namebox, message box not at bottom).
 * @type number
 * @min -9999
 * @default 10
 *
 * @param Breathing Time
 * @desc Time in seconds for one complete breathing cycle (max to min opacity and back) for enabled buttons.
 * @type number
 * @min 0.1
 * @decimals 1
 * @default 2.0
 *
 * @param Min Breathing Opacity
 * @desc Minimum opacity of the breathing effect for enabled buttons (0-255).
 * @type number
 * @min 0
 * @max 255
 * @default 100
 *
 * @param Max Breathing Opacity
 * @desc Maximum opacity of the breathing effect for enabled buttons (0-255).
 * @type number
 * @min 0
 * @max 255
 * @default 255
 *
 * @help
 * ============================================================================
 * Introduction
 * ============================================================================
 *
 * This plugin requires YEP_MessageCore.js to function. Place 
 * JR_MessageAutoConversation.js below YEP_MessageCore.js in the plugin list.
 *
 * This plugin adds an "Auto Conversation" option to auto-advance messages, 
 * with an icon-based status display next to the YEP_MessageCore name box. 
 * - Play Button: Shows the auto-conversation state (enabled/disabled).
 * - Fast-Forward Button: Shows the fast-forward state (enabled when holding Shift, disabled otherwise).
 * The "Auto Conversation" option in the Options menu acts as a master switch:
 * - ON: Enables the plugin, allowing auto-advance, Alt toggle, and showing buttons.
 * - OFF: Disables the plugin entirely (no auto-advance, no Alt toggle, no buttons), but does not interfere with YEP_MessageCore's Shift fast-forward feature.
 *
 * ============================================================================
 * Compatibility
 * ============================================================================
 *
 * Designed for YEP_MessageCore.js. Compatible with YEP_X_MessageBacklog.js.
 * Test with other message plugins (e.g., YEP_X_ExtMesPack1.js) for compatibility.
 */
//=============================================================================

if (Imported.YEP_MessageCore) {

//=============================================================================
// Parameter Variables
//=============================================================================

JR.Parameters = PluginManager.parameters('JR_MessageAutoConversation');
JR.Param = JR.Param || {};

JR.MAC.isNone = function(str) {
    return !str || str.trim().toLowerCase() === 'none' || str.trim() === '';
};

JR.Param.MACAutoLabel = String(JR.Parameters['Auto Conversation Label']) || 'Auto Conversation';
JR.Param.MACAutoDelay = Number(JR.Parameters['Auto Delay']) || 60;
JR.Param.MACPlayEnabledButton = String(JR.Parameters['Play Enabled Button'] || '');
JR.Param.MACPlayDisabledButton = String(JR.Parameters['Play Disabled Button'] || '');
JR.Param.MACPlayButtonIcon = Number(JR.Parameters['Play Button Icon']) || 0;
JR.Param.MACPlayIconScale = Number(JR.Parameters['Play Icon Scale']) || 100;
JR.Param.MACPlayIconRotation = Number(JR.Parameters['Play Icon Rotation']) || 0;
JR.Param.MACPlayButtonText = String(JR.Parameters['Play Button Text'] || '');
JR.Param.MACPlayButtonWidth = Number(JR.Parameters['Play Button Width']) || 32;
JR.Param.MACPlayButtonHeight = Number(JR.Parameters['Play Button Height']) || 32;
JR.Param.MACPlayButtonXOffset = Number(JR.Parameters['Play Button X Offset']) || 10;
JR.Param.MACPlayButtonYOffset = Number(JR.Parameters['Play Button Y Offset']) || 0;

JR.Param.MACFastForwardEnabledButton = String(JR.Parameters['Fast-Forward Enabled Button'] || '');
JR.Param.MACFastForwardDisabledButton = String(JR.Parameters['Fast-Forward Disabled Button'] || '');
JR.Param.MACFastForwardButtonIcon = Number(JR.Parameters['Fast-Forward Button Icon']) || 0;
JR.Param.MACFastForwardIconScale = Number(JR.Parameters['Fast-Forward Icon Scale']) || 100;
JR.Param.MACFastForwardIconRotation = Number(JR.Parameters['Fast-Forward Icon Rotation']) || 0;
JR.Param.MACFastForwardButtonText = String(JR.Parameters['Fast-Forward Button Text'] || '');
JR.Param.MACFastForwardButtonWidth = Number(JR.Parameters['Fast-Forward Button Width']) || 32;
JR.Param.MACFastForwardButtonHeight = Number(JR.Parameters['Fast-Forward Button Height']) || 32;
JR.Param.MACFastForwardButtonXOffset = Number(JR.Parameters['Fast-Forward Button X Offset']) || 5;
JR.Param.MACFastForwardButtonYOffset = Number(JR.Parameters['Fast-Forward Button Y Offset']) || 0;

JR.Param.MACButtonTextSize = Number(JR.Parameters['Button Text Size']) || 16;

JR.Param.MACMessageBoxAboveXOffset = Number(JR.Parameters['Message Box Above X Offset']) || 10;
JR.Param.MACMessageBoxAboveYOffset = Number(JR.Parameters['Message Box Above Y Offset']) || -10;
JR.Param.MACMessageBoxBelowXOffset = Number(JR.Parameters['Message Box Below X Offset']) || 10;
JR.Param.MACMessageBoxBelowYOffset = Number(JR.Parameters['Message Box Below Y Offset']) || 10;
JR.Param.MACBreathingTime = Number(JR.Parameters['Breathing Time']) || 2.0;
JR.Param.MACMinBreathingOpacity = Number(JR.Parameters['Min Breathing Opacity']) || 100;
JR.Param.MACMaxBreathingOpacity = Number(JR.Parameters['Max Breathing Opacity']) || 255;

//=============================================================================
// ConfigManager
//=============================================================================

ConfigManager.autoConversationEnabled = false; 
ConfigManager.autoConversationActive = false; 

JR.MAC.ConfigManager_makeData = ConfigManager.makeData;
ConfigManager.makeData = function() {
    var config = JR.MAC.ConfigManager_makeData.call(this);
    config.autoConversationEnabled = this.autoConversationEnabled;
    config.autoConversationActive = this.autoConversationActive;
    return config;
};

JR.MAC.ConfigManager_applyData = ConfigManager.applyData;
ConfigManager.applyData = function(config) {
    JR.MAC.ConfigManager_applyData.call(this, config);
    this.autoConversationEnabled = this.readAutoConversation(config, 'autoConversationEnabled');
    this.autoConversationActive = this.readAutoConversation(config, 'autoConversationActive');
};

ConfigManager.readAutoConversation = function(config, key) {
    if (config.hasOwnProperty(key)) {
        return config[key];
    } else {
        return false; 
    }
};

//=============================================================================
// Window_Options
//=============================================================================

JR.MAC.Window_Options_addGeneralOptions = Window_Options.prototype.addGeneralOptions;
Window_Options.prototype.addGeneralOptions = function() {
    JR.MAC.Window_Options_addGeneralOptions.call(this);
    this.addCommand(JR.Param.MACAutoLabel, 'autoConversationEnabled');
};

//=============================================================================
// Scene_Map
//=============================================================================

JR.MAC.Scene_Map_createAllWindows = Scene_Map.prototype.createAllWindows;
Scene_Map.prototype.createAllWindows = function() {
    JR.MAC.Scene_Map_createAllWindows.call(this);
    this._autoConversationStatusSprite = new Sprite_AutoConversationStatus(this._messageWindow);
    this.addChild(this._autoConversationStatusSprite);
};

//=============================================================================
// Window_Message
//=============================================================================

JR.MAC.Window_Message_initialize = Window_Message.prototype.initialize;
Window_Message.prototype.initialize = function() {
    JR.MAC.Window_Message_initialize.call(this);
    this._autoTimer = 0;
    this._isFastForwarding = false;
    this._ffTouchHeld = false; // Tracks if the player is currently holding down the touch/mouse on the FF button
};

JR.MAC.Window_Message_update = Window_Message.prototype.update;
Window_Message.prototype.update = function() {
    JR.MAC.Window_Message_update.call(this);
    
    if (ConfigManager.autoConversationEnabled && !(SceneManager._scene instanceof Scene_Battle) && this.isOpen() && this.active) {
        this.updateAutoToggle();
        this.updateFastForward(); 
        if (ConfigManager.autoConversationActive) {
            this.updateAutoConversation();
        } else {
            this._autoTimer = 0;
        }
    } else {
        this._autoTimer = 0;
        this._isFastForwarding = false;
    }
    
    if (ConfigManager.autoConversationEnabled && !(SceneManager._scene instanceof Scene_Battle) && SceneManager._scene._autoConversationStatusSprite) {
        SceneManager._scene._autoConversationStatusSprite.updatePositionAndIcons(this);
    }
};

// Intercept touch input so clicking the custom buttons won't advance the message window dialogue
JR.MAC.Window_Message_updateInput = Window_Message.prototype.updateInput;
Window_Message.prototype.updateInput = function() {
    var sprite = SceneManager._scene && SceneManager._scene._autoConversationStatusSprite;
    if (sprite && sprite.visible && ConfigManager.autoConversationEnabled) {
        if (TouchInput.isTriggered() && (sprite.isTouchInPlayRect() || sprite.isTouchInFFRect())) {
            return true; 
        }
    }
    return JR.MAC.Window_Message_updateInput.call(this);
};

Window_Message.prototype.updateAutoToggle = function() {
    var sprite = SceneManager._scene && SceneManager._scene._autoConversationStatusSprite;
    var playClicked = sprite && sprite.isTouchInPlayRect() && TouchInput.isTriggered();

    if (Input.isTriggered('alt') || playClicked) {
        var wasActive = ConfigManager.autoConversationActive;
        ConfigManager.autoConversationActive = !ConfigManager.autoConversationActive;
        SoundManager.playOk();
        if (!wasActive && ConfigManager.autoConversationActive) {
            if ((this.isMessageFullyDisplayed() || !this._textState) && !this.isWaitingForInput()) {
                this.advanceMessage();
            }
        }
        if (!ConfigManager.autoConversationActive && this.isOpen() && !this.isAnySubWindowActive()) {
            this.activate();
        }
    }
};

Window_Message.prototype.updateFastForward = function() {
    var sprite = SceneManager._scene && SceneManager._scene._autoConversationStatusSprite;
    
    // Check if the touch input is active. If released, break the hold.
    if (!TouchInput.isPressed()) {
        this._ffTouchHeld = false;
    } 
    // If the input is active and hovering over the button, lock it on.
    else if (sprite && sprite.isTouchInFFRect()) {
        this._ffTouchHeld = true;
    }

    this._isFastForwarding = Input.isPressed('shift') || this._ffTouchHeld;
    if (this._isFastForwarding) {
        this._showFast = true;
        this._waitCount = 0;
    } else {
        this._showFast = false;
    }
};

Window_Message.prototype.updateAutoConversation = function() {
    if (this.isWaitingForInput()) {
        this._autoTimer = 0;
        return;
    }

    this.pause = false;
    if (this.isMessageFullyDisplayed() || (!this._textState && $gameMessage.hasText())) {
        var effectiveDelay = this._isFastForwarding ? Math.floor(JR.Param.MACAutoDelay / 4) : JR.Param.MACAutoDelay;
        this._autoTimer++;
        if (this._autoTimer >= effectiveDelay) {
            this._autoTimer = 0;
            this._waitCount = 0;
            this.advanceMessage();
        }
    }
};

Window_Message.prototype.isWaitingForInput = function() {
    return $gameMessage.isChoice() || $gameMessage.isNumberInput() || 
           $gameMessage.isItemChoice() || this._choiceWindow.active || 
           this._numberWindow.active || this._itemWindow.active;
};

Window_Message.prototype.isMessageFullyDisplayed = function() {
    return this._textState && this._textState.index >= this._textState.text.length;
};

Window_Message.prototype.advanceMessage = function() {
    this.terminateMessage();
    if ($gameMessage.hasText()) {
        this.startMessage();
    }
};

JR.MAC.Window_Message_terminateMessage = Window_Message.prototype.terminateMessage;
Window_Message.prototype.terminateMessage = function() {
    JR.MAC.Window_Message_terminateMessage.call(this);
    this._textState = null;
    if ((ConfigManager.autoConversationEnabled && ConfigManager.autoConversationActive) && $gameMessage.hasText()) {
        $gameMessage._texts.shift();
    }
    if (!(ConfigManager.autoConversationEnabled && ConfigManager.autoConversationActive) && this.isOpen() && !this.isAnySubWindowActive()) {
        this.activate();
    }
};

JR.MAC.Window_Message_updateBacklogInput = Window_Message.prototype.updateBacklogInput;
Window_Message.prototype.updateBacklogInput = function() {
    JR.MAC.Window_Message_updateBacklogInput.call(this);
    if (ConfigManager.autoConversationEnabled) {
        if (!this.isOpen() || !$gameMessage.hasText()) return;
        if (ConfigManager.autoConversationActive) return;
        if (this.isAnySubWindowActive()) return;
        if (!$gameSystem.isMessageBacklogKeyEnabled()) return;
        if (Input.isTriggered(Yanfly.Param.MsgBacklogKeyButton)) {
            this.openBacklogWindow();
        }
    }
};

//=============================================================================
// Sprite_AutoConversationStatus
//=============================================================================

function Sprite_AutoConversationStatus() {
    this.initialize.apply(this, arguments);
}

Sprite_AutoConversationStatus.prototype = Object.create(Sprite.prototype);
Sprite_AutoConversationStatus.prototype.constructor = Sprite_AutoConversationStatus;

Sprite_AutoConversationStatus.prototype.initialize = function(messageWindow) {
    Sprite.prototype.initialize.call(this);
    this._messageWindow = messageWindow;
    
    this._playEnabledBitmap = !JR.MAC.isNone(JR.Param.MACPlayEnabledButton) ? ImageManager.loadSystem(JR.Param.MACPlayEnabledButton) : null;
    this._playDisabledBitmap = !JR.MAC.isNone(JR.Param.MACPlayDisabledButton) ? ImageManager.loadSystem(JR.Param.MACPlayDisabledButton) : null;
    this._fastForwardEnabledBitmap = !JR.MAC.isNone(JR.Param.MACFastForwardEnabledButton) ? ImageManager.loadSystem(JR.Param.MACFastForwardEnabledButton) : null;
    this._fastForwardDisabledBitmap = !JR.MAC.isNone(JR.Param.MACFastForwardDisabledButton) ? ImageManager.loadSystem(JR.Param.MACFastForwardDisabledButton) : null;
    
    this._iconsetBitmap = ImageManager.loadSystem('IconSet');

    this._playSprite = new Sprite();
    this._playImageSprite = new Sprite();
    this._playIconContainer = new Sprite();
    this._playIconSprite = new Sprite();
    this._playTextSprite = new Sprite();
    
    this._playIconContainer.addChild(this._playIconSprite);
    this._playIconContainer.addChild(this._playTextSprite);
    this._playSprite.addChild(this._playImageSprite);
    this._playSprite.addChild(this._playIconContainer);

    this._fastForwardSprite = new Sprite();
    this._ffImageSprite = new Sprite();
    this._ffIconContainer = new Sprite();
    this._ffIconSprite = new Sprite();
    this._ffTextSprite = new Sprite();
    
    this._ffIconContainer.addChild(this._ffIconSprite);
    this._ffIconContainer.addChild(this._ffTextSprite);
    this._fastForwardSprite.addChild(this._ffImageSprite);
    this._fastForwardSprite.addChild(this._ffIconContainer);

    this.addChild(this._playSprite);
    this.addChild(this._fastForwardSprite);
    
    this._breathTimer = 0;
    this._breathCycle = JR.Param.MACBreathingTime * 60; 
    this.visible = false; 

    this._playHitRect = null;
    this._ffHitRect = null;
    
    this.updatePositionAndIcons(messageWindow);
};

Sprite_AutoConversationStatus.prototype.update = function() {
    Sprite.prototype.update.call(this);
    if (ConfigManager.autoConversationEnabled) {
        this.updateIconStates();
        this.updateBreathing();
    }
};

Sprite_AutoConversationStatus.prototype.updateIconStates = function() {
    // -------------------------------------------------------------
    // PLAY BUTTON UPDATE
    // -------------------------------------------------------------
    var playHasImage = !JR.MAC.isNone(JR.Param.MACPlayEnabledButton) || !JR.MAC.isNone(JR.Param.MACPlayDisabledButton);
    if (playHasImage) {
        this._playImageSprite.visible = true;
        this._playIconContainer.visible = false;
        this._playImageSprite.bitmap = ConfigManager.autoConversationActive ? this._playEnabledBitmap : this._playDisabledBitmap;
        if (this._playImageSprite.bitmap) {
            this._playImageSprite.scale.x = JR.Param.MACPlayButtonWidth / this._playImageSprite.bitmap.width;
            this._playImageSprite.scale.y = JR.Param.MACPlayButtonHeight / this._playImageSprite.bitmap.height;
        }
    } else {
        this._playImageSprite.visible = false;
        this._playIconContainer.visible = true;
        
        var pScale = JR.Param.MACPlayIconScale / 100;
        var pSize = 32 * pScale;
        var pIcon = JR.Param.MACPlayButtonIcon;
        
        if (!this._playIconSprite.bitmap) {
            this._playIconSprite.bitmap = new Bitmap(32, 32);
            this._playIconSprite.anchor.x = 0.5;
            this._playIconSprite.anchor.y = 0.5;
            this._playIconSprite.x = pSize / 2;
            this._playIconSprite.y = pSize / 2;
            this._playIconDrawn = false;
        }
        
        if (!this._playIconDrawn && this._iconsetBitmap.isReady()) {
            this._playIconSprite.bitmap.clear();
            var sx = pIcon % 16 * 32;
            var sy = Math.floor(pIcon / 16) * 32;
            this._playIconSprite.bitmap.blt(this._iconsetBitmap, sx, sy, 32, 32, 0, 0);
            this._playIconDrawn = true;
        }
        
        this._playIconSprite.scale.x = pScale;
        this._playIconSprite.scale.y = pScale;
        this._playIconSprite.rotation = JR.Param.MACPlayIconRotation * Math.PI / 180;

        if (!this._playTextSprite.bitmap) {
            this._playTextSprite.bitmap = new Bitmap(120, JR.Param.MACButtonTextSize + 4);
            this._playTextSprite.bitmap.fontSize = JR.Param.MACButtonTextSize;
            this._playTextSprite.bitmap.drawText(JR.Param.MACPlayButtonText, 0, 0, 120, JR.Param.MACButtonTextSize + 4, 'center');
            this._playTextSprite.anchor.x = 0.5;
            this._playTextSprite.x = pSize / 2;
            this._playTextSprite.y = pSize + 2;
        }
    }
    
    // -------------------------------------------------------------
    // FAST-FORWARD BUTTON UPDATE
    // -------------------------------------------------------------
    var ffHasImage = !JR.MAC.isNone(JR.Param.MACFastForwardEnabledButton) || !JR.MAC.isNone(JR.Param.MACFastForwardDisabledButton);
    if (ffHasImage) {
        this._ffImageSprite.visible = true;
        this._ffIconContainer.visible = false;
        this._ffImageSprite.bitmap = this._messageWindow._isFastForwarding ? this._fastForwardEnabledBitmap : this._fastForwardDisabledBitmap;
        if (this._ffImageSprite.bitmap) {
            this._ffImageSprite.scale.x = JR.Param.MACFastForwardButtonWidth / this._ffImageSprite.bitmap.width;
            this._ffImageSprite.scale.y = JR.Param.MACFastForwardButtonHeight / this._ffImageSprite.bitmap.height;
        }
    } else {
        this._ffImageSprite.visible = false;
        this._ffIconContainer.visible = true;
        
        var fScale = JR.Param.MACFastForwardIconScale / 100;
        var fSize = 32 * fScale;
        var fIcon = JR.Param.MACFastForwardButtonIcon;
        
        if (!this._ffIconSprite.bitmap) {
            this._ffIconSprite.bitmap = new Bitmap(32, 32);
            this._ffIconSprite.anchor.x = 0.5;
            this._ffIconSprite.anchor.y = 0.5;
            this._ffIconSprite.x = fSize / 2;
            this._ffIconSprite.y = fSize / 2;
            this._ffIconDrawn = false;
        }
        
        if (!this._ffIconDrawn && this._iconsetBitmap.isReady()) {
            this._ffIconSprite.bitmap.clear();
            var fx = fIcon % 16 * 32;
            var fy = Math.floor(fIcon / 16) * 32;
            this._ffIconSprite.bitmap.blt(this._iconsetBitmap, fx, fy, 32, 32, 0, 0);
            this._ffIconDrawn = true;
        }
        
        this._ffIconSprite.scale.x = fScale;
        this._ffIconSprite.scale.y = fScale;
        this._ffIconSprite.rotation = JR.Param.MACFastForwardIconRotation * Math.PI / 180;

        if (!this._ffTextSprite.bitmap) {
            this._ffTextSprite.bitmap = new Bitmap(120, JR.Param.MACButtonTextSize + 4);
            this._ffTextSprite.bitmap.fontSize = JR.Param.MACButtonTextSize;
            this._ffTextSprite.bitmap.drawText(JR.Param.MACFastForwardButtonText, 0, 0, 120, JR.Param.MACButtonTextSize + 4, 'center');
            this._ffTextSprite.anchor.x = 0.5;
            this._ffTextSprite.x = fSize / 2;
            this._ffTextSprite.y = fSize + 2;
        }
    }
};

Sprite_AutoConversationStatus.prototype.updateBreathing = function() {
    if (!this.visible) return;
    this._breathTimer = (this._breathTimer + 1) % this._breathCycle;
    var t = (this._breathTimer / this._breathCycle) * Math.PI * 2;
    var amplitude = (JR.Param.MACMaxBreathingOpacity - JR.Param.MACMinBreathingOpacity) / 2;
    var offset = JR.Param.MACMinBreathingOpacity + amplitude;
    var newOpacity = Math.round(offset + amplitude * Math.sin(t));

    this._playSprite.opacity = ConfigManager.autoConversationActive ? newOpacity : 255;
    this._fastForwardSprite.opacity = this._messageWindow._isFastForwarding ? newOpacity : 255;
};

Sprite_AutoConversationStatus.prototype.updatePositionAndIcons = function(messageWindow) {
    var isBacklogOpen = false;
    if (Imported.YEP_X_MessageBacklog && messageWindow._backlogWindow) {
        isBacklogOpen = messageWindow._backlogWindow.isOpenAndActive();
    }

    if (ConfigManager.autoConversationEnabled && messageWindow.isOpen() && !isBacklogOpen) {
        this.x = 0;
        this.y = 0;
        
        var playHasImage = !JR.MAC.isNone(JR.Param.MACPlayEnabledButton) || !JR.MAC.isNone(JR.Param.MACPlayDisabledButton);
        var ffHasImage = !JR.MAC.isNone(JR.Param.MACFastForwardEnabledButton) || !JR.MAC.isNone(JR.Param.MACFastForwardDisabledButton);

        var playWidth = playHasImage ? JR.Param.MACPlayButtonWidth : (32 * JR.Param.MACPlayIconScale / 100);
        var playHeight = playHasImage ? JR.Param.MACPlayButtonHeight : (32 * JR.Param.MACPlayIconScale / 100 + JR.Param.MACButtonTextSize + 6);
        
        var ffWidth = ffHasImage ? JR.Param.MACFastForwardButtonWidth : (32 * JR.Param.MACFastForwardIconScale / 100);
        var ffHeight = ffHasImage ? JR.Param.MACFastForwardButtonHeight : (32 * JR.Param.MACFastForwardIconScale / 100 + JR.Param.MACButtonTextSize + 6);

        var nameWindowVisible = messageWindow._nameWindow && messageWindow._nameWindow.visible && messageWindow._nameWindow.isOpen();
        if (nameWindowVisible) {
            var nameWindow = messageWindow._nameWindow;
            this._playSprite.x = nameWindow.x + nameWindow.width + JR.Param.MACPlayButtonXOffset;
            this._playSprite.y = nameWindow.y + JR.Param.MACPlayButtonYOffset;
        } else {
            var messageBoxBottom = messageWindow.y + messageWindow.height;
            var isAtBottom = messageBoxBottom >= Graphics.boxHeight - 10; 
            
            if (isAtBottom) {
                this._playSprite.x = JR.Param.MACMessageBoxAboveXOffset;
                this._playSprite.y = messageWindow.y - playHeight + JR.Param.MACMessageBoxAboveYOffset;
            } else {
                this._playSprite.x = JR.Param.MACMessageBoxBelowXOffset;
                this._playSprite.y = messageBoxBottom + JR.Param.MACMessageBoxBelowYOffset;
            }
        }

        this._fastForwardSprite.x = this._playSprite.x + playWidth + JR.Param.MACFastForwardButtonXOffset;
        this._fastForwardSprite.y = this._playSprite.y + JR.Param.MACFastForwardButtonYOffset;

        var playRightEdge = this._playSprite.x + playWidth;
        if (playRightEdge > Graphics.boxWidth) {
            this._playSprite.x = Graphics.boxWidth - playWidth;
        }
        if (this._playSprite.y < 0) {
            this._playSprite.y = 0;
        }

        var ffRightEdge = this._fastForwardSprite.x + ffWidth;
        if (ffRightEdge > Graphics.boxWidth) {
            this._fastForwardSprite.x = Graphics.boxWidth - ffWidth;
        }
        if (this._fastForwardSprite.y < 0) {
            this._fastForwardSprite.y = 0;
        }

        this._playHitRect = new Rectangle(this._playSprite.x, this._playSprite.y, playWidth, playHeight);
        this._ffHitRect = new Rectangle(this._fastForwardSprite.x, this._fastForwardSprite.y, ffWidth, ffHeight);

        this.visible = true;
    } else {
        this.visible = false;
        this._playSprite.x = 0;
        this._playSprite.y = 0;
        this._fastForwardSprite.x = 0;
        this._fastForwardSprite.y = 0;
        this._playHitRect = null;
        this._ffHitRect = null;
    }
};

Sprite_AutoConversationStatus.prototype.isTouchInPlayRect = function() {
    if (!this.visible || !this._playHitRect) return false;
    var tx = TouchInput.x;
    var ty = TouchInput.y;
    return tx >= this._playHitRect.x && tx <= this._playHitRect.x + this._playHitRect.width &&
           ty >= this._playHitRect.y && ty <= this._playHitRect.y + this._playHitRect.height;
};

Sprite_AutoConversationStatus.prototype.isTouchInFFRect = function() {
    if (!this.visible || !this._ffHitRect) return false;
    var tx = TouchInput.x;
    var ty = TouchInput.y;
    return tx >= this._ffHitRect.x && tx <= this._ffHitRect.x + this._ffHitRect.width &&
           ty >= this._ffHitRect.y && ty <= this._ffHitRect.y + this._ffHitRect.height;
};

//=============================================================================
// Game_Message
//=============================================================================

JR.MAC.Game_Message_clear = Game_Message.prototype.clear;
Game_Message.prototype.clear = function() {
    JR.MAC.Game_Message_clear.call(this);
    if (SceneManager._scene && SceneManager._scene._messageWindow) {
        SceneManager._scene._messageWindow._autoTimer = 0;
        SceneManager._scene._messageWindow._isFastForwarding = false;
    }
};

//=============================================================================
// End of File
//=============================================================================

} else {
    console.error('JR_MessageAutoConversation.js requires YEP_MessageCore.js to be installed and loaded.');
}