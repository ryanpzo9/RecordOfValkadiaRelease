//=============================================================================
// JR_GalvToolHUD.js
//=============================================================================

/*:
 * @plugindesc Extends Galv's Tools by replacing the HUD with interactive, dynamic touch/mouse buttons based on JR_QuestTracker logic.
 * @author JR
 *
 * @param Disable Original HUD
 * @type boolean
 * @desc Set to true to hide Galv's original HUD and only use this one.
 * @default true
 *
 * @param Transparent Opacity
 * @type number
 * @min 0
 * @max 255
 * @desc Opacity of the buttons when the player walks behind them.
 * @default 100
 *
 * @param Custom Key Codes
 * @desc Map custom keys to keyboard codes. Format: "key:code, key:code". E.g. "q:81, f:70, w:87"
 * @default q:81, f:70, w:87
 *
 * @param --- Tool Button (Red) ---
 * @default
 *
 * @param Tool Key
 * @parent --- Tool Button (Red) ---
 * @desc Keys to use the tool (e.g., f, alt, pageup). Separate multiple with commas.
 * @default f, alt
 *
 * @param Tool Button Text
 * @parent --- Tool Button (Red) ---
 * @desc Custom text to show in the brackets. Leave blank to use the first Tool Key value.
 * @default 
 *
 * @param Tool Text Spacing
 * @parent --- Tool Button (Red) ---
 * @type number
 * @min -999
 * @desc The vertical spacing (in pixels) between the button and its text.
 * @default 2
 *
 * @param Tool X
 * @parent --- Tool Button (Red) ---
 * @desc X position of the main tool button. Variables: w, h, toolw, toolh
 * @default (w / 2) - (toolw / 2)
 *
 * @param Tool Y
 * @parent --- Tool Button (Red) ---
 * @desc Y position of the main tool button. Variables: w, h, toolw, toolh
 * @default 50
 *
 * @param Tool Custom Image
 * @parent --- Tool Button (Red) ---
 * @type file
 * @dir img/system/
 * @desc Custom background frame for the main tool button. The item's icon is drawn over this. Leave blank for no frame.
 * @default 
 *
 * @param Tool SE Name
 * @parent --- Tool Button (Red) ---
 * @type file
 * @dir audio/se/
 * @desc Sound effect to play when clicked.
 * @default Decision1
 *
 * @param --- Left Arrow ---
 * @default
 *
 * @param Left Key
 * @parent --- Left Arrow ---
 * @desc Keys to cycle left. Separate multiple with commas.
 * @default q
 *
 * @param Left Button Text
 * @parent --- Left Arrow ---
 * @desc Custom text to show in the brackets. Leave blank to use the first Left Key value.
 * @default 
 *
 * @param Left Text Spacing
 * @parent --- Left Arrow ---
 * @type number
 * @min -999
 * @desc The vertical spacing (in pixels) between the button and its text.
 * @default 2
 *
 * @param Left X
 * @parent --- Left Arrow ---
 * @desc X position. Variables: w, h, toolx, tooly, toolw, toolh, arroww, arrowh
 * @default toolx - arroww - 10
 *
 * @param Left Y
 * @parent --- Left Arrow ---
 * @desc Y position. Variables: w, h, toolx, tooly, toolw, toolh, arroww, arrowh
 * @default tooly + (toolh / 2) - (arrowh / 2)
 *
 * @param Left Custom Image
 * @parent --- Left Arrow ---
 * @type file
 * @dir img/system/
 * @desc Custom image for the left arrow. Leave blank to use Icon.
 * @default 
 *
 * @param Left Icon
 * @parent --- Left Arrow ---
 * @type number
 * @desc Icon ID if Custom Image is blank.
 * @default 74
 *
 * @param Left Icon Rotation
 * @parent --- Left Arrow ---
 * @type number
 * @desc Rotation of the icon in degrees (e.g., 0, 90, 180). Only applies if using Icon.
 * @default 180
 *
 * @param Left SE Name
 * @parent --- Left Arrow ---
 * @type file
 * @dir audio/se/
 * @desc Sound effect to play when clicked.
 * @default Cursor1
 *
 * @param --- Right Arrow ---
 * @default
 *
 * @param Right Key
 * @parent --- Right Arrow ---
 * @desc Keys to cycle right. Separate multiple with commas.
 * @default w
 *
 * @param Right Button Text
 * @parent --- Right Arrow ---
 * @desc Custom text to show in the brackets. Leave blank to use the first Right Key value.
 * @default 
 *
 * @param Right Text Spacing
 * @parent --- Right Arrow ---
 * @type number
 * @min -999
 * @desc The vertical spacing (in pixels) between the button and its text.
 * @default 2
 *
 * @param Right X
 * @parent --- Right Arrow ---
 * @desc X position. Variables: w, h, toolx, tooly, toolw, toolh, arroww, arrowh
 * @default toolx + toolw + 10
 *
 * @param Right Y
 * @parent --- Right Arrow ---
 * @desc Y position. Variables: w, h, toolx, tooly, toolw, toolh, arroww, arrowh
 * @default tooly + (toolh / 2) - (arrowh / 2)
 *
 * @param Right Custom Image
 * @parent --- Right Arrow ---
 * @type file
 * @dir img/system/
 * @desc Custom image for the right arrow. Leave blank to use Icon.
 * @default 
 *
 * @param Right Icon
 * @parent --- Right Arrow ---
 * @type number
 * @desc Icon ID if Custom Image is blank.
 * @default 74
 *
 * @param Right Icon Rotation
 * @parent --- Right Arrow ---
 * @type number
 * @desc Rotation of the icon in degrees (e.g., 0, 90, 180). Only applies if using Icon.
 * @default 0
 *
 * @param Right SE Name
 * @parent --- Right Arrow ---
 * @type file
 * @dir audio/se/
 * @desc Sound effect to play when clicked.
 * @default Cursor1
 *
 * @help
 * Make sure to place this below Galv_Tools.js.
 * This plugin disables Galv's standard HUD and injects an interactive
 * 3-button layout that reacts to Touch, Mouse, and Keyboard inputs, utilizing 
 * the dynamic evaluation coordinate system seen in JR_QuestTracker.
 *
 * ============================================================================
 * Script Calls
 * ============================================================================
 * 
 * jrToolHud.show()
 *    - Unhides the custom Tool HUD and enables tool usage.
 *
 * jrToolHud.hide()
 *    - Hides the custom Tool HUD and disables tool usage.
 * 
 */

var Imported = Imported || {};
Imported.JR_GalvToolHUD = true;

var GalvExt = GalvExt || {};
GalvExt.Parameters = PluginManager.parameters('JR_GalvToolHUD');

GalvExt.DisableOrig = eval(String(GalvExt.Parameters['Disable Original HUD']));
GalvExt.CustomKeys = String(GalvExt.Parameters['Custom Key Codes']);
GalvExt.TransOpacity = Number(GalvExt.Parameters['Transparent Opacity'] || 100);

// Script Call Interfaces
window.jrToolHud = {
    show: function() {
        if ($gameSystem) $gameSystem.toolBtnDisabled = false;
    },
    hide: function() {
        if ($gameSystem) $gameSystem.toolBtnDisabled = true;
    }
};

var getKeys = function(str) {
    if (!str) return [];
    return str.split(',').map(function(k) { return k.trim().toLowerCase(); });
};

// Button Configs
GalvExt.Btn = {
    main: {
        keys: getKeys(String(GalvExt.Parameters['Tool Key'])),
        btnText: String(GalvExt.Parameters['Tool Button Text'] || ''),
        textSpacing: Number(GalvExt.Parameters['Tool Text Spacing'] || 2),
        x: String(GalvExt.Parameters['Tool X']),
        y: String(GalvExt.Parameters['Tool Y']),
        img: String(GalvExt.Parameters['Tool Custom Image']),
        se: String(GalvExt.Parameters['Tool SE Name'])
    },
    left: {
        keys: getKeys(String(GalvExt.Parameters['Left Key'])),
        btnText: String(GalvExt.Parameters['Left Button Text'] || ''),
        textSpacing: Number(GalvExt.Parameters['Left Text Spacing'] || 2),
        x: String(GalvExt.Parameters['Left X']),
        y: String(GalvExt.Parameters['Left Y']),
        img: String(GalvExt.Parameters['Left Custom Image']),
        icon: Number(GalvExt.Parameters['Left Icon']),
        rotation: Number(GalvExt.Parameters['Left Icon Rotation'] || 0),
        se: String(GalvExt.Parameters['Left SE Name'])
    },
    right: {
        keys: getKeys(String(GalvExt.Parameters['Right Key'])),
        btnText: String(GalvExt.Parameters['Right Button Text'] || ''),
        textSpacing: Number(GalvExt.Parameters['Right Text Spacing'] || 2),
        x: String(GalvExt.Parameters['Right X']),
        y: String(GalvExt.Parameters['Right Y']),
        img: String(GalvExt.Parameters['Right Custom Image']),
        icon: Number(GalvExt.Parameters['Right Icon']),
        rotation: Number(GalvExt.Parameters['Right Icon Rotation'] || 0),
        se: String(GalvExt.Parameters['Right SE Name'])
    }
};

// Disable Galv's default input triggers only if our HUD is active
if (GalvExt.DisableOrig) {
    Galv.TOOLS.btnTool = "DISABLED_BY_JR_HUD";
    Galv.TOOLS.btnLeft = "DISABLED_BY_JR_HUD";
    Galv.TOOLS.btnRight = "DISABLED_BY_JR_HUD";
}

// Register Custom Keys
if (GalvExt.DisableOrig && GalvExt.CustomKeys) {
    var pairs = GalvExt.CustomKeys.split(',');
    for (var i = 0; i < pairs.length; i++) {
        var pair = pairs[i].split(':');
        if (pair.length === 2) {
            var key = pair[0].trim().toLowerCase();
            var code = parseInt(pair[1].trim());
            if (key && !isNaN(code)) {
                Input.keyMapper[code] = key;
            }
        }
    }
}

// Auto-Equip tool intercept
var _Galv_TOOLS_updateToolList = Galv.TOOLS.updateToolList;
Galv.TOOLS.updateToolList = function() {
    _Galv_TOOLS_updateToolList.call(this); // Run Galv's default list update first
    
    // Auto-equip the first tool if the player currently has nothing selected, but tools are available
    if ($gameSystem._tools.selected <= 0 && $gameSystem._tools.list.length > 0) {
        $gameSystem._tools.selected = $gameSystem._tools.list[0];
        Galv.TOOLS.needRefresh = true;
    }
};

// Optimized Coordinate Evaluator with caching
GalvExt.evalCoord = function(paramString, sprite, toolSprite, coordType) {
    var w = Graphics.boxWidth;
    var h = Graphics.boxHeight;
    
    var arroww = sprite._width || Window_Base._iconWidth;
    var arrowh = sprite._height || Window_Base._iconHeight;
    var toolw = arroww; 
    var toolh = arrowh;
    
    var toolx = 0;
    var tooly = 0;
    
    if (toolSprite) {
        toolw = toolSprite._width || Window_Base._iconWidth;
        toolh = toolSprite._height || Window_Base._iconHeight;
        toolx = toolSprite.x;
        tooly = toolSprite.y;
    }

    sprite._evalCacheKeys = sprite._evalCacheKeys || {};
    sprite._evalCacheVals = sprite._evalCacheVals || {};

    var stateKey = w + "_" + h + "_" + arroww + "_" + arrowh + "_" + toolw + "_" + toolh + "_" + toolx + "_" + tooly + "_" + paramString;

    if (sprite._evalCacheKeys[coordType] === stateKey) {
        return sprite._evalCacheVals[coordType];
    }

    try {
        var val = eval(paramString);
        sprite._evalCacheKeys[coordType] = stateKey;
        sprite._evalCacheVals[coordType] = val;
        return val;
    } catch (e) {
        // Log the error once per formula, then fallback to 0 safely
        if (!sprite._evalCacheKeys[coordType + "_error"]) {
            console.error("JR_GalvToolHUD Eval Error in: " + paramString, e);
            sprite._evalCacheKeys[coordType + "_error"] = true;
        }
        sprite._evalCacheKeys[coordType] = stateKey;
        sprite._evalCacheVals[coordType] = 0;
        return 0;
    }
};

//=============================================================================
// Sprite_ExtToolBtn (Inherits directly from Sprite to isolate from other UI mods)
//=============================================================================
function Sprite_ExtToolBtn() {
    this.initialize.apply(this, arguments);
}
Sprite_ExtToolBtn.prototype = Object.create(Sprite.prototype);
Sprite_ExtToolBtn.prototype.constructor = Sprite_ExtToolBtn;

Sprite_ExtToolBtn.prototype.initialize = function(type, refSprite) {
    Sprite.prototype.initialize.call(this);
    this._btnType = type;
    this._refSprite = refSprite;
    this._config = GalvExt.Btn[type];
    this._pressTimer = 0;
    this._width = 0;
    this._height = 0;
    
    // Background layer (scales independently)
    this._bgSprite = new Sprite();
    this.addChild(this._bgSprite);
    
    // Key Hint layer (never scales)
    this._keyHintSprite = new Sprite();
    this.addChild(this._keyHintSprite);
    
    this.setupGraphics();
};

Sprite_ExtToolBtn.prototype.setupGraphics = function() {
    if (this._config.img && this._config.img !== '') {
        var bmp = ImageManager.loadSystem(this._config.img);
        this._bgSprite.bitmap = bmp;
        bmp.addLoadListener(function() {
            this._width = bmp.width;
            this._height = bmp.height;
            this.centerBgSprite();
            this.refreshKeyHint();
            this.updatePosition();
        }.bind(this));
    } else {
        var pw = Window_Base._iconWidth;
        var ph = Window_Base._iconHeight;
        this._width = pw;
        this._height = ph;
        
        this._bgSprite.bitmap = new Bitmap(pw, ph);
        
        if (this._config.icon) {
            this._iconSprite = new Sprite(new Bitmap(pw, ph));
            var iconSet = ImageManager.loadSystem('IconSet');
            var sx = (this._config.icon % 16) * pw;
            var sy = Math.floor(this._config.icon / 16) * ph;
            this._iconSprite.bitmap.blt(iconSet, sx, sy, pw, ph, 0, 0);
            
            // Center the anchor point for clean rotation
            this._iconSprite.anchor.x = 0.5;
            this._iconSprite.anchor.y = 0.5;
            
            // Place at 0, 0 relative to the parent (_bgSprite) which is already centered!
            this._iconSprite.x = 0;
            this._iconSprite.y = 0;
            
            if (this._config.rotation !== 0) {
                this._iconSprite.rotation = this._config.rotation * (Math.PI / 180);
            }
            this._bgSprite.addChild(this._iconSprite);
        }
        
        this.centerBgSprite();
        this.refreshKeyHint();
        this.updatePosition();
    }
};

Sprite_ExtToolBtn.prototype.centerBgSprite = function() {
    this._bgSprite.anchor.x = 0.5;
    this._bgSprite.anchor.y = 0.5;
    this._bgSprite.x = this._width / 2;
    this._bgSprite.y = this._height / 2;
};

Sprite_ExtToolBtn.prototype.refreshKeyHint = function() {
    var defaultKey = this._config.keys.length > 0 ? this._config.keys[0].toUpperCase() : '';
    var rawText = this._config.btnText !== '' ? this._config.btnText : defaultKey;
    var text = '[' + rawText + ']';
    var fontSize = 16;
    var tempBmp = new Bitmap(1, 1);
    tempBmp.fontSize = fontSize;
    var width = tempBmp.measureTextWidth(text) + 8;
    
    this._keyHintSprite.bitmap = new Bitmap(width, fontSize + 8);
    this._keyHintSprite.bitmap.fontSize = fontSize;
    this._keyHintSprite.bitmap.textColor = '#ffffff'; 
    this._keyHintSprite.bitmap.outlineColor = 'rgba(0,0,0,0.8)';
    this._keyHintSprite.bitmap.outlineWidth = 3;
    this._keyHintSprite.bitmap.drawText(text, 0, 0, width, fontSize + 8, 'center');
    
    var w = this._width > 0 ? this._width : Window_Base._iconWidth;
    var h = this._height > 0 ? this._height : Window_Base._iconHeight;
    var spacing = this._config.textSpacing;
    
    this._keyHintSprite.x = (w - width) / 2;
    this._keyHintSprite.y = h + spacing;
};

Sprite_ExtToolBtn.prototype.update = function() {
    this.updateVisibility();
    
    // Optimization: Do not update children or input logic if the HUD is hidden
    if (!this.visible) {
        this._pressTimer = 0;
        this._bgSprite.scale.set(1, 1);
        return;
    }
    
    Sprite.prototype.update.call(this);
    this.updatePosition();
    this.updateInput();
    this.updateOpacity();
};

Sprite_ExtToolBtn.prototype.updateVisibility = function() {
    var isEventRunning = $gameMap.isEventRunning();
    
    // Ignore empty or comment-only events to prevent split-second HUD flickering
    if (isEventRunning && $gameMap._interpreter && $gameMap._interpreter._list) {
        var commandList = $gameMap._interpreter._list;
        var onlyComments = true;
        
        for (var i = 0; i < commandList.length; i++) {
            var code = commandList[i].code;
            // 0 = End of Event, 108 = Comment, 408 = Comment Continuation
            if (code !== 0 && code !== 108 && code !== 408) {
                onlyComments = false;
                break;
            }
        }
        
        if (onlyComments) {
            isEventRunning = false;
        }
    }

    if (isEventRunning || $gameSystem.toolBtnDisabled) {
        this.visible = false;
    } else {
        this.visible = true;
    }
};

Sprite_ExtToolBtn.prototype.updatePosition = function() {
    var w = Graphics.boxWidth;
    var h = Graphics.boxHeight;
    var arroww = this._width || Window_Base._iconWidth;
    var arrowh = this._height || Window_Base._iconHeight;
    var toolw = this._refSprite ? (this._refSprite._width || Window_Base._iconWidth) : arroww;
    var toolh = this._refSprite ? (this._refSprite._height || Window_Base._iconHeight) : arrowh;
    var toolx = this._refSprite ? this._refSprite.x : 0;
    var tooly = this._refSprite ? this._refSprite.y : 0;
    
    // Optimization: Skip evalCoord completely if dimensions haven't changed (saves 360 strings/sec)
    if (this._lastLayout &&
        this._lastLayout.w === w && this._lastLayout.h === h &&
        this._lastLayout.arroww === arroww && this._lastLayout.arrowh === arrowh &&
        this._lastLayout.toolw === toolw && this._lastLayout.toolh === toolh &&
        this._lastLayout.toolx === toolx && this._lastLayout.tooly === tooly) {
        return; 
    }
    
    this._lastLayout = { w: w, h: h, arroww: arroww, arrowh: arrowh, toolw: toolw, toolh: toolh, toolx: toolx, tooly: tooly };
    
    this.x = GalvExt.evalCoord(this._config.x, this, this._refSprite, 'x');
    this.y = GalvExt.evalCoord(this._config.y, this, this._refSprite, 'y');
};

Sprite_ExtToolBtn.prototype.updateInput = function() {
    if (this._pressTimer > 0) this._pressTimer--;

    var isHovered = this.isButtonTouched();
    var isMousePressed = TouchInput.isPressed() && isHovered;
    
    // Optimization: Replace the .some() callback with a standard loop
    var kbTriggered = false;
    var keys = this._config.keys;
    for (var i = 0; i < keys.length; i++) {
        if (Input.isTriggered(keys[i])) {
            kbTriggered = true;
            break;
        }
    }

    if (kbTriggered && $gamePlayer.canUseTool()) {
        this.onClick(); 
    } else if (isHovered && TouchInput.isTriggered() && $gamePlayer.canUseTool()) {
        this.onClick();
    }
    
    if (this._pressTimer > 0 || isMousePressed) {
        this._bgSprite.scale.x = 0.90;
        this._bgSprite.scale.y = 0.90;
    } else if (isHovered) {
        this._bgSprite.scale.x = 1.05;
        this._bgSprite.scale.y = 1.05;
    } else {
        this._bgSprite.scale.x = 1.0;
        this._bgSprite.scale.y = 1.0;
    }
};

Sprite_ExtToolBtn.prototype.updateOpacity = function() {
    var player = $gamePlayer;
    var screenX = player.screenX();
    var screenY = player.screenY();
    
    var w = this._width;
    var h = this._height;
    
    if (this._keyHintSprite && this._keyHintSprite.bitmap) {
        h += this._keyHintSprite.bitmap.height;
    }
    
    var isOverlapping = !(
        (screenX - 24) > (this.x + w) ||
        (screenX + 24) < this.x ||
        (screenY - 48) > (this.y + h) ||
        screenY < this.y
    );
    
    this.opacity = isOverlapping ? GalvExt.TransOpacity : 255;
};

Sprite_ExtToolBtn.prototype.isButtonTouched = function() {
    // Determine strict bounding box manually
    var mx = TouchInput.x;
    var my = TouchInput.y;
    return mx >= this.x && mx <= this.x + this._width && my >= this.y && my <= this.y + this._height;
};

Sprite_ExtToolBtn.prototype.onClick = function() {
    this._pressTimer = 5; 
    
    if (this._config.se !== '') {
        AudioManager.playSe({ name: this._config.se, pan: 0, pitch: 100, volume: 90 });
    }
    
    if (this._btnType === 'main') {
        $gamePlayer.useTool();
    } else if (this._btnType === 'left') {
        Galv.TOOLS.shiftTool(-1);
    } else if (this._btnType === 'right') {
        Galv.TOOLS.shiftTool(1);
    }
};


//=============================================================================
// Sprite_ExtToolMainBtn (Specialized to show the actual tool icon on top)
//=============================================================================
function Sprite_ExtToolMainBtn() {
    this.initialize.apply(this, arguments);
}
Sprite_ExtToolMainBtn.prototype = Object.create(Sprite_ExtToolBtn.prototype);
Sprite_ExtToolMainBtn.prototype.constructor = Sprite_ExtToolMainBtn;

Sprite_ExtToolMainBtn.prototype.initialize = function(type, ref) {
    Sprite_ExtToolBtn.prototype.initialize.call(this, type, ref);
    
    this._toolIconSprite = new Sprite_ToolHudIcon(); 
    
    this._toolIconSprite.updateGraphic = function() {
        if (this._toolId != $gameSystem._tools.selected || Galv.TOOLS.needRefresh) {
            var item = $dataItems[$gameSystem._tools.selected];
            this._iconIndex = item ? item.iconIndex : 0;
            
            this.x = 0;
            this.y = 0;
            this.scale.x = Galv.TOOLS.needRefresh ? 1 : Galv.TOOLS.zoom;
            this.scale.y = Galv.TOOLS.needRefresh ? 1 : Galv.TOOLS.zoom;

            var imgReady = false;
            
            if (item && item.meta.toolimg) {
                var sourceBmp = ImageManager.loadPicture(item.meta.toolimg);
                if (sourceBmp.isReady()) {
                    // FIX: Create a private copy to prevent modifying the globally cached picture
                    this.bitmap = new Bitmap(sourceBmp.width, sourceBmp.height);
                    this.bitmap.blt(sourceBmp, 0, 0, sourceBmp.width, sourceBmp.height, 0, 0);
                    imgReady = true;
                }
            } else if (this._iconIndex) {
                var pw = Window_Base._iconWidth;
                var ph = Window_Base._iconHeight;
                var tw = Galv.TOOLS.hudIconWH[0];
                var th = Galv.TOOLS.hudIconWH[1];
                
                var bmpIcon = ImageManager.loadSystem('IconSet');
                
                if (bmpIcon.isReady()) {
                    // Revert to reliable method: generate a new bitmap so the engine immediately renders it
                    this.bitmap = new Bitmap(tw, th);
                    var sx = (this._iconIndex % 16) * pw;
                    var sy = Math.floor(this._iconIndex / 16) * ph;
                    
                    this.bitmap.blt(bmpIcon, sx, sy, pw, ph, 0, 0, tw, th);
                    imgReady = true;
                }
            } else {
                this.bitmap = new Bitmap(Window_Base._iconWidth, Window_Base._iconHeight);
                imgReady = true;
            }
            
            if (imgReady) {
                var itemNumber = $gameParty.numItems(item);
                this.bitmap.fontSize = Galv.TOOLS.numSize;
                if (itemNumber && itemNumber > 1) {
                    this.bitmap.drawText(itemNumber, 0, this.bitmap.height - Galv.TOOLS.numSize - 5, this.bitmap.width - 5, Galv.TOOLS.numSize, 'right');
                }
                this._toolId = $gameSystem._tools.selected;
                Galv.TOOLS.needRefresh = false;
            }
        }
    };
    
    this._toolIconSprite.x = 0;
    this._toolIconSprite.y = 0;
    this._toolId = null; 
    this._toolIconSprite.updateGraphic(); 
    
    this._bgSprite.addChild(this._toolIconSprite);
};


//=============================================================================
// Spriteset_Map Injection
//=============================================================================
var _Spriteset_Map_createToolHud = Spriteset_Map.prototype.createToolHud;
Spriteset_Map.prototype.createToolHud = function() {
    if (GalvExt.DisableOrig) {
        this.createExtendedToolHud();
    } else {
        _Spriteset_Map_createToolHud.call(this);
    }
};

Spriteset_Map.prototype.createExtendedToolHud = function() {
    this._extToolMain = new Sprite_ExtToolMainBtn('main', null);
    this._extToolLeft = new Sprite_ExtToolBtn('left', this._extToolMain);
    this._extToolRight = new Sprite_ExtToolBtn('right', this._extToolMain);
    
    this.addChild(this._extToolMain);
    this.addChild(this._extToolLeft);
    this.addChild(this._extToolRight);
};


//=============================================================================
// Scene_Map Touch Interception
//=============================================================================
var _Scene_Map_processMapTouch = Scene_Map.prototype.processMapTouch;
Scene_Map.prototype.processMapTouch = function() {
    if (this._spriteset) {
        var hudMain = this._spriteset._extToolMain;
        var hudLeft = this._spriteset._extToolLeft;
        var hudRight = this._spriteset._extToolRight;
        
        if (hudMain && hudMain.visible) {
            if ((hudMain.isButtonTouched && hudMain.isButtonTouched()) || 
                (hudLeft.isButtonTouched && hudLeft.isButtonTouched()) || 
                (hudRight.isButtonTouched && hudRight.isButtonTouched())) {
                return;
            }
        }
    }
    _Scene_Map_processMapTouch.call(this);
};